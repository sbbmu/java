package fxgraph;

/**
 * Created by VHASFCSUNB on 10/3/2016.
 */
public class Bounds {
    private double x, y, w, h;

    public Bounds(double x, double y, double w, double h) {
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
    }

    public Bounds() {
        x = 0;
        y = 0;
        w = 0;
        h = 0;
    }

    public static double keepBounds(double val, double min, double max) {
        if (val < min) val = min;
        if (val > max) val = max;
        return val;
    }

    // find out max bounds when x,y keep changing, eg, a continuous mouse movement
    public static Bounds maxBounds(Bounds b, double x, double y) {
        if (x < b.getX()) b.setW(b.getW() + b.getX() - x);
        else b.setW(Utils.max(b.getW(), x - b.getX()));
        if (y < b.getY()) b.setH(b.getH() + b.getY() - y);
        else b.setH(Utils.max(b.getH(), y - b.getY()));

        b.setX(Utils.min(b.getX(), x));
        b.setY(Utils.min(b.getY(), y));

        return b;
    }

    public static Bounds maxBounds(PointsArray p) {
        double xMin = Utils.min(p.getaX()), yMin = Utils.min(p.getaY()),
                xMax = Utils.max(p.getaX()), yMax = Utils.max(p.getaY());
        return new Bounds(xMin, yMin, xMax - xMin, yMax - yMin);
    }

    // add border of delta to the bounds
    public static Bounds resize(Bounds b, double delta) {
        return resize(b, delta, delta);
    }

    public static Bounds resize(Bounds b, double dx, double dy) {
        b.setX(b.getX() - dx);
        b.setY(b.getY() - dy);
        b.setW(b.getW() + dx * 2);
        b.setH(b.getH() + dy * 2);
        return b;
    }

    public static Bounds getBoundingBox(Bounds b, PointsArray array) {
        for (int i = 0; i < array.size(); i++) {
            b = maxBounds(b, array.getaX()[i], array.getaY()[i]);
        }
        return b;
    }

    public double getX() {
        return x;
    }

    public void setX(double x) {
        this.x = x;
    }

    public double getY() {
        return y;
    }

    public void setY(double y) {
        this.y = y;
    }

    public double getW() {
        return w;
    }

    public void setW(double w) {
        this.w = w;
    }

    public double getH() {
        return h;
    }

    public void setH(double h) {
        this.h = h;
    }
    public String toString(){
        return Utils.log(x,y,w,h);
    }
}


