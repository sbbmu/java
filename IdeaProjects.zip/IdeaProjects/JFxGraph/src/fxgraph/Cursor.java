package fxgraph;

import javafx.scene.ImageCursor;
import javafx.scene.SnapshotParameters;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;
import javafx.scene.shape.Ellipse;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.Shape;

/**
 * Created by Bing Sun1 on 9/4/2016.
 */
enum CursorType {
    RECTANGLE, OVAL
}

public class Cursor {
    static CursorType cursorType;
    static Bounds cursorBounds;

    public static void Rectangle(Canvas canvas, double w, double h) {
        Rectangle rectangle = new Rectangle(w, h);
        rectangle.setFill(Color.rgb(220, 220, 220, 0.15));
        rectangle.setStroke(Color.BLACK);
        canvas.setCursor(new ImageCursor(rectangle.snapshot(null, null)));
        cursorType=CursorType.RECTANGLE;
        cursorBounds=new Bounds(0,0,w,h);
    }

    public static void Ellipse(Canvas canvas, double w, double h) {
        Canvas c=new Canvas(w,h);
        GraphicsContext gc=c.getGraphicsContext2D();
        gc.setStroke(Color.BLACK);
        gc.setFill(Color.rgb(192, 192, 192, 0.15));
        gc.strokeOval(1,1,w-2,h-2);
        gc.fillOval(1,1,w-2,h-2);
        gc.setLineWidth(1);
        gc.strokeLine(0,h/2,w-1,h/2);
        gc.strokeLine(w/2,0,w/2,h-1);

        SnapshotParameters sp = new SnapshotParameters();
        sp.setFill(Color.TRANSPARENT);
        Image img = c.snapshot(sp, null);

        canvas.setCursor(new ImageCursor(img, img.getWidth() / 2, img.getHeight() / 2));

        cursorType=CursorType.RECTANGLE;
        cursorBounds=new Bounds(0,0,w,h);
    }
}
