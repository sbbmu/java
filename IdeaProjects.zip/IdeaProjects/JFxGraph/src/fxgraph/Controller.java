package fxgraph;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Cursor;
import javafx.scene.SnapshotParameters;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.*;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.PixelReader;
import javafx.scene.image.WritableImage;
import javafx.scene.input.*;
import javafx.scene.paint.Color;

import java.awt.*;
import java.net.URL;
import java.util.ResourceBundle;

public final class Controller implements Initializable {
    private final KeyCombination ctlZ = new KeyCodeCombination(KeyCode.Z, KeyCombination.CONTROL_DOWN); //undo
    private final KeyCombination ctlY = new KeyCodeCombination(KeyCode.Y, KeyCombination.CONTROL_DOWN); //redo
    private final KeyCombination ctlX = new KeyCodeCombination(KeyCode.X, KeyCombination.CONTROL_DOWN); //cut
    private final KeyCombination ctlC = new KeyCodeCombination(KeyCode.C, KeyCombination.CONTROL_DOWN); //copy
    private final KeyCombination ctlV = new KeyCodeCombination(KeyCode.V, KeyCombination.CONTROL_DOWN); //paste

    @FXML
    private ToggleButton freehandButton;
    @FXML
    private TextField textA, textB, textC;
    @FXML
    private TextField canvasW, canvasH, textLwd;
    @FXML
    private ScrollPane scrollPane;
    @FXML
    private ColorPicker colorPickerStroke, colorPickerFill;
    @FXML
    private CheckBox posColCheckBox, rndColCheckBox, fillCheckBox, strokeCheckBox;
    @FXML
    private Label label1, label2, label3, label4, labelA, labelB, labelC;
//    @FXML
//    private HBox editHBox;

    private PannableCanvas pane;
    private Canvas canvas, canvas2, canvasGrid;
    private GraphicsContext gc;
    private GraphicsContext gc2;
    private WritableImage img; // selection
    private DraggableImageView imageView;
    private TextInput textInputWindow = new TextInput();
    private DrawGC undoGC;
    private int mouseX, mouseY;


    @Override
    public void initialize(URL location, ResourceBundle resources) {
        canvas = new Canvas(800, 600);
        gc = canvas.getGraphicsContext2D();
        Brushes.setGc(gc);

        undoGC = new DrawGC(gc); // for undo wrapper

        // canvas layer 2
        canvas2 = new Canvas(canvas.getWidth(), canvas.getHeight());
        gc2 = canvas2.getGraphicsContext2D();

        pane = new PannableCanvas(canvas.getWidth(), canvas.getHeight());
        pane.getChildren().addAll(canvas, canvas2);
        pane.setTranslateX(10);
        pane.setTranslateY(10);

        scrollPane.setContent(pane);
        SceneGestures sceneGestures = new SceneGestures(pane);
        scrollPane.addEventFilter(MouseEvent.MOUSE_PRESSED, sceneGestures.getOnMousePressed());
        scrollPane.addEventFilter(MouseEvent.MOUSE_DRAGGED, sceneGestures.getOnMouseDragged());
        scrollPane.addEventFilter(ScrollEvent.ANY, sceneGestures.getOnScroll());

        scrollPane.setOnKeyPressed(e -> onKeyPressed(e));

        freehandButton.setSelected(true);
        freehandButton.requestFocus();
        freeDrawButton();

        colorPickerStroke.setValue(Color.BLACK);
        colorPickerStroke.setStyle("-fx-color-label-visible: false; -fx-color-rect-height: 4; ");
        colorPickerFill.setValue(Color.WHITE);
        colorPickerFill.setStyle("-fx-color-label-visible: false;");

        TextFieldEvents tfe = new TextFieldEvents();
        textA.setOnMouseDragged(e -> {
            tfe.setTextFieldValueByDragging(e, 3, 100);
            setOnTextFieldAction(new ActionEvent(e.getSource(), null));
        });
        textB.setOnMouseDragged(e -> {
            tfe.setTextFieldValueByDragging(e, 1.0, 400.0);
            setOnTextFieldAction(new ActionEvent(e.getSource(), null));
        });
        textC.setOnMouseDragged(e -> {
            tfe.setTextFieldValueByDragging(e, -360, 360);
            setOnTextFieldAction(new ActionEvent(e.getSource(), null));
        });
        textLwd.setOnMouseDragged(e -> {
            tfe.setTextFieldValueByDragging(e, 0.1, 200.0);
            setOnTextFieldAction(new ActionEvent(e.getSource(), null));
        });

//        DoubleProperty myScale =new SimpleDoubleProperty(pane.getScale());
//        StringConverter<Number> converter = new NumberStringConverter();
//        Bindings.bindBidirectional(label3.textProperty(), new SimpleDoubleProperty(pane.getScale()), converter);
//        label3.textProperty().bind(StringProperty.class.cast(String.valueOf(pane.getScale())));
    }

    @FXML
    private void onKeyPressed(KeyEvent k) {
//        System.out.println("Key pressed " + k.toString());
        if (k.getCode() == KeyCode.C) clearCanvas(false);
        else if (k.getCode() == KeyCode.DELETE) cutButton();
        else if (k.getCode() == KeyCode.SHIFT) Brushes.setIsSHIFT(true);
        else if (k.getCode() == KeyCode.P) freeDrawButton();
        else if (k.getCode() == KeyCode.UP) {
            --mouseY;
            moveCursor(mouseX, mouseY);
        } else if (k.getCode() == KeyCode.DOWN) {
            ++mouseY;
            moveCursor(mouseX, mouseY);
        } else if (k.getCode() == KeyCode.LEFT) {
            --mouseX;
            moveCursor(mouseX, mouseY);
        } else if (k.getCode() == KeyCode.RIGHT) {
            ++mouseX;
            moveCursor(mouseX, mouseY);
        }

        //
        if (ctlZ.match(k)) undo();
        else if (ctlY.match(k)) redo();
        else if (ctlX.match(k)) cutButton();
        else if (ctlC.match(k)) copyButton();
        else if (ctlV.match(k)) pasteButton();

        k.consume();
    }

    /**
     * Move the mouse to the specific screen position
     *
     * @param screenX
     * @param screenY
     */
    public void moveCursor(int screenX, int screenY) {
        Platform.runLater(() -> {
            try {
                Robot robot = new Robot();
                robot.mouseMove(screenX, screenY);
            } catch (AWTException e) {
                e.printStackTrace();
            }
        });
    }

    @FXML
    private void undo() {
        UndoCollector.INSTANCE.undo();
    }

    @FXML
    private void redo() {
        UndoCollector.INSTANCE.redo();
    }

    @FXML
    private void onKeyReleased(KeyEvent k) {
        if (k.getCode() == KeyCode.SHIFT)
            Brushes.setIsSHIFT(false);
    }

    @FXML
    private void clearCanvas() {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Are you sure to clear canvas?", ButtonType.OK);
        alert.showAndWait().filter(response -> response == ButtonType.OK)
                .ifPresent(response -> clearCanvas(false));
    }

    private void clearCanvas(boolean ask) {
        if (ask)
            clearCanvas();
        else
            undoGC.callCommand(e -> undoGC.clearRect(e), new Bounds(0, 0, canvas.getWidth(), canvas.getHeight()));
//            gc.clearRect(0, 0, canvas.getWidth(), canvas.getHeight());
    }

    @FXML
    private void openImage() {
        fxgraphIO.openImage(gc);
    }

    @FXML
    private void saveImage() {
        fxgraphIO.saveImage(canvas);
    }

    @FXML
    private void setCanvasSize() {
        try {
            canvas.setHeight(Integer.parseInt(canvasH.getText()));
            canvas.setWidth(Integer.parseInt(canvasW.getText()));
            pane.setPrefWidth(canvas.getWidth());
            pane.setPrefHeight(canvas.getHeight());
            setCanvas2Size();
        } catch (NumberFormatException | NullPointerException e) {
            System.out.println(e);
        }
    }

    @FXML
    private void expandCanvasSize() {
//        Undo undo = new Undo(canvas,"Old Canvas");
        canvas.setHeight(scrollPane.getHeight() - 8);
        canvas.setWidth(scrollPane.getWidth() - 8);
//        undo.End(new Bounds(0,0,canvas.getWidth(),canvas.getHeight()));
        pane.setPrefWidth(canvas.getWidth());
        pane.setPrefHeight(canvas.getHeight());
        setCanvas2Size();
    }

    private void setCanvas2Size() {
        canvas2.setWidth(canvas.getWidth());
        canvas2.setHeight(canvas.getHeight());
    }

    @FXML
    private void setStrokeColor() {
        Brushes.setStrokeColor(colorPickerStroke.getValue());
    }

    @FXML
    private void setFillColor() {
        Brushes.setFillColor(colorPickerFill.getValue());
    }

    @FXML
    public void setOnTextFieldAction(ActionEvent e) {
        double newValue;
        String text = ((TextField) e.getSource()).getText();
        try {
            newValue = Double.parseDouble(text);
        } catch (NumberFormatException ex) {
            newValue = 1;
        }
        if (e.getSource() == textA) {
            if (!text.isEmpty()) Brushes.setParA(newValue);
        } else if (e.getSource() == textB) {
            if (!text.isEmpty()) Brushes.setParB(newValue);
        } else if (e.getSource() == textC) {
            if (!text.isEmpty()) Brushes.setParC(newValue);
        } else if (e.getSource() == textLwd) {
            if (newValue < 0.1) newValue = 0.1;
            if (newValue > 400) newValue = 400;
            Brushes.setLwd(newValue);
        }
    }

    public void setBrushStatus() {
        Event.fireEvent(textA, new ActionEvent(textA, null));
        Event.fireEvent(textB, new ActionEvent(textB, null));
        Event.fireEvent(textC, new ActionEvent(textC, null));
        Event.fireEvent(textLwd, new ActionEvent(textLwd, null));

        setStrokeColor();
        setFillColor();
        Brushes.setIsFill(fillCheckBox.isSelected());
        Brushes.setIsStroke(strokeCheckBox.isSelected());

        if (posColCheckBox.isSelected())
            Brushes.setColorState(ColorState.Position);
        else if (rndColCheckBox.isSelected())
            Brushes.setColorState(ColorState.Random);
        else
            Brushes.setColorState(ColorState.Fixed);
    }

    public void scrollPaneOnMouseMoved(MouseEvent e) {
        mouseX = (int) scrollPane.localToScreen(e.getX(), e.getY()).getX();
        mouseY = (int) scrollPane.localToScreen(e.getX(), e.getY()).getY();
        label4.setText(String.format("%1$1.0f", e.getX()) + ", " + String.format("%1$1.0f", e.getY()));
        label3.setText(String.format("%1$1.2f%%", pane.getScale() * 100));
        // label1.setText(Brushes.log(Brushes.getX1(), Brushes.getY1(),
        // Brushes.getSelectionWidth(), Brushes.getSelectionHeight()));
        // label2.setText(isInRect(e, Brushes.getSelectionBounds()) ? "IN" : "Out");
        // label2.setText("ScrollPane content: " + scrollPane.getContent());
        // pane.setStyle("-fx-background-color: #fefefe");
        // scrollPane.setStyle("-fx-background: #808080");
    }

    @FXML
    public void cutButton() {
        copyButton();
        Bounds r = Brushes.getSelectionBounds();
//        gc.clearRect(r.getX(), r.getY(), r.getWidth(), r.getHeight());
        undoGC.callCommand(e -> undoGC.clearRect(e), new Bounds(r.getX(), r.getY(), r.getW(), r.getH()));
    }

    @FXML
    public void copyButton() {
        if (Brushes.isSelectionSet()) {
            img = Brushes.copyImage(canvas, Brushes.getSelectionBounds());
            if (img.getWidth() > 0)
                imageView = new DraggableImageView(img);
        }
    }

    @FXML
    public void pasteButton() {
        if (imageView != null && img.getWidth() > 0) {
            if (!pane.getChildren().contains(imageView)) {
                pane.getChildren().add(imageView);
                imageView.setTranslateX(0.0);
                imageView.setTranslateY(0.0);
                imageView.setX(Brushes.getX0());
                imageView.setY(Brushes.getY0());
                imageView.setEffect(new DropShadow(20, Color.gray(0.15)));
            }
        }
    }

    public void flattenButton() {
        if (pane.getChildren().contains(imageView)) {
            double offsetX = imageView.getTranslateX() + imageView.getX();
            double offsetY = imageView.getTranslateY() + imageView.getY();

            Undo undo = new Undo(gc.getCanvas(), "Paste");
            gc.drawImage(img, offsetX, offsetY);
            undo.End(new Bounds(offsetX, offsetY, img.getWidth(), img.getHeight()));

            pane.getChildren().remove(imageView);
            Brushes.GCClear(gc2);
        }
    }

    @FXML
    public void newCanvas() {
        clearCanvas();
    }

    private void setTextFieldVisibility(boolean visLabelA, boolean visLabelB, boolean visLabelC,
                                        String txtLabelA, String txtLabelB, String txtLabelC,
                                        String txtTextA, String txtTextB, String txtTextC) {
        boolean txtVis = setTextFieldVisibility(visLabelA, visLabelB, visLabelC);
        boolean lblViz = setToolbarLabels(txtLabelA, txtLabelB, txtLabelC);

        if (!txtVis | !lblViz) {
            textA.setText(txtTextA);
            textB.setText(txtTextB);
            textC.setText(txtTextC);
        }
    }

    private boolean setToolbarLabels(String a, String b, String c) {
        if (labelA.getText().equals(a) & labelB.getText().equals(b) & labelC.getText().equals(c))
            return true;
        if (!a.isEmpty()) {
            labelA.setVisible(true);
            labelA.setText(a);
        } else labelA.setVisible(false);

        if (!b.isEmpty()) {
            labelB.setVisible(true);
            labelB.setText(b);
        } else labelB.setVisible(false);

        if (!c.isEmpty()) {
            labelC.setVisible(true);
            labelC.setText(c);
        } else labelC.setVisible(false);

        return false;
    }

    private boolean setTextFieldVisibility(boolean visLabelA, boolean visLabelB, boolean visLabelC) {
        if (labelA.isVisible() == visLabelA & labelB.isVisible() == visLabelB & labelC.isVisible() == visLabelC)
            return true;
        labelA.setVisible(visLabelA);
        textA.setVisible(visLabelA);

        labelB.setVisible(visLabelB);
        textB.setVisible(visLabelB);

        labelC.setVisible(visLabelC);
        textC.setVisible(visLabelC);
        return false;
    }

    public void about() {
        About.show();
    }

    public void options() {
        OptionsWindow.diplay();
    }

    /**
     * ****************  Brushes  ***********************
     */
    @FXML
    private void onMouseDown(MouseEvent e) {
        Brushes.setX0(e.getX());
        Brushes.setY0(e.getY());
        setBrushStatus();
    }

    // freehand
    @FXML
    public void freeDrawButton() {
        label1.setText(" Freehand drawing.");
        setTextFieldVisibility(false, false, false);
//        editHBox.setVisible(false);
        setBrushStatus();

        fxgraph.Cursor.Ellipse(canvas, Brushes.getLwd(), Brushes.getLwd());
        canvas.toFront();
        canvas.setOnMousePressed(e -> {
            if (e.getButton() == MouseButton.PRIMARY) {
                onMouseDown(e);
                Brushes.startFreeHand(e);
            }
        });
        canvas.setOnMouseDragged(e -> Brushes.drawFreeHand(e));
        canvas.setOnMouseReleased(e -> { if (e.getButton() == MouseButton.PRIMARY) Brushes.onMouseReleased(e); });
    }

    public void eraserButton() {
        label1.setText(" Eraser with size of Width and Height.");
        setTextFieldVisibility(true, true, false, "Width", "Height", "", "10", "10", "");
//        editHBox.setVisible(false);
        setBrushStatus();

        double w = Brushes.getParA(), h = Brushes.getParB();
        fxgraph.Cursor.Rectangle(canvas, w, h);

        canvas.toFront();
        canvas.setOnMousePressed(e -> { if (e.getButton() == MouseButton.PRIMARY) Brushes.startErase(e); });
        canvas.setOnMouseDragged(e -> { if (e.getButton() == MouseButton.PRIMARY) Brushes.drawErase(e); });
        canvas.setOnMouseReleased(e -> { if (e.getButton() == MouseButton.PRIMARY) Brushes.drawEraseReleased(e); });
    }

    public void selectButton() {
        label1.setText(" 1. Make a rectangular selection. 2. Copy or Cut. 3. Paste and drag to a new location. 4. Flatten to apply to the new place. ");
        setTextFieldVisibility(true, true, true, "Width", "Height", "Rotation", "0", "0", "0");
//        editHBox.setVisible(true);

        canvas2.setCursor(Cursor.CROSSHAIR);
        canvas2.toFront();
        canvas2.setOnMousePressed(e -> onMouseDown(e));
        canvas2.setOnMouseDragged(e -> canvas2OnMouseDragged(e));
        canvas2.setOnMouseReleased(e -> canvas2OnMouseRelease(e));
    }

    private void canvas2OnMouseRelease(MouseEvent e) {
        Brushes.selectOnMouseReleased(e);
        Brushes.setIsSelectionSet(true);
    }

    private void canvas2OnMouseDragged(MouseEvent e) {
        Brushes.drawRect(e, gc2);
    }

    public void lineButton() {
        label1.setText(" Number of parallel lines with Distance apart.");
        setTextFieldVisibility(true, true, false, "Number", "Distance", "", "5", "10", "");
//        editHBox.setVisible(false);
        setBrushStatus();

        canvas2.setCursor(Cursor.CROSSHAIR);
        canvas2.toFront();
        canvas2.setOnMousePressed(e -> onMouseDown(e));
        canvas2.setOnMouseDragged(e -> Brushes.drawLine(e, gc2));
        canvas2.setOnMouseReleased(e -> Brushes.lineOnMouseReleased(e, gc2));
    }

    public void rectButton() {
        label1.setText(" Click and drag to make a rectangle.");
        setTextFieldVisibility(true, true, true, "Width", "Height", "Rotation", "0", "0", "0");
//        editHBox.setVisible(false);
        setBrushStatus();

        canvas2.setCursor(Cursor.CROSSHAIR);
        canvas2.toFront();
        canvas2.setOnMouseDragged(e -> {
            Brushes.drawRect(e, gc2);
        });//label3.setText(Utils.log(Brushes.bx,Brushes.by,Brushes.bw,Brushes.bh));});
        canvas2.setOnMousePressed(e -> onMouseDown(e));
        canvas2.setOnMouseReleased(e -> Brushes.rectOnMouseReleased(e, gc2));
    }

    public void ovalButton() {
        label1.setText(" Click and drag to make an oval.");
        setTextFieldVisibility(true, true, true, "Width", "Height", "Rotation", "0", "0", "0");
//        editHBox.setVisible(false);
        setBrushStatus();

        canvas2.setCursor(Cursor.CROSSHAIR);
        canvas2.toFront();
        canvas2.setOnMouseDragged(e -> Brushes.drawOval(e, gc2));
        canvas2.setOnMousePressed(e -> onMouseDown(e));
        canvas2.setOnMouseReleased(e -> Brushes.ovalOnMouseReleased(e, gc2));
    }

    @FXML
    public void polyBrushButton() {
        label1.setText(" Polygon with Vertices of points, Radius , Rotation of the points from Eas upward.");
        setTextFieldVisibility(true, true, true, "Vertices", "Radius", "Rotation", "5", "30", "18");
//        editHBox.setVisible(false);
        setBrushStatus();

        canvas.setCursor(Cursor.DEFAULT);
        canvas.toFront();
        canvas.setOnMouseDragged(e -> { if (e.getButton() == MouseButton.PRIMARY) Brushes.polyBrush(e); });
        canvas.setOnMousePressed(e -> { if (e.getButton() == MouseButton.PRIMARY) Brushes.polyBrush(e); });
        canvas.setOnMouseReleased(null);
    }

    @FXML
    public void starBrushButton() {
        label1.setText(" Star with Vertices of points, outer Radius (inner will always 1/3 of outer), Rotation of the points from Eas upward.");
        setTextFieldVisibility(true, true, true, "Vertices", "Radius", "Rotation", "5", "30", "18");
//        editHBox.setVisible(false);
        setBrushStatus();

        canvas.setCursor(Cursor.DEFAULT);
        canvas.toFront();
        canvas.setOnMouseDragged(e -> { if (e.getButton() == MouseButton.PRIMARY) Brushes.starBrush(e); });
        canvas.setOnMousePressed(e -> { if (e.getButton() == MouseButton.PRIMARY) Brushes.starBrush(e); });
        canvas.setOnMouseReleased(null);
    }

    public void sineBrushButton() {
        label1.setText(" Draw a sine curve: y =  A * sin(B * x + C). Hold <SHIFT> to keep horizontal. A=Amplitude, B= 2*Pi/period, C=shift");
        setTextFieldVisibility(true, true, true, "Amp", "Freq", "Phase", "40", "0.5", "90");
//        editHBox.setVisible(false);
        setBrushStatus();

        canvas.setCursor(Cursor.DEFAULT);
        canvas.toFront();

        canvas.setOnMousePressed(e -> {
            Brushes.setX1(e.getX());
            Brushes.setY1(e.getY());
            onMouseDown(e);
            Brushes.sineBrushStart(e);
        });
        canvas.setOnMouseDragged(e -> Brushes.sineBrush(e));
        canvas.setOnMouseReleased(e -> Brushes.onMouseReleased(e));
    }

    public void flowerBrushButton() {
        label1.setText(" Draw a flora: k petals (or pairs of petals for even numbers.)");
        setTextFieldVisibility(true, true, true, "k", "Amplitude", "Rotation", "7", "100", "0");
//        editHBox.setVisible(false);
        setBrushStatus();

        canvas.setCursor(Cursor.DEFAULT);
        canvas.toFront();

        canvas.setOnMousePressed(e -> { if (e.getButton() == MouseButton.PRIMARY) Brushes.roseBrush(e); });
        canvas.setOnMouseDragged(e -> { if (e.getButton() == MouseButton.PRIMARY) Brushes.roseBrush(e); });
        canvas.setOnMouseReleased(null);
    }

    @FXML
    public void hozMirrorButton() {
        label1.setText(" Draw right-left symmetry.");
        setTextFieldVisibility(false, false, false);
//        editHBox.setVisible(false);
        setBrushStatus();

        canvas.setCursor(Cursor.DEFAULT);
        canvas.toFront();
        canvas.setOnMousePressed(e -> Brushes.hozMirrorBrushStart(e));
        canvas.setOnMouseDragged(e -> Brushes.hozMirrorBrush(e));
        canvas.setOnMouseReleased(e -> Brushes.onMouseReleased(e));
    }

    @FXML
    public void fourMirrorButton() {
        label1.setText(" Draw from all four corners.");
        setTextFieldVisibility(false, false, false);
//        editHBox.setVisible(false);
        setBrushStatus();

        canvas.setCursor(Cursor.DEFAULT);
        canvas.toFront();
        canvas.setOnMousePressed(e -> Brushes.fourMirrorStart(e));
        canvas.setOnMouseDragged(e -> Brushes.fourMirrorBrush(e));
        canvas.setOnMouseReleased(e -> Brushes.onMouseReleased(e));
    }

    public void paintTextButton() {
        label1.setText(" Draw some texts.");
        setTextFieldVisibility(false, false, false);
//        editHBox.setVisible(false);
        boolean isOK = textInputWindow.display();
        if (isOK) {
            setBrushStatus();
            canvas.setCursor(Cursor.TEXT);
            canvas.toFront();
            canvas.setOnMousePressed(e -> {
                if (e.getButton() == MouseButton.PRIMARY)
                    Brushes.paintText(e, textInputWindow.getInputText(),
                            textInputWindow.getFont(), textInputWindow.getFontSize());
            });
            canvas.setOnMouseDragged(null);
            canvas.setOnMouseReleased(null);
        }
    }

    public void paintSparkleButton() {
        label1.setText(" Spray: Number of dots, Spread radius, Size for each dot.");
        setTextFieldVisibility(true, true, true, "Number", "Spread", "Size", "25", "50", "5");
//        editHBox.setVisible(false);
        setBrushStatus();

        canvas.setCursor(Cursor.HAND);
        canvas.toFront();
        canvas.setOnMousePressed(e -> { if (e.getButton() == MouseButton.PRIMARY) Brushes.drawSparkles(e); });
        canvas.setOnMouseDragged(e -> { if (e.getButton() == MouseButton.PRIMARY) Brushes.drawSparkles(e); });
        canvas.setOnMouseReleased(null);

    }

    @FXML
    public void drawPathButton() {
        label1.setText(" Try make a path: r for radius of the dome, s for size of the base.");
        setTextFieldVisibility(true, true, false, "r", "s", "", "10", "20", "0");
//        editHBox.setVisible(false);
        setBrushStatus();

        canvas.setCursor(Cursor.OPEN_HAND);
        canvas.toFront();
        fxgraphDrawPath.setGc(gc);
        canvas.setOnMouseDragged(e ->{ if (e.getButton() == MouseButton.PRIMARY)fxgraphDrawPath.drawPath(e); } );
        canvas.setOnMousePressed(e -> { if (e.getButton() == MouseButton.PRIMARY)fxgraphDrawPath.drawPath(e); });
        canvas.setOnMouseReleased(null);
    }

    @FXML
    private void holidayBrushButton() {
        label1.setText(" Just doodle!");
        setTextFieldVisibility(false, false, false);
//        editHBox.setVisible(false);
        canvas.setCursor(Cursor.DEFAULT);
        canvas.toFront();
        canvas.setOnMouseDragged(e -> Brushes.holidayBrush(e));
        canvas.setOnMousePressed(e -> Brushes.holidayBrushStart(e));
        canvas.setOnMouseReleased(e -> Brushes.onMouseReleased(e));
    }

    @FXML
    public void quadraticButton() {
        label1.setText(" y = A * x^2 + B * x + C");
        setTextFieldVisibility(true, true, true, "A", "B", "C", "0.5", "0", "0");
//        editHBox.setVisible(false);
        setBrushStatus();
        canvas.setCursor(Cursor.CROSSHAIR);
        canvas.toFront();
        canvas.setOnMouseDragged(e -> { if (e.getButton() == MouseButton.PRIMARY) Brushes.quadraticBrush(e); });
        canvas.setOnMousePressed(e -> { if (e.getButton() == MouseButton.PRIMARY) Brushes.quadraticBrush(e); });
        canvas.setOnMouseReleased(null);
    }

    @FXML
    public void drawRndRect() {
        label1.setPrefWidth(30);
        label2.setPrefWidth(30);
        label3.setPrefWidth(30);
        setTextFieldVisibility(true, true, true, "Number", "Max", "Min", "12", "50", "20");
//        editHBox.setVisible(false);

        setBrushStatus();
        int number = (int) Brushes.getParA();
        double max = Brushes.getParB(), min = Brushes.getParC();

        canvas.setCursor(Cursor.DEFAULT);
        Brushes.drawRndRect(number, max, min);
        label1.setText("Random rectangles of Number: " + number + ", max size: " + max + ", min size: " + min);

        canvas.setOnMousePressed(null);
        canvas.setOnMouseDragged(null);
        canvas.setOnMouseReleased(null);
    }

    public void floodFill() {
        SnapshotParameters sp = new SnapshotParameters();
        sp.setFill(Color.TRANSPARENT);

        canvas.setCursor(Cursor.DEFAULT);
        canvas.toFront();
        canvas.setOnMousePressed(null);
        canvas.setOnMouseDragged(null);
        canvas.setOnMouseReleased(e -> {
            WritableImage img = canvas.snapshot(sp, null);
            if (e.getButton() == MouseButton.PRIMARY)
                Brushes.floodFill(img, (int) e.getX(), (int) e.getY(), colorPickerFill.getValue());
        });
    }

    public void showGridButton() {
        if (pane.getChildren().contains(canvasGrid)) pane.getChildren().remove(canvasGrid);
        else {
            double w = canvas.getWidth(), h = canvas.getHeight();
            canvasGrid = new Canvas(w, h);
            pane.getChildren().addAll(canvasGrid);
            canvasGrid.setMouseTransparent(true);

            GraphicsContext gridGC = canvasGrid.getGraphicsContext2D();
            gridGC.setStroke(Color.LIGHTGREEN);
            gridGC.setLineWidth(1);
            gridGC.setLineDashes(.1f, 3.5f);
            for (double i = 0.5; i < Math.max(w, h); i += 20) {
                gridGC.strokeLine(i, 0.5, i, h);
                gridGC.strokeLine(0.5, i, w, i);
            }
        }
    }

    public void samplerButton(ActionEvent actionEvent) {
        canvas.setOnMousePressed(null);
        canvas.setOnMouseReleased(e -> getColor(e));
        canvas.setOnMouseDragged(null);
    }

    void getColor(MouseEvent e) {
        SnapshotParameters sp = new SnapshotParameters();
        sp.setFill(Color.TRANSPARENT);
        PixelReader pixelReader = canvas.snapshot(sp, null).getPixelReader();
        Color color = pixelReader.getColor((int) e.getX(), (int) e.getY());
        if (e.getButton() == MouseButton.PRIMARY) colorPickerStroke.setValue(color);
        if (e.getButton() == MouseButton.SECONDARY) colorPickerFill.setValue(color);
    }
}
