package fxgraph;

/**
 * My first Java program - learning javafx
 * Version: 0.1 @ 2016-9-6
 * Version: 0.2 @ 2016-10-6
 * Date started 2016-8-24
 * Author: Bing Sun
 * Updated: 2016-10-6 This version is working and with a lot of features implemented.
 *                    There are some bugs and weakness not fixed yet.
 *                    1. Draw rectangle not at the mouse cursor point.
 * Stopped developing due to the Canvas control does not support anti-aliasing off mode.
 */

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Main extends Application {
    public Stage window;

    @Override
    public void start(Stage primaryStage) throws Exception {
        window = primaryStage;
        Parent layout = FXMLLoader.load(getClass().getResource("fxgraph.fxml"));

        window.setTitle("JavaFX 8 test ground");
        Scene scene=new Scene(layout, 1000, 800);
        window.setScene(scene);
        window.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
