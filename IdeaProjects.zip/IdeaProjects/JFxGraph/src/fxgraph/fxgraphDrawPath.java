package fxgraph;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;

/**
 * Created by VHASFCSUNB on 9/6/2016.
 */
public class fxgraphDrawPath {
    private static GraphicsContext gc;

    public static void setGc(GraphicsContext gc) {
        fxgraphDrawPath.gc = gc;
    }

    public static void drawPath(MouseEvent e) {
        double x = e.getX(), y = e.getY();

        Color sColor, fColor;
        if (Brushes.getColorState() == ColorState.Random) {
            sColor = Color.rgb((int) (Math.random() * 256), (int) (Math.random() * 256), (int) (Math.random() * 256),
                    Math.random());
            fColor = Color.rgb((int) (Math.random() * 256), (int) (Math.random() * 256), (int) (Math.random() * 256),
                    Math.random());
        } else if (Brushes.getColorState() == ColorState.Position) {
            int r = Math.abs((int) e.getX() * 3) % 256, g = Math.abs((int) e.getY() % 256),
                    b = Math.abs((int) (e.getX() * 2 + e.getY()) % 256);
            sColor = Color.rgb(r, g, b);
            fColor = sColor;
        } else {
            sColor = Brushes.getStrokeColor();
            fColor = Brushes.getFillColor();
        }

        gc.setStroke(sColor);
        gc.setFill(fColor);
        double r = Brushes.getParA(), s = Brushes.getParB();

        Undo undo = new Undo(gc.getCanvas(), "Draw path");
        gc.beginPath();
        gc.moveTo(x, y);
        gc.lineTo(x + 50 - s, y);
        gc.lineTo(x + 70 - s, y - 50);
        gc.bezierCurveTo(x + 70 + 100 - s, y - 50 - r, x + 70 - 200, y - 50 - r, x - 20, y - 50);
        gc.closePath();
        gc.stroke();
        if (Brushes.getIsFill())
            gc.fill();

        double xmin = Utils.min(x, x + 50 - s, x + 70 - s, x + 70 + 100 - s, x + 70 - 200, x - 20),
                ymin = Utils.min(y, y - 50, y - 50 - r, y - 50 - r, y - 50);
        undo.End(new Bounds(xmin, ymin,
                Utils.max(x, x + 50 - s, x + 70 - s, x + 70 + 100 - s, x + 70 - 200, x - 20)-xmin,
                Utils.max(y, y - 50, y - 50 - r, y - 50 - r, y - 50)-ymin));
    }

    public static void startPath(MouseEvent e) {
        drawPath(e);
    }
}
