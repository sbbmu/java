package fxgraph;

import javafx.geometry.Point2D;
import javafx.scene.SnapshotParameters;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.PixelReader;
import javafx.scene.image.PixelWriter;
import javafx.scene.image.WritableImage;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.StrokeLineCap;
import javafx.scene.shape.StrokeLineJoin;
import javafx.scene.text.Font;
import javafx.scene.transform.Rotate;

/**
 * Created by VHASFCSUNB on 8/26/2016.
 */
enum ColorState {
    Position, Random, Fixed
}

public final class Brushes {
    private static double x0, y0, x1, y1;
    private static double parA, parB, parC, lwd;
    private static boolean isFill, isStroke, isRndLwd, isSelectionSet, isSHIFT;
    private static Color strokeColor, fillColor;
    private static ColorState colorState;
    private static Bounds selBounds = new Bounds();
    private static GraphicsContext gc;
    private static Undo undo;
    private static Bounds undoBounds;
    private DrawGC undoGC;

    public static void setUndoBounds(Bounds undoBounds) { Brushes.undoBounds = undoBounds; }

    public static void setGc(GraphicsContext gc) {
        Brushes.gc = gc;
    }

    public static boolean isSelectionSet() {
        return isSelectionSet;
    }

    public static void setIsSelectionSet(boolean isSelectionSet) {
        Brushes.isSelectionSet = isSelectionSet;
    }

    public static void setIsSHIFT(boolean isSHIFT) {
        Brushes.isSHIFT = isSHIFT;
    }

    public static void setIsStroke(boolean isStroke) {
        Brushes.isStroke = isStroke;
    }

    public static boolean getIsFill() {
        return isFill;
    }

    public static void setIsFill(boolean isFill) {
        Brushes.isFill = isFill;
    }

    public static ColorState getColorState() {
        return colorState;
    }

    public static void setColorState(ColorState cs) {
        colorState = cs;
    }

    public static double getLwd() {
        return lwd;
    }

    public static void setLwd(double lwd) {
        Brushes.lwd = lwd;
    }

    public static void setX1(double x1) {
        Brushes.x1 = x1;
    }

    public static void setY1(double y1) {
        Brushes.y1 = y1;
    }

    public static Color getStrokeColor() {
        return strokeColor;
    }

    public static void setStrokeColor(Color strokeColor) {
        Brushes.strokeColor = strokeColor;
    }

    public static Color getFillColor() {
        return fillColor;
    }

    public static void setFillColor(Color fillColor) {
        Brushes.fillColor = fillColor;
    }

    static double getParA() {
        return parA;
    }

    static void setParA(double parA) {
        Brushes.parA = parA;
    }

    static double getParB() {
        return parB;
    }

    static void setParB(double parB) {
        Brushes.parB = parB;
    }

    static double getParC() {
        return parC;
    }

    static void setParC(double parC) {
        Brushes.parC = parC;
    }

    /**
     * Clear background
     */
    static void GCClear(GraphicsContext gc) {
        gc.clearRect(0, 0, gc.getCanvas().getWidth(), gc.getCanvas().getHeight());
    }

    /**
     * setup canvas
     */
    private static void setGCStatus(MouseEvent e) {
        setGCLineWidth();
        setGCStrokeColor(e);
        setGCFillColor(e);
        gc.setLineCap(StrokeLineCap.ROUND);
        gc.setLineJoin(StrokeLineJoin.ROUND);
    }

    public static double getX0() {
        return x0;
    }

    public static void setX0(double x0) {
        Brushes.x0 = x0;
    }

    public static double getY0() {
        return y0;
    }

    public static void setY0(double y0) {
        Brushes.y0 = y0;
    }

    private static void setGCStrokeColor(MouseEvent e) {
        if (colorState == ColorState.Position) {
            gc.setStroke(Utils.positionColor(e));
        } else if (colorState == ColorState.Random) {
            gc.setStroke(Utils.randomColor());
        } else {
            gc.setStroke(strokeColor);
        }
    }

    private static void setGCFillColor(MouseEvent e) {
        if (colorState == ColorState.Position) {
            gc.setFill(Utils.positionColor(e));
        } else if (colorState == ColorState.Random) {
            gc.setFill(Utils.randomColor());
        } else {
            gc.setFill(getFillColor());
        }
    }

    private static void setGCLineWidth() {
        double lw;
        if (isRndLwd) lw = Math.random() * lwd;
        else lw = lwd;
        gc.setLineWidth(lw);
    }

    /**
     * selection
     */
    public static void selectOnMouseReleased(MouseEvent e) {
        double x = e.getX(), y = e.getY();

        selBounds.setX(Math.min(x, x0));
        selBounds.setY(Math.min(y, y0));
        selBounds.setW(Math.abs(x - x0));
        selBounds.setH(Math.abs(y - y0));
    }

    public static Bounds getSelectionBounds() {
        return selBounds;
    }

    public static WritableImage copyImage(Canvas canvas, Bounds selectionBounds) {
        SnapshotParameters sp = new SnapshotParameters();
        sp.setFill(Color.TRANSPARENT);
        WritableImage srcImage = canvas.snapshot(sp, null);
        PixelReader pixelReader = srcImage.getPixelReader();
        int w = (int) selectionBounds.getW(), h = (int) selectionBounds.getH();

        //Copy from source to destination pixel by pixel
        WritableImage destImage = new WritableImage(w, h);
        PixelWriter pixelWriter = destImage.getPixelWriter();

        for (int yi = 0; yi < h; yi++) {
            for (int xi = 0; xi < w; xi++) {
                Color color = pixelReader.getColor((int) selectionBounds.getX() + xi, (int) selectionBounds.getY() + yi);
                pixelWriter.setColor(xi, yi, color);
            }
        }
        return destImage;
    }

    /**
     * brushes
     */
    static void drawFreeHand(MouseEvent e) {
        double x = e.getX(), y = e.getY();
        gc.strokeLine(x0, y0, x, y);

        setX0(x);
        setY0(y);
        undoBounds = Bounds.maxBounds(undoBounds, x, y);
    }

    static void startFreeHand(MouseEvent e) {
        fxgraph.Cursor.Ellipse(gc.getCanvas(), lwd, lwd);
        setGCStatus(e);

        undo = new Undo(gc.getCanvas(), "free draw");// start a undo
        undoBounds = new Bounds(x0 - lwd / 2, y0 - lwd / 2, lwd, lwd);

        gc.strokeLine(x0, y0, x0, y0); //
    }

    static void onMouseReleased(MouseEvent e) {
        undo.End(Bounds.resize(undoBounds, lwd / 2 + .5)); // end the undo
    }

    static void drawErase(MouseEvent e) {
        double x = e.getX(), y = e.getY();
        gc.clearRect(x + 1, y + 1, parA, parB);
        undoBounds = Bounds.maxBounds(undoBounds, x + 1, y + 1);
        undoBounds = Bounds.resize(undoBounds, parA, parB);
    }

    static void startErase(MouseEvent e) {
        Cursor.Rectangle(gc.getCanvas(), parA, parB);
        double x = e.getX(), y = e.getY();

        undo = new Undo(gc.getCanvas(), "Erase");// start a undo
        undoBounds = new Bounds(x + 1, y + 1, parA, parB);

        gc.clearRect(x + 1, y + 1, parA, parB);
    }

    public static void drawEraseReleased(MouseEvent e) {
        undo.End(undoBounds);
    }

    static void lineOnMouseReleased(MouseEvent e, GraphicsContext gc2) {
        GCClear(gc2);
        int amount = (int) parA;
        double distance = parB;
        double x = e.getX(), y = e.getY();
        if (isSHIFT) {
            int theta = (int) (Math.atan((y - y0) / (x - x0)) * 180 / Math.PI / 45);
            y1 = theta * (x - x0) + y0;
            if (Math.abs(x - x0) < 10) {
                y1 = y;
                x = x0;
            }
            y = y1;
        }
        Point2D p0 = new Point2D(x0, y0), p1 = new Point2D(x, y), p3 = new Point2D(1, 0); // p3 is a vector on x axis
        double theta = p3.angle(p1.subtract(p0)), at = Math.toRadians(theta);  //  vector math for angles

        if (y0 < y) at = -at;
        double dx = distance * Math.sin(at), dy = distance * Math.cos(at);

        undo = new Undo(gc.getCanvas(), "Lines");
        double xm = e.getX(), ym = e.getY(), wm = 0, hm = 0;
        for (int i = 0; i < amount; i++) {
            double d = i - (amount - 1) / 2.0; // adjust center of line start points
            setGCStatus(e);
            gc.strokeLine(x0 + dx * d, y0 + dy * d, x + dx * d, y + dy * d);
            xm = Utils.min(xm, x0 + dx * d, x + dx * d);
            ym = Utils.min(ym, y0 + dy * d, y + dy * d);
            wm = Utils.max(wm, x0 + dx * d, x + dx * d);
            hm = Utils.max(hm, y0 + dy * d, y + dy * d);
        }
        undo.End(Bounds.resize(new Bounds(xm, ym, wm - xm, hm - ym), lwd / 2 + .5));
        e.consume();
    }

    static void drawLine(MouseEvent e, GraphicsContext gc2) {
        double x = e.getX(), y = e.getY();
        y1 = y;
        GCClear(gc2);
        gc2.setStroke(Color.BLACK);
        gc2.setLineWidth(1);
        gc2.setLineDashes(10f);
        if (isSHIFT) {
//            int alpha = (int)(Math.acos((x-x0)/Math.sqrt((x-x0)*(x-x0)+(y-y0)*(y-y0)))*180/Math.PI);
            int theta = (int) (Math.atan((y - y0) / (x - x0)) * 180 / Math.PI / 45);
            y1 = theta * (x - x0) + y0;
//            System.out.println(alpha+ " " +theta);
            if (Math.abs(x - x0) < 10) {
                y1 = y;
                x = x0;
            }
        }
        gc2.strokeLine(x0, y0, x, y1);
    }

    static void gcSetRotate(GraphicsContext gc, double angle, double cx, double cy) {
        Rotate r = new Rotate(angle, cx, cy);
        gc.setTransform(r.getMxx(), r.getMyx(), r.getMxy(), r.getMyy(), r.getTx(), r.getTy());
    }

    // return bounds of a rectangle after rotated, used for undo
    static Bounds getRotatedBounds(double bx, double by, double bw, double bh, double rotation) {
        Rectangle r = new Rectangle(bx, by, bw, bh);
        r.getTransforms().add(new Rotate(rotation, bx, by));
        r.localToParent(bx, by);
        javafx.geometry.Bounds b = r.getBoundsInParent();

        return new Bounds(b.getMinX(), b.getMinY(), b.getWidth(), b.getHeight());
    }

    static Bounds getRotatedRect(double bx, double by, double bw, double bh, double rotation) {
        Rectangle r = new Rectangle(bx, by, bw, bh);
        r.getTransforms().add(new Rotate(rotation, bx, by));
        r.localToParent(bx, by);
        return new Bounds(r.getX(), r.getY(), r.getWidth(), r.getHeight());
    }

    static void rectOnMouseReleased(MouseEvent e, GraphicsContext gc2) {
        setGCStatus(e);
        if (isFill | isStroke) {
            undo = new Undo(gc.getCanvas(), "Rect");
            double bx = selBounds.getX(), by = selBounds.getY(), bw = selBounds.getW(), bh = selBounds.getH();

            gc.save();
            gcSetRotate(gc, parC, bx, by);

            if (isFill) gc.fillRect(bx, by, bw, bh);
            if (isStroke) gc.strokeRect(bx, by, bw, bh);

            gc.restore();
//            Bounds b=getRotatedBounds(bx, by, bw, bh, parC);
//            strokeRect(b);
            undo.End(Bounds.resize(getRotatedBounds(bx, by, bw, bh, parC), lwd / 2 + .5));
        }
        GCClear(gc2);
    }

    // draw temporary rectangle on a second canvas
    static void drawRect(MouseEvent e, GraphicsContext gc2) {
        double x = e.getX(), y = e.getY();
        double bx, by, bw, bh;
        double gcW = gc2.getCanvas().getWidth(), gcH = gc2.getCanvas().getHeight();
        double rad = parC / 180 * Math.PI;
        x = Bounds.keepBounds(x, 0, gcW);
        y = Bounds.keepBounds(y, 0, gcH);

        double x1 = getRotatedRect(x, y, 0, 0, -parC).getX(), y1 = getRotatedRect(x, y, 0, 0, -parC).getY(); // rotate cursor point back
        double w = Math.abs(x1 - x0), h = Math.abs(y1 - y0);
//        selBounds = new Bounds(Math.min(x1, x0), Math.min(y1, y0), Math.abs(x1 - x0), Math.abs(y1 - y0));
//        double h = (Math.abs(y - y0) - Math.abs(x - x0) * Math.tan(rad)) * Math.cos(rad);
//        double w = Math.abs(x - x0) / Math.cos(rad) + h * Math.tan(rad);
        selBounds = getRotatedRect(Math.abs(Math.min(x1, x0)), Math.abs(Math.min(y1, y0)), Math.abs(w), Math.abs(h), parC);
//Utils.logO(x1,y1,w,h);
//        System.out.println(getRotatedRect(x,y,0,0,-parC));
        if (parA != 0 & parB != 0) {
            selBounds.setW(parA);
            selBounds.setH(parB);
        }
        bx = selBounds.getX();
        by = selBounds.getY();
        bw = selBounds.getW();
        bh = selBounds.getH();

        GCClear(gc2);
        gc2.setStroke(Color.BLACK);
        gc2.setLineWidth(0.7);
        gc2.setLineDashes(5f);

        gc2.save();
        gcSetRotate(gc2, parC, bx, by);
        gc2.strokeRect(bx, by, bw, bh);
        gc2.restore();

//        Utils.logO(selBounds.toString());
    }

    static void ovalOnMouseReleased(MouseEvent e, GraphicsContext gc2) {
        setGCStatus(e);
        if (isFill | isStroke) {
            undo = new Undo(gc.getCanvas(), "Oval");
            double bx = selBounds.getX(), by = selBounds.getY(), bw = selBounds.getW(), bh = selBounds.getH();
            gc.save();
            gcSetRotate(gc, parC, bx, by);

            if (isFill) gc.fillOval(bx, by, bw, bh);
            if (isStroke) gc.strokeOval(bx, by, bw, bh);

            gc.restore();

            undo.End(Bounds.resize(getRotatedBounds(bx, by, bw, bh, parC), lwd / 2 + .5));
        }
        GCClear(gc2);
    }

    static void drawOval(MouseEvent e, GraphicsContext gc2) {
        double x = e.getX(), y = e.getY();
        double bx, by, bw, bh;
        double gcW = gc2.getCanvas().getWidth(), gcH = gc2.getCanvas().getHeight();
        double rad = parC / 180 * Math.PI;
        x = Bounds.keepBounds(x, 0, gcW);
        y = Bounds.keepBounds(y, 0, gcH);

        selBounds = new Bounds(Math.min(x, x0), Math.min(y, y0), Math.abs(x - x0), Math.abs(y - y0));
//        double h = Math.abs((Math.abs(y - y0) - Math.abs(x - x0) * Math.tan(rad)) * Math.cos(rad));
//        double w = Math.abs(x - x0) / Math.cos(rad) + h * Math.tan(rad);
//        selBounds = getRotatedRect(Math.min(x, x0), Math.min(y , y0), w, h, parC);
        if (parA != 0 & parB != 0) {
            selBounds.setW(parA);
            selBounds.setH(parB);
        }

        GCClear(gc2);
        gc2.setStroke(Color.BLACK);
        gc2.setLineWidth(0.7);
        gc2.setLineDashes(5f);

        gc2.save();
        bx = selBounds.getX();
        by = selBounds.getY();
        bw = selBounds.getW();
        bh = selBounds.getH();

        gcSetRotate(gc2, parC, bx, by);

        gc2.strokeOval(bx, by, bw, bh);
        gc2.restore();
    }

    static void polyBrush(MouseEvent e) {
        setGCStatus(e);
        int nVertices = (int) parA;
        double r = parB, rotation = parC / 180 * Math.PI;
        double centerX = e.getX(), centerY = e.getY();
        double angle = Math.PI / nVertices * 2;

        PointsArray p = new PointsArray();
        for (int i = 0; i < nVertices; i++) {
            double x = centerX + Math.cos(i * angle - rotation) * r; // 5 point star rotation=angle/2= 18 degrees
            double y = centerY + Math.sin(i * angle - rotation) * r;
            p.add(x, y);
        }

        if (isFill | isStroke) {
            undo = new Undo(gc.getCanvas(), "Polygon");
            if (isFill) gc.fillPolygon(p.getaX(), p.getaY(), p.size());
            if (isStroke) gc.strokePolygon(p.getaX(), p.getaY(), p.size());
            undo.End(Bounds.resize(Bounds.maxBounds(p), lwd / 2 + 1.5));
        }
    }

    static void starBrush(MouseEvent e) {
        int nVertices = (int) parA;
        double outerR = parB, innerR = outerR / 3, rotation = parC / 180 * Math.PI;
        setGCStatus(e);
        PointsArray p = computeStar(e.getX(), e.getY(), nVertices, outerR, innerR, rotation);

        if (isFill | isStroke) {
            undo = new Undo(gc.getCanvas(), "Star");
            if (isFill) gc.fillPolygon(p.getaX(), p.getaY(), p.size());
            if (isStroke) gc.strokePolygon(p.getaX(), p.getaY(), p.size());
            undo.End(Bounds.resize(Bounds.maxBounds(p), lwd / 2 + 1.5));
        }
    }

    private static PointsArray computeStar(double centerX, double centerY, int nVertices, double outerR, double innerR, double rotation) {
        PointsArray p = new PointsArray();
        double angle = Math.PI / nVertices;

        for (int i = 0; i < 2 * nVertices; i++) {
            double r = (i % 2 == 0) ? outerR : innerR;
            double x = centerX + Math.cos(i * angle - rotation) * r; // 5 point star rotation=angle/2= 18 degrees
            double y = centerY + Math.sin(i * angle - rotation) * r;
            p.add(x, y);
        }
        return p;
    }

    public static void sineBrushStart(MouseEvent e) {
        fxgraph.Cursor.Ellipse(gc.getCanvas(), lwd, lwd);
        setGCStatus(e);

        undo = new Undo(gc.getCanvas(), "Sine wave");// start a undo
        undoBounds = new Bounds(x0 - lwd / 2, y0 - lwd / 2, lwd, lwd);
    }

    static void sineBrush(MouseEvent e) {
        int a = (int) parA;
        double b = parB, c = parC / 180 * Math.PI;
        double Y = isSHIFT ? y1 : e.getY();
        double x = e.getX(), y = a * Math.sin(b * x / 10.0 + c) + Y;
        setGCStatus(e);
        gc.setLineCap(StrokeLineCap.ROUND);
        gc.setLineJoin(StrokeLineJoin.ROUND);
        if (x1 != x0) gc.strokeLine(x0, y0, x, y);
        setX0(x);
        setY0(y);
        undoBounds = Bounds.maxBounds(undoBounds, x, y);
    }

    static void roseBrush(MouseEvent e) {
        setGCStatus(e);

        int k = (int) parA;
//        if (k % 2 == 0) k /= 2;
        double a = parB, rotation = parC / 180 * Math.PI;
        PointsArray p = new PointsArray();
        for (double i = 0; i <= Math.PI * 2; i += 0.02) {
            double x = a * Math.cos(k * i) * Math.cos(i + rotation) + e.getX();
            double y = a * Math.cos(k * i) * Math.sin(i + rotation) + e.getY();
            p.add(x, y);
        }

        if (isFill | isStroke) {
            undo = new Undo(gc.getCanvas(), "Rose");
            if (isFill) gc.fillPolygon(p.getaX(), p.getaY(), p.size());
            if (isStroke) gc.strokePolygon(p.getaX(), p.getaY(), p.size());
            undo.End(Bounds.resize(Bounds.maxBounds(p), lwd / 2 + 1.5));
        }
    }

    static void hozMirrorBrushStart(MouseEvent e) {
        fxgraph.Cursor.Ellipse(gc.getCanvas(), lwd, lwd);
        setGCStatus(e);

        double x = e.getX(), y = e.getY();
        double w = gc.getCanvas().getWidth();

        undo = new Undo(gc.getCanvas(), "Horiz Mirror");
        undoBounds = new Bounds(x, y, 0, 0);
        undoBounds = Bounds.maxBounds(undoBounds, Math.abs(w - x), y);

        gc.strokeLine(x, y, x, y);
        gc.strokeLine(Math.abs(w - x), y, Math.abs(w - x), y);
        setX0(x);
        setY0(y);
    }

    static void hozMirrorBrush(MouseEvent e) {
        setGCStatus(e);

        double x = e.getX(), y = e.getY();
        double w = gc.getCanvas().getWidth();
        gc.strokeLine(x0, y0, x, y);
        gc.strokeLine(Math.abs(w - x0), y0, Math.abs(w - x), y);

        setX0(x);
        setY0(y);
        undoBounds = Bounds.maxBounds(undoBounds, x, y);
        undoBounds = Bounds.maxBounds(undoBounds, Math.abs(w - x), y);
    }

    static void vertMirrorBrush(MouseEvent e) {
        double x = e.getX(), y = e.getY();
        double h = gc.getCanvas().getHeight();

        setGCStatus(e);
        gc.setLineCap(StrokeLineCap.ROUND);
        gc.setLineJoin(StrokeLineJoin.ROUND);
        gc.strokeLine(x0, y0, x, y);
        gc.strokeLine(x0, Math.abs(h - y0), x, Math.abs(h - y));
        setX0(x);
        setY0(y);
    }

    public static void fourMirrorStart(MouseEvent e) {
        setGCStatus(e);
        undo = new Undo(gc.getCanvas(), "Four Mirror");
        undoBounds = new Bounds(0, 0, gc.getCanvas().getWidth(), gc.getCanvas().getHeight());
        setX0(e.getX());
        setY0(e.getY());
    }

    static void fourMirrorBrush(MouseEvent e) {
        double x = e.getX(), y = e.getY();
        double w = gc.getCanvas().getWidth(), h = gc.getCanvas().getHeight();

        setGCStatus(e);

        gc.strokeLine(x0, y0, x, y);
        gc.strokeLine(x0, Math.abs(h - y0), x, Math.abs(h - y));
        gc.strokeLine(Math.abs(w - x0), y0, Math.abs(w - x), y);
        gc.strokeLine(Math.abs(w - x0), Math.abs(h - y0), Math.abs(w - x), Math.abs(h - y));
        setX0(x);
        setY0(y);
    }

    static void paintText(MouseEvent e, String text, String font, double fontSize) {
        double x = e.getX(), y = e.getY();
        setGCStatus(e);
        if (isFill | isStroke) {

            undo = new Undo(gc.getCanvas(), "Text");
            gc.setFont(new Font(font, fontSize));
            if (isStroke) gc.strokeText(text, x, y);
            if (isFill) gc.fillText(text, x, y);
            // http://stackoverflow.com/questions/13015698/how-to-calculate-the-pixel-width-of-a-string-in-javafx
            float width = com.sun.javafx.tk.Toolkit.getToolkit().getFontLoader().computeStringWidth(text, gc.getFont());
            float height = com.sun.javafx.tk.Toolkit.getToolkit().getFontLoader().getFontMetrics(gc.getFont()).getLineHeight();
            float descent = com.sun.javafx.tk.Toolkit.getToolkit().getFontLoader().getFontMetrics(gc.getFont()).getDescent();
//            float ascent=com.sun.javafx.tk.Toolkit.getToolkit().getFontLoader().getFontMetrics(gc.getFont()).getMaxAscent();

            undo.End(Bounds.resize(new Bounds(x, y - height + descent, width, height), lwd / 2));
//            gc.strokeRect(x, y-height+descent, width, height);
//            System.out.println(ascent+", d="+descent+", h="+height+", w="+width);
        }
    }

    static void drawSparkles(MouseEvent e) {
        double x = e.getX(), y = e.getY();
        double number = parA, spread = parB, size = parC;
        undo = new Undo(gc.getCanvas(), "Sparkles");
        for (int i = 0; i < number; i++) {
            setGCStatus(e);
            double theta = Math.random() * Math.PI * 2;
            double r = spread * Math.random();
            if (isFill) gc.fillOval(x + Math.cos(theta) * r, y + Math.sin(theta) * r, size, size);
            if (isStroke) gc.strokeOval(x + Math.cos(theta) * r, y + Math.sin(theta) * r, size, size);
        }
        Bounds undoBounds = new Bounds(x - spread - size / 2, y - spread - size / 2, spread * 2 + size, spread * 2 + size);
        undo.End(Bounds.resize(undoBounds, lwd / 2 + .5));
    }

    public static void holidayBrushStart(MouseEvent e) {
        double x = e.getX(), y = e.getY();
        undo = new Undo(gc.getCanvas(), "Holiday");
        undoBounds = new Bounds(x, y, 0, 0);
        setX0(x);
        setY0(y);
    }

    static void holidayBrush(MouseEvent e) {
        double x = e.getX(), y = e.getY();
        int r = Math.abs((int) x % 256), g = Math.abs((int) y % 256), b = Math.abs((int) (x * 2 + y) % 256);
        gc.setStroke(Color.rgb(r, g, b));
        gc.setLineWidth(Math.sin((x / 2 * Math.sqrt(y))) * 5);
        gc.strokeLine(x0, y0, x, y);
        gc.setFill(Color.rgb((int) (Math.random() * 256), (int) (Math.random() * 256), (int) (Math.random() * 256), Math.random()));
        gc.fillOval(x - Math.random() * 2, y - Math.random() * 2, Math.random() * 30, Math.random() * 30);
        setX0(x);
        setY0(y);
        undoBounds = Bounds.maxBounds(undoBounds, x - 30, y - 30);
        undoBounds = Bounds.maxBounds(undoBounds, x + 30, y + 30);
//        strokeRect(undoBounds);
    }

    static void drawRndRect(int number, double maxSize, double minSize) {
        double x1, y1, w, h;
        undo = new Undo(gc.getCanvas(), "Random rectangle");
        for (int i = 0; i < number; i++) {
            x1 = (int) (Math.random() * gc.getCanvas().getWidth());
            y1 = (int) (Math.random() * gc.getCanvas().getHeight());
            w = (int) (Math.random() * Math.abs(maxSize - minSize) + minSize);
            h = (int) (Math.random() * Math.abs(maxSize - minSize) + minSize);

            MouseEvent e = new MouseEvent(MouseEvent.MOUSE_MOVED, x1, y1, x1, y1, MouseButton.NONE, 1,
                    false, false, false, false, false, false, false, false, false, false, null);

            setGCStatus(e);
            if (isStroke) gc.strokeRect(x1, y1, w, h);
            if (isFill) gc.fillRect(x1, y1, w, h);
        }
        undo.End(0, 0, (int) gc.getCanvas().getWidth(), (int) gc.getCanvas().getHeight());
    }

    static void quadraticBrush(MouseEvent e) {
        double x0 = e.getX(), y0 = e.getY();
        double a = parA, b = parB, c = parC;
        double x1 = 0, y1 = 0, scale = 20;
        Color sColor;

        // stroke color
        if (colorState == ColorState.Random) {
            sColor = Utils.randomColor();
        } else if (colorState == ColorState.Position) {
            sColor = Utils.positionColor(e);
        } else {
            sColor = strokeColor;
        }

        setGCStatus(e);
        gc.setStroke(sColor);

        undo = new Undo(gc.getCanvas(), "Quadratics");
        undoBounds = new Bounds(x0, y0, 0, 0);
        for (int i = -12; i <= 12; i++) { // single quadratic
            double x = i / 4.0;
            double y = -a * x * x + b * x + c;
            if (i == -12) {
                x1 = x;
                y1 = y;
            }

            gc.strokeLine(x * scale + x0, y * scale + y0, x1 * scale + x0, y1 * scale + y0);
            x1 = x;
            y1 = y;
            undoBounds = Bounds.maxBounds(undoBounds, x1 * scale + x0, y1 * scale + y0);
        }
        undo.End(undoBounds);
    }

    public static void floodFill(WritableImage image, int x, int y, Color fillColor) {
        undo = new Undo(gc.getCanvas(), "Flood fill");
        FloodFiller ff = new FloodFiller(image, fillColor);
        ff.fill(x, y);
        gc.drawImage(image, 0, 0);
        undo.End(ff.getUndoBounds()); // end the undo
    }

    private static void strokeRect(Bounds b) {
        double x = b.getX(), y = b.getY(), w = b.getW(), h = b.getH();
        gc.strokeRect(x, y, w, h);
        Utils.log(x, y, w, h);
    }

}

