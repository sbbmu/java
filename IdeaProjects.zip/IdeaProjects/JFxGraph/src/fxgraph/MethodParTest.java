package fxgraph;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

/**
 * Created by VHASFCSUNB on 9/23/2016.
 */

interface DrawMethod { //Command patter
    void Draw(Bounds par);
}

class DrawGC implements DrawMethod {
    private GraphicsContext gc;
    private Canvas canvas;

    public DrawGC(GraphicsContext g) {
        gc = g;
        canvas = gc.getCanvas();
    }

    public void strokeRect(Bounds b) {
        gc.strokeRect(b.getX(), b.getY(), b.getW(), b.getH());
    }

    public void fillRect(Bounds b) {
        gc.fillRect(b.getX(), b.getY(), b.getW(), b.getH());

    }
    public void clearRect(Bounds b) {
        gc.clearRect(b.getX(), b.getY(), b.getW(), b.getH());
    }

    @Override public void Draw(Bounds par) { }

    public void callCommand(DrawMethod command, Bounds b) {
       callCommand(command,b,"Object "+b.getX()+", "+b.getY());
    }
    public void callCommand(DrawMethod command, Bounds b,String name) {
        double x = b.getX(), y = b.getY(), w = b.getW(), h = b.getH();
        Undo undo = new Undo(canvas, name);// save current image with a name
        command.Draw(b);
        undo.End(new Bounds(x, y, w, h)); //save modified image, trim to the size
    }

}

public class MethodParTest extends Application {
    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage window) throws Exception {
        Canvas canvas = new Canvas(400, 400);
        GraphicsContext gc = canvas.getGraphicsContext2D();
        gc.setStroke(Color.RED);
        gc.setFill(Color.LAVENDER);

        DrawGC s = new DrawGC(gc);
//        s.setGc(gc);
        s.callCommand(e -> s.strokeRect(e), new Bounds(10, 50, 200, 200));
        s.callCommand(e -> s.fillRect(e), new Bounds(50, 60, 50, 50));

        VBox vbox = new VBox(10);
        vbox.getChildren().addAll(canvas);

        window.setScene(new Scene(vbox, 500, 500));
        window.show();
    }
}
