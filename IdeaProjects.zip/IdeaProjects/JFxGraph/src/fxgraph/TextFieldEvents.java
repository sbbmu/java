package fxgraph;

import javafx.geometry.Bounds;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;

/**
 * Created by VHASFCSUNB on 9/21/2016.
 */
public class TextFieldEvents {
    private double textFieldValueByDragging(MouseEvent e, double min, double max) {
        TextField source = (TextField) e.getSource();
        double val;
        try {
            val = Double.parseDouble(source.getText());
        } catch (NumberFormatException ex) {
            val = 1.0;
        }
        Bounds bounds = source.localToScreen(source.getBoundsInLocal());
        double tX = bounds.getMinX() + bounds.getWidth() / 2.0;
        double mX = e.getScreenX();

        double newVal = val + (mX - tX) / 30.0;
        if (newVal < min) newVal = min;
        if (newVal > max) newVal = max;

        return newVal;
    }

    void setTextFieldValueByDragging(MouseEvent e, int min, int max) {
        double newValue = textFieldValueByDragging(e, (double) min, (double) max);
        ((TextField) e.getSource()).setText(String.valueOf((int) newValue));
    }

    void setTextFieldValueByDragging(MouseEvent e, double min, double max) {
        double newValue = textFieldValueByDragging(e, min, max);
        ((TextField) e.getSource()).setText(String.format("%3.1f", newValue));
    }

}
