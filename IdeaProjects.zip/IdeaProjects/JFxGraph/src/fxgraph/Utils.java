package fxgraph;

import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

import java.util.ArrayList;
import java.util.DoubleSummaryStatistics;

/**
 * Created by Bing Sun1 on 9/4/2016.
 */
public class Utils {
    /**
     * Helper functions -- log to console
     */
    public static String log(String p, String... v) {
        for (String s : v) p += ", " + s;
//        System.out.println(p);
        return p;
    }
    public static String logO(String p, String... v) {
        String ps=log(p,v);
        System.out.println(ps);
        return ps;
    }
    public static String log(double p, double... v) {
        String ps = String.valueOf(p);
        for (double s : v) ps += ", " + String.valueOf(s);
//        System.out.println(ps);
        return ps;
    }
    public static String logO(double p, double... v) {
        String ps=log(p,v);
        System.out.println(ps);
        return ps;
    }

    public static boolean isInRect(MouseEvent e, Rectangle rectangle) {
        return isInRect(e, rectangle.getX(), rectangle.getY(), rectangle.getWidth(), rectangle.getHeight());
    }

    public static boolean isInRect(MouseEvent e, double x1, double y1, double selectionWidth, double selectionHeight) {
        double x = e.getX(), y = e.getY();
        return x >= x1 & x <= x1 + selectionWidth & y >= y1 & y <= y1 + selectionHeight;
    }

    static Color randomColor() {
        return Color.rgb((int) (Math.random() * 256), (int) (Math.random() * 256), (int) (Math.random() * 256),
                Math.random());
    }

    static Color positionColor(MouseEvent e) {
        int r, g, b, a;
        if (e != null) {
            r = Math.abs((int) e.getX() * 3) % 256;
            g = Math.abs((int) e.getY() % 256);
            b = Math.abs((int) (e.getX() * 2 + e.getY()) % 256);
            a = 1;
        } else {
            r = 0;
            g = 0;
            b = 0;
            a = 1;
        }
        return (Color.rgb(r, g, b, a));
    }

    public static double min(double x, double... y) {
        double result = x;
        for (double i : y) {
            result = Math.min(result, i);
        }
        return result;
    }
    public static double min(double[] x){
        double result=x[0];
        for (int i = 1; i < x.length; i++) {
            result=Math.min(result,x[i]);
        }
        return result;
    }
    public static double min(ArrayList<Double> x){
        double result=x.get(0);
        for (int i = 1; i < x.size(); i++) {
            result=Math.min(result,x.get(i));
        }
        return result;
    }
    public static double max(double x, double... y) {
        double result = x;
        for (double i : y) {
            result = Math.max(result, i);
        }
        return result;
    }
    public static double max(ArrayList<Double> x){
        double result=x.get(0);
        for (int i = 1; i < x.size(); i++) {
            result=Math.max(result,x.get(i));
        }
        return result;
    }
    public static double max(double[] x){
        double result=x[0];
        for (int i = 1; i < x.length; i++) {
            result=Math.max(result,x[i]);
        }
        return result;
    }

}
