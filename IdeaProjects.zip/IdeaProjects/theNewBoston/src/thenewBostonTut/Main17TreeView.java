package thenewBostonTut;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 * Created by vhasfcsunb on 8/17/2016.
 */
public class Main17TreeView extends Application {
    Button btn, btn2;
    Stage window;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        window = primaryStage;

        TableColumn<tableViewProduct,String> nameCol=new TableColumn<>("Name");
        nameCol.setMinWidth(200);
        nameCol.setCellValueFactory(new PropertyValueFactory<>("name"));

        TableColumn<tableViewProduct,String> priceCol=new TableColumn<>("Price");
        priceCol.setMinWidth(100);
        priceCol.setCellValueFactory(new PropertyValueFactory<>("price"));
        TableColumn<tableViewProduct,String> quantityCol=new TableColumn<>("Quantity");
        quantityCol.setMinWidth(100);
        quantityCol.setCellValueFactory(new PropertyValueFactory<>("quantity"));

        TableView<tableViewProduct> table=new TableView<>();
        table.setItems(getProduct());
        table.getColumns().addAll(nameCol,priceCol,quantityCol);


        btn = new Button("Button 1");
        btn.setOnAction(e -> System.out.println("I am Button 1"));
        btn2 = new Button("Button 2");
        btn2.setOnAction(e -> System.out.println("I am Button 2"));

        HBox layout = new HBox(10);
        layout.setPadding(new Insets(10, 10, 10, 10));
        layout.setAlignment(Pos.CENTER);
        layout.getChildren().addAll(btn, btn2);

        VBox vbox=new VBox(10);
        vbox.setAlignment(Pos.CENTER);
        vbox.getChildren().addAll(table,layout);

        window.setTitle("JavaFx Table View Application");
        window.setScene(new Scene(vbox, 400, 300));
        window.show();
    }

    public ObservableList<tableViewProduct> getProduct() {
        ObservableList<tableViewProduct> products = FXCollections.observableArrayList();
        products.add(new tableViewProduct("Laptop", 859, 20));
        products.add(new tableViewProduct("Bouncy ball", 2.49, 100));
        products.add(new tableViewProduct("Toilet", 99.0, 280));
        products.add(new tableViewProduct("The Notebook DVD", 19.99, 18));
        products.add(new tableViewProduct("Corn", 1.49, 200));
        return products;
    }
}
