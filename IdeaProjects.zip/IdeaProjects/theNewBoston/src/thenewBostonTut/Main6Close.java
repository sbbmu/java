package thenewBostonTut;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

/**
 * Created by vhasfcsunb on 8/11/2016.
 */
public class Main6Close extends Application {
    Button btn, btn2;
    Stage window;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        window=primaryStage;
        btn = new Button("Click me!");
        btn.setOnAction(e -> closeProgram());
        btn2 = new Button("Button 2");
        btn2.setOnAction(e -> System.out.println("I am Button 2"));

        HBox layout = new HBox();
        layout.getChildren().addAll(btn, btn2);
        layout.setSpacing(10);


        Scene scene = new Scene(layout, 400, 300);
        window.setTitle("Test JavaFx 1");
        window.setScene(scene);
        window.show();
    }

    private void closeProgram() {
        System.out.println("File saved!");
        window.close();
    }
}
