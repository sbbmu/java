package thenewBostonTut;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ComboBox;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;


/**
 * Created by vhasfcsunb on 8/17/2016.
 */
public class Main10CheckBox extends Application {
    Button btn, btn2;
    Stage window;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        window = primaryStage;

        //Check boxes
        CheckBox cBox1 = new CheckBox("Tuna");
        cBox1.setSelected(true);
        CheckBox cBox2 = new CheckBox("Bacon");

        // choice box
        ChoiceBox<String> choiceBox = new ChoiceBox<>();
        choiceBox.getItems().addAll("Apple", "Banana", "Orange");
        choiceBox.setValue("Apple");

        //listen for selection changes
        choiceBox.getSelectionModel().selectedItemProperty().addListener(
                (v, oldValue,newValue) -> {
                    System.out.println(newValue);
                });

        //comboBox
        ComboBox<String> comboBox=new ComboBox<>();
        comboBox.getItems().addAll("Meatball","Ham","Turkey","Steak");
        comboBox.setEditable(true);
        comboBox.setPromptText("What kind of meat you want?");
        comboBox.setOnAction(e->{
            System.out.println("ComboBox selection: "+ comboBox.getValue());
        });


        VBox order = new VBox(10);
        order.setAlignment(Pos.CENTER);
        order.setPadding(new Insets(10, 10, 10, 10));
        order.getChildren().addAll(cBox1, cBox2, choiceBox,comboBox);


        btn = new Button("Order Now");
        btn.setOnAction(e -> handleOptions(cBox1, cBox2, choiceBox,comboBox));
        btn2 = new Button("Cancel");
        btn2.setOnAction(e -> {
            System.out.println("Good bye.");
            window.close();
        });

        HBox buttonBox = new HBox(10);
        buttonBox.setPadding(new Insets(10, 10, 10, 10));
        buttonBox.setAlignment(Pos.CENTER);
        buttonBox.setStyle("-fx-border-color: black");
        buttonBox.getChildren().addAll(btn, btn2);

        VBox layout = new VBox(20);
        layout.getChildren().addAll(order, buttonBox);

        window.setTitle("JavaFx Application");
        window.setScene(new Scene(layout, 400, 300));
        window.show();
    }

    private void handleOptions(CheckBox cBox1, CheckBox cBox2, ChoiceBox<String> choice,ComboBox<String>comboBox) {
        String s = "";
        if (cBox1.isSelected())
            s += "Tuna ";
        if (cBox2.isSelected()) s += "Bacon ";
        s += choice.getValue() + " " + comboBox.getValue();
        AlertBox.display("Bucky's meat sub", "User ordered: " + s);

    }
}
