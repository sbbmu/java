package thenewBostonTut;

import javafx.beans.InvalidationListener;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;

/**
 * Created by vhasfcsunb on 8/18/2016.
 */
public class Person {
    private StringProperty firstName= new SimpleStringProperty(this,"firstName","");

    // return the object, can be used to add listener
    public StringProperty firstNameProperty() {
        return firstName;
    }

    // set value
    public void setFirstName(String firstName) {
        this.firstName.set(firstName);
    }
    // get the value of firstName, ie, "bucky"
    public String getFirstName() {
        return firstName.get();
    }

}
