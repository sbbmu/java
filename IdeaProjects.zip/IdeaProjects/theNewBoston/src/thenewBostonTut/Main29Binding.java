package thenewBostonTut;

import javafx.application.Application;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

/**
 * Created by vhasfcsunb on 8/18/2016.
 */
public class Main29Binding extends Application {
    Button btn, btn2;
    Stage window;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        window = primaryStage;

        IntegerProperty x=new SimpleIntegerProperty(3);
        IntegerProperty y=new SimpleIntegerProperty();
        y.bind(x.multiply(10));


        btn = new Button("set x=10");
        btn.setOnAction(e -> {
            x.setValue(10);
            System.out.println("x:"+x.getValue()+ " "+ "y: "+y.getValue());
        });
        btn2 = new Button("set x=2");
        btn2.setOnAction(e -> {
            x.setValue(2);
            System.out.println("x:"+x.getValue()+ " "+ "y: "+y.getValue());
        });

        HBox layout = new HBox(10);
        layout.setPadding(new Insets(10, 10, 10, 10));
        layout.setAlignment(Pos.CENTER);
        layout.getChildren().addAll(btn, btn2);

        window.setTitle("JavaFx Application");
        window.setScene(new Scene(layout, 400, 300));
        window.show();
    }
}
