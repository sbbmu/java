package thenewBostonTut;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.Border;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

/**
 * Created by vhasfcsunb on 8/11/2016.
 */
public class Main3 extends Application {
    Button btn, btn2;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        btn = new Button("Click me!");
        btn.setOnAction(e -> System.out.println("I am an lambda expression"));
        btn2 = new Button("Button 2");
        btn2.setOnAction(e -> System.out.println("I am Button 2"));

        HBox layout = new HBox();
        layout.getChildren().addAll(btn, btn2);
        layout.setSpacing(10);


        Scene scene = new Scene(layout, 400, 300);
        primaryStage.setTitle("Test JavaFx 1");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}
