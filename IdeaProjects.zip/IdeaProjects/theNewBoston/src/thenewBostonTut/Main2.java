package thenewBostonTut;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

/**
 * Created by vhasfcsunb on 8/11/2016.
 */
public class Main2 extends Application implements EventHandler<ActionEvent> {
    Button btn,btn2;
    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {

        btn=new Button("Click me!");
        btn.setOnAction(this);
        btn2=new Button("Button 2");
        btn2.setOnAction(this);

        HBox layout=new HBox();
        layout.getChildren().addAll(btn,btn2);
        layout.setSpacing(10);
        //layout.setBorder(10);

        Scene scene=new Scene(layout, 400,300);
        primaryStage.setTitle("Test JavaFx 1");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    @Override
    public void handle(ActionEvent event) {
        if(event.getSource()==btn){
            System.out.println("OOOOOooooooooooooo");
        }
        if(event.getSource()==btn2){
            System.out.println("you clicked button1 2!");
        }
    }
}
