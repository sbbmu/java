package thenewBostonTut;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

/**
 * Created by vhasfcsunb on 8/18/2016.
 */
public class Main28Properties extends Application {
    Button btn, btn2;
    Stage window;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        window = primaryStage;

        Person bucky = new Person();
        bucky.firstNameProperty().addListener((v, oldValue, newValue) -> {
            System.out.println("Name changed to " + newValue);
            System.out.println("firstNameProperty(): " + bucky.firstNameProperty());
            System.out.println("getFirstName(): " + bucky.getFirstName());
        });



        btn = new Button("set 1");
        btn.setOnAction(e -> bucky.setFirstName("Bucky"));
        btn2 = new Button("set 2");
        btn2.setOnAction(e -> bucky.setFirstName("Sally"));

        HBox layout = new HBox(10);
        layout.setPadding(new Insets(10, 10, 10, 10));
        layout.setAlignment(Pos.CENTER);
        layout.getChildren().addAll(btn, btn2);

        window.setTitle("JavaFx Application");
        window.setScene(new Scene(layout, 400, 300));
        window.show();
    }
}
