package thenewBostonTut;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 * Created by vhasfcsunb on 8/18/2016.
 */
public class Main30BindingExample extends Application {
    Button btn, btn2;
    Stage window;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        window = primaryStage;

        //Input
        TextField textField=new TextField();
        textField.setMaxWidth(200);
        Label label1=new Label("Welcome to the site ");
        Label label2=new Label();

        label2.textProperty().bind(textField.textProperty());

        HBox hBox=new HBox(label1,label2);
        hBox.setAlignment(Pos.CENTER);

        btn = new Button("Button 1");
        btn.setOnAction(e -> System.out.println("I am Button 1"));
        btn2 = new Button("Button 2");
        btn2.setOnAction(e -> System.out.println("I am Button 2"));

        HBox layout = new HBox(10);
        layout.setPadding(new Insets(10, 10, 10, 10));
        layout.setAlignment(Pos.CENTER);
        layout.getChildren().addAll(btn, btn2);

        VBox vBox=new VBox(10);
        vBox.setAlignment(Pos.CENTER);
        vBox.setPadding(new Insets(10,10,10,10));
        vBox.getChildren().addAll(textField,hBox,layout);

        window.setTitle("JavaFx Application");
        window.setScene(new Scene(vBox, 400, 300));
        window.show();
    }
}
