package thenewBostonTut;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 * Created by Bing Sun1 on 8/17/2016.
 */
public class Main21Menus extends Application {
    Stage window;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        window = primaryStage;
        BorderPane layout = new BorderPane();

        // File menu
        MenuItem newFile = new MenuItem("_New...");
        newFile.setOnAction(e -> System.out.println("Creating new file..."));
        Menu fileMenu = new Menu("_File");
        fileMenu.getItems().addAll(newFile,
                new MenuItem("_Open..."), new MenuItem("_Save"),
                new SeparatorMenuItem(), new MenuItem("E_xit"));

        // Edit menu
        MenuItem copyMenu = new MenuItem("_Copy");
        MenuItem cutMenu = new MenuItem("C_ut");
        MenuItem pasteMenu = new MenuItem("_Paste");
        pasteMenu.setOnAction(e -> System.out.println("Pasting..."));
        pasteMenu.setDisable(true);

        Menu editMenu = new Menu("_Edit");
        editMenu.getItems().addAll(copyMenu, cutMenu, pasteMenu);

        //Options
        CheckMenuItem wrapMenu = new CheckMenuItem("Wrap");
        MenuItem italicMenu = new MenuItem("Italic");
        wrapMenu.setOnAction(e -> {
            if (wrapMenu.isSelected())
                System.out.println("Selected");
            else
                System.out.println("Unselected");
        });

        Menu optionsMenu = new Menu("Options");
        optionsMenu.getItems().addAll(wrapMenu, italicMenu);

        //Difficulty RadioMenuItem
        RadioMenuItem easyMenu=new RadioMenuItem("Easy");
        RadioMenuItem mediumMenu=new RadioMenuItem("Medium");
        RadioMenuItem hardMenu=new RadioMenuItem("Hard");

        ToggleGroup diffToggle=new ToggleGroup();
        easyMenu.setToggleGroup(diffToggle);
        mediumMenu.setToggleGroup(diffToggle);
        hardMenu.setToggleGroup(diffToggle);

        Menu difficultyMenu= new Menu("Difficulty");
        difficultyMenu.getItems().addAll(easyMenu,mediumMenu,hardMenu);

        // menu bar
        MenuBar menuBar = new MenuBar();
        menuBar.getMenus().addAll(fileMenu, editMenu, optionsMenu,difficultyMenu);
        layout.setTop(menuBar);

        // Text fields
        TextField nameInput = new TextField();
        nameInput.setPromptText("Name");
        TextField ageInput = new TextField();
        ageInput.setPromptText("Age");

        HBox inputLayout = new HBox(10, nameInput, ageInput);
        inputLayout.setAlignment(Pos.CENTER);
        inputLayout.setPadding(new Insets(10, 10, 10, 10));

        // Buttons
        Button button1, button2;
        Label label = new Label();
        button1 = new Button("OK");
        button1.setOnAction(e -> {
            System.out.println(nameInput.getText() + ", " + ageInput.getText());
            label.setText(nameInput.getText() + ", " + ageInput.getText());
        });
        button2 = new Button("Close");
        button2.setOnAction(e -> window.close());

        HBox buttonLayout = new HBox(10);
        buttonLayout.setPadding(new Insets(10, 10, 10, 10));
        buttonLayout.setAlignment(Pos.CENTER);
        buttonLayout.getChildren().addAll(button1, button2);

        // root layout
        VBox vbox = new VBox(10);
        vbox.setAlignment(Pos.CENTER);
        vbox.getChildren().addAll(inputLayout, buttonLayout, label);
        layout.setCenter(vbox);

        window.setTitle("JavaFx Application");
        window.setScene(new Scene(layout, 400, 300));
        window.show();
    }
}
