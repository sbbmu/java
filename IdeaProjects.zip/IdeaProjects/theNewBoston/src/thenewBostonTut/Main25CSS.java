package thenewBostonTut;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 * Created by Bing Sun1 on 8/17/2016.
 */
public class Main25CSS extends Application {
    Button button1, button2;
    Stage window;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        window = primaryStage;

        // Text fields
        TextField nameInput = new TextField();
        nameInput.setPromptText("Name");
        TextField ageInput = new TextField();
        ageInput.setPromptText("Age");

        HBox inputLayout = new HBox(10, nameInput, ageInput);
        inputLayout.setAlignment(Pos.CENTER);
        inputLayout.setPadding(new Insets(10, 10, 10, 10));

        // Buttons
        Label label = new Label();
        label.setId("bold-label"); // custom CSS id defined in "Viper.css"
//        label.setStyle("-fx-text-fill: #22bce5");
        button1 = new Button("OK");
        button1.setOnAction(e -> {
//            setUserAgentStylesheet(STYLESHEET_MODENA);
            System.out.println(nameInput.getText() + ", " + ageInput.getText());
            label.setText(nameInput.getText() + ", " + ageInput.getText());
        });
        button2 = new Button("Close");
        button2.getStyleClass().add("button-blue");
       button2.setOnAction(e -> setUserAgentStylesheet(STYLESHEET_CASPIAN));

        HBox buttonLayout = new HBox(10);
        buttonLayout.setPadding(new Insets(10, 10, 10, 10));
        buttonLayout.setAlignment(Pos.CENTER);
        buttonLayout.getChildren().addAll(button1, button2);

        // root layout
        VBox vbox = new VBox(10);
        vbox.setAlignment(Pos.CENTER);
        vbox.getChildren().addAll(inputLayout, buttonLayout, label);

        Scene scene = new Scene(vbox, 400, 300);
        //put css file in the "src" folder
        scene.getStylesheets().add("Viper.css");
        window.setTitle("JavaFx Application");
        window.setScene(scene);
        window.show();
    }
}
