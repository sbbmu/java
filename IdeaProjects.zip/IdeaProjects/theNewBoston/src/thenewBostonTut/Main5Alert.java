package thenewBostonTut;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 * Created by vhasfcsunb on 8/11/2016.
 */
public class Main5Alert extends Application {
    Stage window;
    Button btn, btn2;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        window=primaryStage;
        window.setTitle("Main window");
        btn=new Button("Show Alert");
        btn2=new Button("Show new window");
        btn.setOnAction(e->{AlertBox.display("Alert","Welcome to the new world!");});
        btn2.setOnAction(e -> {
            boolean result=ConfirmBox.display("Confirm Box", "Do you want to do that?");
            System.out.println(result);

        });

        VBox layout=new VBox(50);
        layout.getChildren().addAll(btn,btn2);
        layout.setAlignment(Pos.CENTER);
        window.setScene(new Scene(layout,200,300));
        window.show();
    }
}
