package thenewBostonTut;

import javafx.application.Application;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 * Created by vhasfcsunb on 8/17/2016.
 */
public class Main15ListView extends Application {
    Button btn, btn2;
    Stage window;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        window = primaryStage;
        ListView<String> listView = new ListView<>();
        listView.getItems().addAll("Iron man", "Titanic", "Contact", "Surrogates");
        listView.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);

        // tree view
        TreeView<String> treeView = new TreeView<>();
        treeView.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        TreeItem<String> root,bucky,megan;
        root=new TreeItem<>();
        root.setExpanded(true);
        
        bucky=makeBranch("Bucky",root);
        makeBranch("thenewBoston",bucky);
        makeBranch("YouTube",bucky);
        makeBranch("Chicken",bucky);

        megan=makeBranch("Megan",root);
        makeBranch("Glitter",megan);
        makeBranch("MakeUp",megan);
        makeBranch("Flowers",megan);

        treeView=new TreeView<>(root);
        treeView.setShowRoot(false);
        treeView.getSelectionModel().selectedItemProperty().addListener(
                (v,oldV,newV)->{
                    if(newV!=null)
                        System.out.println(newV.getValue());
                });

        //
        HBox hbox = new HBox(10);
        hbox.getChildren().addAll(treeView, listView);

        btn = new Button("OK");
        btn.setOnAction(e -> processMovies(listView));
        btn2 = new Button("Close");
        btn2.setOnAction(e -> window.close());

        HBox hbox2= new HBox(10);
        hbox2.getChildren().addAll( btn, btn2);
        hbox2.setAlignment(Pos.CENTER);

        VBox layout = new VBox(10);
        layout.setPadding(new Insets(10, 10, 10, 10));
        layout.setAlignment(Pos.CENTER);
        layout.getChildren().addAll(hbox,hbox2);

        window.setTitle("JavaFx Application");
        window.setScene(new Scene(layout, 400, 300));
        window.show();
    }

    private TreeItem<String> makeBranch(String title, TreeItem<String> parent) {
        TreeItem<String> item=new TreeItem<>(title);
        item.setExpanded(true);
        parent.getChildren().add(item);
        return item;
    }

    private void processMovies(ListView<String> listView) {
        ObservableList<String> movies = listView.getSelectionModel().getSelectedItems();

        System.out.println(movies);
        String message = "";
        for (String m : movies) {
            message += m + " ";

        }
        System.out.println(message);
    }


}
