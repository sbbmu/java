package thenewBostonTut;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

/**
 * Created by vhasfcsunb on 8/17/2016.
 */
public class Main9GridPane extends Application {
    Stage window;

    public static void main(String[] args) {
        launch();
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        window = primaryStage;
        window.setTitle("GridPane");

        GridPane grid = new GridPane();
        grid.setPadding(new Insets(10, 10, 10, 10));
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(10);
        grid.setVgap(8);

        // Name label
        Label l1 = new Label("User Name:");
        GridPane.setConstraints(l1, 0, 0);

        //Text field
        TextField nameInput = new TextField("Bucky");
        GridPane.setConstraints(nameInput, 1, 0);


        // Name label
        Label l2 = new Label("Password:");
        GridPane.setConstraints(l2, 0, 1);

        //Text field
        TextField passInput = new TextField();
        passInput.setPromptText("password");
        GridPane.setConstraints(passInput, 1, 1);

        Button loginButton = new Button("Login");
        GridPane.setConstraints(loginButton, 1, 2);
        loginButton.setOnAction((e -> System.out.println(isValidateInput(nameInput.getText()))));

        grid.getChildren().addAll(l1, nameInput, l2, passInput, loginButton);

        window.setScene(new Scene(grid, 300, 200));
        window.show();
    }

    private boolean isValidateInput(String input) {
        if (isNumber(input)) return true;
        else if (input.contains(" "))
            return true;
        return false;
    }

    private boolean isNumber(String s) {
        try {
            double n = Double.parseDouble(s);
            System.out.println("the number is " + n);
            return true;
        } catch (NumberFormatException e) {
            System.out.println(e.toString());
            return false;
        }
    }
}
