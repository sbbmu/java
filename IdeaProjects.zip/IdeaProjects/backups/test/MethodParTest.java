package test;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

/**
 * Created by VHASFCSUNB on 9/23/2016.
 */

interface DrawMethod { //Command patter
    void Draw(Object par);
}

class DrawGC implements DrawMethod {
    private GraphicsContext gc;
    private Canvas canvas;

    public void setGc(GraphicsContext g) {
        gc = g;
        canvas = gc.getCanvas();
    }

    public void strokeRect(Object par) {
        Bounds b = (Bounds) par;
        double x = b.getX(), y = b.getY(), w = b.getW(), h = b.getH();
        gc.strokeRect(x, y, w, h);
//        fxgraph.Utils.log(x, y, w, h);
    }

    public void fillRect(Object par) {
        Bounds b = (Bounds) par;
        double x = b.getX(), y = b.getY(), w = b.getW(), h = b.getH();
        gc.fillRect(x, y, w, h);
//        fxgraph.Utils.log(x, y, w, h);
    }

    @Override public void Draw(Object par) { }

    public void callCommand(DrawMethod command, Bounds b) {
        double x = b.getX(), y = b.getY(), w = b.getW(), h = b.getH();
        Undo undo = new Undo(canvas, "rect" + x + "," + y);// save current image with a name
        command.Draw(b);
        undo.End(new Bounds(x, y, w, h)); //save modified image, trim to the size

    }
}

public class MethodParTest extends Application {
    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage window) throws Exception {
        Canvas canvas = new Canvas(400, 400);
        GraphicsContext gc = canvas.getGraphicsContext2D();
        gc.setStroke(Color.RED);
        gc.setFill(Color.LAVENDER);

        DrawGC s = new DrawGC();
        s.setGc(gc);
        s.callCommand(e -> s.strokeRect(e), new Bounds(10, 50, 200, 200));
        s.callCommand(e -> s.fillRect(e), new Bounds(50, 60, 50, 50));

        VBox vbox = new VBox(10);
        vbox.getChildren().addAll(canvas);

        window.setScene(new Scene(vbox, 500, 500));
        window.show();
    }
}
