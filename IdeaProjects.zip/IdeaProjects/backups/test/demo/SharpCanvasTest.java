package fxgraph.demo;

/**
 * Created by VHASFCSUNB on 9/20/2016.
 */

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.ScrollEvent;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class SharpCanvasTest extends Application {

    @Override
    public void start(Stage primaryStage) {
        Canvas sharpCanvas = createCanvasGrid(600, 300, true);
        Canvas blurryCanvas = createCanvasGrid(600, 300, false);
        GraphicsContext gcSharp = sharpCanvas.getGraphicsContext2D();
        GraphicsContext gcBlur = blurryCanvas.getGraphicsContext2D();

        gcSharp.setStroke(Color.RED);
        gcSharp.setLineWidth(1);
        gcSharp.strokeLine(10, 10, 200, 200);

        gcBlur.setStroke(Color.RED);
        gcBlur.setLineWidth(1);
        gcBlur.strokeLine(10, 10, 200, 200);

        VBox root = new VBox(5, sharpCanvas, blurryCanvas);

        PannableCanvas pane = new PannableCanvas(root.getWidth(), root.getHeight());
        pane.getChildren().addAll(root);
        SceneGestures sceneGestures = new SceneGestures(pane);
        pane.addEventFilter(MouseEvent.MOUSE_PRESSED, sceneGestures.getOnMousePressed());
        pane.addEventFilter(MouseEvent.MOUSE_DRAGGED, sceneGestures.getOnMouseDragged());
        pane.addEventFilter(ScrollEvent.ANY, sceneGestures.getOnScroll());
        primaryStage.setScene(new Scene(pane, 600, 600));
        primaryStage.show();
    }

    private Canvas createCanvasGrid(int width, int height, boolean sharp) {
        Canvas canvas = new Canvas(width, height);
        GraphicsContext gc = canvas.getGraphicsContext2D();
        gc.setLineWidth(1.0);
        for (int x = 0; x < width; x += 20) {
            double x1;
            if (sharp) {
                x1 = x + 0.5;
            } else {
                x1 = x;
            }
            gc.moveTo(x1, 0);
            gc.lineTo(x1, height);
            gc.stroke();
        }

        for (int y = 0; y < height; y += 20) {
            double y1;
            if (sharp) {
                y1 = y + 0.5;
            } else {
                y1 = y;
            }
            gc.moveTo(0, y1);
            gc.lineTo(width, y1);
            gc.stroke();
        }
        return canvas;
    }

    public static void main(String[] args) {
        launch(args);
    }
}
