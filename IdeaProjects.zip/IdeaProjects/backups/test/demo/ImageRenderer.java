package fxgraph.demo;
// http://stackoverflow.com/questions/22725813/javafx-disable-image-smoothing-on-canvas-object/26706028#26706028

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.image.PixelReader;
import javafx.scene.image.PixelWriter;
import javafx.scene.paint.Color;

/**
 * Created by VHASFCSUNB on 9/20/2016.
 */
public class ImageRenderer {
    public static void render(GraphicsContext context, Image image, int sx, int sy, int sw, int sh, int tx, int ty) {
        PixelReader reader = image.getPixelReader();
        PixelWriter writer = context.getPixelWriter();
        for (int x = 0; x < sw; x++) {
            for (int y = 0; y < sh; y++) {
                Color color = reader.getColor(sx + x, sy + y);
                if (color.isOpaque()) {
                    writer.setColor(tx + x, ty + y, color);
                }
            }
        }
    }

    public static void render(GraphicsContext context, Image image){
        render(context,image,0,0,(int)image.getWidth(),(int)image.getHeight(),0,0);
    }
}

