package fxgraph.demo;


import fxgraph.fxgraphIO;
import javafx.application.Application;
import javafx.geometry.Bounds;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.ScrollEvent;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

import static fxgraph.fxgraphIO.saveImage;

//http://stackoverflow.com/questions/27356577/scale-at-pivot-point-in-an-already-scaled-node
 class GUITools{
     // This zoom is not compatible with the PannableCanvas pan method
    /** Allow to zoom/scale any node with pivot at scene (x,y) coordinates.
     *
     * @param node
     * @param factor
     * @param x
     * @param y
     */
    public static void zoom(Node node, double factor, double x, double y) {
        double delta = 1.2;
        double oldScale = node.getScaleX();
        double scale = oldScale ;
        if ( factor< 0) scale /= delta;
        else scale *= delta;

        if (scale < 0.05) scale = 0.05;
        if (scale > 50)  scale = 50;
        node.setScaleX(scale);
        node.setScaleY(scale);

        double  f = (scale / oldScale)-1;
        Bounds bounds = node.getBoundsInParent(); //node.localToScene(node.getBoundsInLocal());
        double dx = (x - (bounds.getWidth()/2 + bounds.getMinX()));
        double dy = (y - (bounds.getHeight()/2 + bounds.getMinY()));

        node.setTranslateX(node.getTranslateX()-f*dx);
        node.setTranslateY(node.getTranslateY()-f*dy);

        Canvas canvas=(Canvas)(((PannableCanvas)((Pane)node).getChildren().get(0)).getChildren().get(0));
        ImageRenderer.render(canvas.getGraphicsContext2D(),canvas.snapshot(null,null));
//        fxgraphIO.saveImage(canvas);
    }

    public static void zoom(Node node, ScrollEvent e) {
        zoom(node, e.getDeltaY(), e.getSceneX(), e.getSceneY());
    }
//    public static void zoom(Node node, ZoomEvent event) {
//        zoom(node, event.getZoomFactor(), event.getSceneX(), event.getSceneY());
//    }

}

 public class TestZoom extends Application {
    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage stage) {
//        Group group = new Group();

        // create canvas
        PannableCanvas canvas = new PannableCanvas(600,600);

        // we don't want the canvas on the top/left in this example => just
        // translate it a bit
        canvas.setTranslateX(100);
        canvas.setTranslateY(100);

        // create sample nodes which can be dragged
        NodeGestures nodeGestures = new NodeGestures(canvas);

        Label label1 = new Label("Draggable node 1");
        label1.setTranslateX(10);
        label1.setTranslateY(10);
        label1.addEventFilter(MouseEvent.MOUSE_PRESSED, nodeGestures.getOnMousePressed());
        label1.addEventFilter(MouseEvent.MOUSE_DRAGGED, nodeGestures.getOnMouseDragged());

        Label label2 = new Label("Draggable node 2");
        label2.setTranslateX(100);
        label2.setTranslateY(100);
        label2.addEventFilter(MouseEvent.MOUSE_PRESSED, nodeGestures.getOnMousePressed());
        label2.addEventFilter(MouseEvent.MOUSE_DRAGGED, nodeGestures.getOnMouseDragged());

        Label label3 = new Label("Draggable node 3");
        label3.setTranslateX(200);
        label3.setTranslateY(200);
        label3.addEventFilter(MouseEvent.MOUSE_PRESSED, nodeGestures.getOnMousePressed());
        label3.addEventFilter(MouseEvent.MOUSE_DRAGGED, nodeGestures.getOnMouseDragged());

        Circle circle1 = new Circle(300, 300, 50);
        circle1.setStroke(Color.ORANGE);
        circle1.setFill(Color.ORANGE.deriveColor(1, 1, 1, 0.5));
        circle1.addEventFilter(MouseEvent.MOUSE_PRESSED, nodeGestures.getOnMousePressed());
        circle1.addEventFilter(MouseEvent.MOUSE_DRAGGED, nodeGestures.getOnMouseDragged());

        Rectangle rect1 = new Rectangle(100, 100);
        rect1.setTranslateX(450);
        rect1.setTranslateY(450);
        rect1.setStroke(Color.BLUE);
        rect1.setFill(Color.BLUE.deriveColor(1, 1, 1, 0.5));
        rect1.addEventFilter(MouseEvent.MOUSE_PRESSED, nodeGestures.getOnMousePressed());
        rect1.addEventFilter(MouseEvent.MOUSE_DRAGGED, nodeGestures.getOnMouseDragged());

        canvas.getChildren().addAll(label1, label2, label3, circle1, rect1);

//        group.getChildren().add(canvas);

        Pane pane=new Pane();
pane.getChildren().addAll(canvas);
        SceneGestures sceneGestures = new SceneGestures(canvas);
        pane.addEventFilter(MouseEvent.MOUSE_PRESSED, sceneGestures.getOnMousePressed());
        pane.addEventFilter(MouseEvent.MOUSE_DRAGGED, sceneGestures.getOnMouseDragged());
//        scene.addEventFilter(ScrollEvent.ANY, sceneGestures.getOnScroll());

// This zoom is not compatible with the PannableCanvas pan method
        pane.setOnScroll(event -> GUITools.zoom(pane, event)); // mouse scroll wheel zoom
//        pane.setOnZoom(event -> GUITools.zoom(pane, event)); // pinch to zoom

        // create scene which can be dragged and zoomed
        Scene scene = new Scene(pane, 1024, 768);
        stage.setScene(scene);
        stage.show();


        canvas.addGrid();

        Canvas grid=(Canvas)(canvas.getChildren().get(0));
//        fxgraphIO.saveImage(grid);
        scene.setOnKeyPressed(e->{
            System.out.println("save image");
             fxgraphIO.saveImage(grid);});
    }
}