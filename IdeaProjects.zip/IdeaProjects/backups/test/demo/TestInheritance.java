package fxgraph.demo;

/**
 * Created by Bing Sun1 on 9/15/2016.
 */
class Employee {
    String name;
    double salary;

    public double getSalary() { return salary; }

    public Employee(String name, double salary) {
        this.name = name;
        this.salary = salary;
    }
}

class Manager extends Employee {
    double bonus;

    public double getBonus() { return bonus; }

    public void setBonus(double bonus) { this.bonus = bonus; }

    public Manager(String name, double salary, double bonus) {
        super(name, salary);
        this.bonus = bonus;
    }

    public double getSalary(){
        return super.getSalary()+getBonus();
    }
}


public class TestInheritance {
    public static void main(String[] args) {
        Manager SL=new Manager("Scott Lancing",80000,0);
        SL.setBonus(1000);
        System.out.println(SL.getSalary());
    }
}
