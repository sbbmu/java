// from: http://stackoverflow.com/questions/23983465/is-there-a-fill-function-for-arbitrary-shapes-in-javafx
// "Is there a “fill” function for arbitrary shapes in javafx?"
// by: jewelsea

package fxgraph;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Point2D;
import javafx.scene.Scene;
import javafx.scene.image.*;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.util.Stack;

public class floodFillDemo extends Application {
    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(final Stage stage) {
        Image original = new Image(getClass().getResourceAsStream("image_2.jpg"));

        WritableImage updateable = new WritableImage(
                original.getPixelReader(),
                (int) original.getWidth(),
                (int) original.getHeight()
        );

        FloodFill kraken = new FloodFill(updateable, Color.WHITE);
        kraken.unleash(new Point2D(40, 40), Color.BLUE);
        kraken.unleash(new Point2D(40, 100), Color.RED);
        kraken.unleash(new Point2D(100, 100), Color.GREEN);
        kraken.unleash(new Point2D(120, 40), Color.YELLOW);

        ImageView originalView = new ImageView(original);
        ImageView filledView = new ImageView(updateable);

        HBox layout = new HBox(10, originalView, filledView);
        layout.setPadding(new Insets(10));
        stage.setScene(new Scene(layout));
        stage.show();
    }


}

// from: http://stackoverflow.com/questions/23983465/is-there-a-fill-function-for-arbitrary-shapes-in-javafx
// "Is there a “fill” function for arbitrary shapes in javafx?"
// by: jewelsea
// Original class "Kraken"

class FloodFill {
    private final WritableImage image;
    private final Color colorToFill;

    // tolerance for color matching (on a scale of 0 to 1);
    private final double E = 0.3;

    public FloodFill(WritableImage image, Color colorToFill) {
        this.image = image;
        this.colorToFill = colorToFill;
    }

    public void unleash(Point2D start, Color color) {
        PixelReader reader = image.getPixelReader();
        PixelWriter writer = image.getPixelWriter();

        Stack<Point2D> stack = new Stack<>();
        stack.push(start);

        while (!stack.isEmpty()) {
            Point2D point = stack.pop();
            int x = (int) point.getX();
            int y = (int) point.getY();
            if (filled(reader, x, y)) {
                continue;
            }

            writer.setColor(x, y, color);

            push(stack, x - 1, y - 1);
            push(stack, x - 1, y);
            push(stack, x - 1, y + 1);
            push(stack, x, y + 1);
            push(stack, x + 1, y + 1);
            push(stack, x + 1, y);
            push(stack, x + 1, y - 1);
            push(stack, x, y - 1);
        }
    }

    private void push(Stack<Point2D> stack, int x, int y) {
        if (x < 0 || x > image.getWidth() ||
                y < 0 || y > image.getHeight()) {
            return;
        }

        stack.push(new Point2D(x, y));
    }

    private boolean filled(PixelReader reader, int x, int y) {
        Color color = reader.getColor(x, y);

        return !withinTolerance(color, colorToFill, E);
    }

    private boolean withinTolerance(Color a, Color b, double epsilon) {
        return
                withinTolerance(a.getRed(), b.getRed(), epsilon) &&
                        withinTolerance(a.getGreen(), b.getGreen(), epsilon) &&
                        withinTolerance(a.getBlue(), b.getBlue(), epsilon);
    }

    private boolean withinTolerance(double a, double b, double epsilon) {
        return Math.abs(a - b) < epsilon;
    }
}