package test;
// based on http://torgen-engineering.blogspot.com/2015/11/testing-javafx-applications-with-testfx.html#!/2016/05/how-to-bring-undoredo-features-to-your.html


import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.SnapshotParameters;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.WritableImage;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.util.ArrayDeque;
import java.util.Deque;

/**
 * Created by VHASFCSUNB on 9/21/2016.
 * This class saves a region of the canvas to an image to perform Undo
 * Bug: due to canvas anti-aliasing, the undo-redo has some leftover borders. -- solved --
 */

interface Undoable {
    void undo();

    void redo();

    String getName();
}

interface Command {
    void execute();

    boolean canExecute();
}


final class UndoCollector {
    public static final UndoCollector INSTANCE = new UndoCollector();

    private final Deque<Undoable> undo;
    private final Deque<Undoable> redo;
    private int sizeMax;

    private UndoCollector() {
        super();
        undo = new ArrayDeque<>();
        redo = new ArrayDeque<>();
        sizeMax = 60;
    }

    public Deque<Undoable> getUndo() {
        return undo;
    }

    /**
     * Adds an undoable object to the collector.
     *
     * @param undoable The undoable object to add.
     */
    public Undoable add(final Undoable undoable) {
        Undoable last = null;
        if (undoable != null && sizeMax > 0) {
            if (undo.size() == sizeMax) {
                last = undo.peekLast();
                undo.removeLast();
            }

            undo.push(undoable);
            redo.clear(); /* The redoable objects must be removed. */
        }
        return last;
    }

    //Undoes the last undoable object.
    public void undo() {
        if (!undo.isEmpty()) {
            final Undoable undoable = undo.pop();
            undoable.undo();
            redo.push(undoable);
        }
    }

    // Redoes the last undoable object.
    public void redo() {
        if (!redo.isEmpty()) {
            final Undoable undoable = redo.pop();
            undoable.redo();
            undo.push(undoable);
        }
    }

    /**
     * @return The last undoable object name or "".
     */
    public String getLastUndoMessage() {
        return undo.isEmpty() ? "" : undo.peek().getName();
    }

    /**
     * @return The last redoable object name or "".
     */
    public String getLastRedoMessage() {
        return redo.isEmpty() ? "" : redo.peek().getName();
    }

    /**
     * @return The last undoable object or null.
     */
    public Undoable getLastUndo() {
        return undo.isEmpty() ? null : undo.peek();
    }

    /**
     * @return The last redoable object or null.
     */
    public Undoable getLastRedo() {
        return redo.isEmpty() ? null : redo.peek();
    }

    /**
     * @param max The max number of saved undoable objects. Must be great than 0.
     */
    public void setSizeMax(final int max) {
        if (max >= 0) {
            for (int i = 0, nb = undo.size() - max; i < nb; i++) {
                undo.removeLast();
            }
            this.sizeMax = max;
        }
    }
}

class Bounds {
    private double x, y, w, h;

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    public double getW() {
        return w;
    }

    public double getH() {
        return h;
    }

    public Bounds(double x, double y, double w, double h) {
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
    }

    public static double keepBounds(double val, double min, double max) {
        if (val < min) val = min;
        if (val > max) val = max;
        return val;
    }
}


class Undo implements Undoable, Command {
    private String Name;
    private WritableImage preImage, postImage, image;
    private Canvas canvas;
    private GraphicsContext gc;
    private int x, y;
    boolean spill;

    // constructor
    public Undo(Canvas c, String name, boolean spill) {
        canvas = c;
        gc = canvas.getGraphicsContext2D();
        SnapshotParameters sp = new SnapshotParameters();
        sp.setFill(Color.TRANSPARENT);
        preImage = canvas.snapshot(sp, null);
        setName(name);
        this.spill = spill;
    }

    public Undo(Canvas c, boolean spill) {
        this(c, "Undo", spill);
    }

    public Undo(Canvas c, String s) {
        this(c, s, true);
    }

    public Undo(Canvas c) {
        this(c, "Undo", true);
    }

    public void End(int px, int py, int w, int h) {
        SnapshotParameters sp = new SnapshotParameters();
        sp.setFill(Color.TRANSPARENT);
        postImage = canvas.snapshot(sp, null);

        px--;
        py--;
        w += 2;
        h += 2; // include 1 pixel border for correction of the canvas anti-aliasing

        px = (int) Bounds.keepBounds(px, 0, preImage.getWidth());
        py = (int) Bounds.keepBounds(py, 0, preImage.getHeight());
        w = (int) Bounds.keepBounds(w, 0, preImage.getWidth()-px);
        h = (int) Bounds.keepBounds(h, 0, preImage.getHeight()-py);

        preImage = new WritableImage(preImage.getPixelReader(), px, py, w, h);
        postImage = new WritableImage(postImage.getPixelReader(), px, py, w, h);
        x = px;
        y = py;
        UndoCollector.INSTANCE.add(this);
    }

    public void End(Bounds b) {
        End((int) b.getX(), (int) b.getY(), (int) b.getW(), (int) b.getH());
    }

    @Override
    public void undo() { image = preImage; if (canExecute()) execute(); }

    @Override
    public void redo() {
        image = postImage;
        if (canExecute()) execute();
    }

    public void setName(String name) { Name = name; }

    @Override
    public String getName() { return Name; }

    @Override
    public void execute() {
        int a = 1;//antialiasing Correction, avoid 1 pixel border
//        if (spill) a = 0;
        gc.clearRect(x + a, y + a, image.getWidth() - a, image.getHeight() - a);
        gc.drawImage(image, x, y);
//        System.out.println("Undo: " + fxgraph.Utils.log(x, y, preImage.getWidth(), preImage.getHeight()));
    }

    @Override
    public boolean canExecute() { return image != null; }
}

public class UndoTest extends Application {
    private Canvas canvas;
    private GraphicsContext gc;
    private Label label;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage window) throws Exception {
        Pane pane = new Pane();
        canvas = new Canvas(400, 400);
        pane.getChildren().add(canvas);
        gc = canvas.getGraphicsContext2D();
        draw(gc);

        canvas.setOnMouseClicked(this::onMouseClicked);
        canvas.setOnMouseMoved(e -> onMouseMoved(e));
        // Text fields
        TextField nameInput = new TextField();
        nameInput.setPromptText("Name");
        TextField ageInput = new TextField();
        ageInput.setPromptText("Age");

        HBox inputLayout = new HBox(10, nameInput, ageInput);
        inputLayout.setAlignment(Pos.CENTER);
        inputLayout.setPadding(new Insets(10, 10, 10, 10));

        // Buttons
        label = new Label();
        Button button1 = new Button("Undo");
        button1.setOnAction(e -> UndoCollector.INSTANCE.undo());
        Button button2 = new Button("Redo");
        button2.setOnAction(e -> UndoCollector.INSTANCE.redo());

        HBox buttonLayout = new HBox(10);
        buttonLayout.setPadding(new Insets(10, 10, 10, 10));
        buttonLayout.setAlignment(Pos.CENTER);
        buttonLayout.getChildren().addAll(button1, button2);

        // root layout
        VBox vbox = new VBox(10);
        vbox.setAlignment(Pos.CENTER);
        vbox.getChildren().addAll(pane, inputLayout, buttonLayout, label);

        window.setTitle("JavaFx Application");
        window.setScene(new Scene(vbox, 500, 500));
        window.show();
    }

    private void onMouseMoved(MouseEvent e) {
        label.setText(e.getX() + ", " + e.getY());
    }


    private void onMouseClicked(MouseEvent e) {
        double x = e.getX(), y = e.getY(), w = 100 * Math.random() + 10, h = 100 * Math.random() + 10;
        Undo undo = new Undo(canvas, "rect" + x + "," + y, false);
        gc.setStroke(Color.BLACK);
        gc.setFill(Color.rgb((int) (255 * Math.random()), (int) (255 * Math.random()), (int) (255 * Math.random()), Math.random()));//
        gc.fillRect((int) x, (int) y, (int) w, (int) h);
        gc.strokeRect((int) x, (int) y - 5, (int) w + 5, (int) h - 2);
        undo.End(new Bounds(x, y - 5, w + 5, h + 5));

        label.setText("Mouse clicked: " + fxgraph.Utils.log((int) x, (int) y, (int) w, (int) h));
    }


    private void draw(GraphicsContext gc) {
        DrawGC s = new DrawGC();
        s.setGc(gc);

        s.callCommand(s::strokeRect, new Bounds(30, 70, 30, 30));

        gc.setFill(Color.RED);
        s.callCommand(s::fillRect, new Bounds(90, 120, 60, 60));

        s.callCommand(s::strokeRect, new Bounds(110, 210, 30, 30));

        gc.setFill(Color.YELLOW);
        s.callCommand(s::fillRect, new Bounds(150, 140, 60, 90));


        gc.setStroke(Color.BLACK);
        gc.setFill(Color.BLUE);

        Undo undo = new Undo(canvas, "rect" + 10 + "," + 10);
        gc.strokeRect(10, 10, 30, 30);
        undo.End(new Bounds(10, 10, 30, 30));

        undo = new Undo(canvas, "rect" + 50 + "," + 20);
        gc.fillRect(50, 20, 60, 60);
        undo.End(new Bounds(50, 20, 60, 60));


        gc.setStroke(Color.RED);
        gc.setFill(Color.LAVENDER);
        s.callCommand(s::strokeRect, new Bounds(10, 20, 200, 200));
        s.callCommand(e -> s.fillRect(e), new Bounds(50, 50, 50, 50));

    }

}

