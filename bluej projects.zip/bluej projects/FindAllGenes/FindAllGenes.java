
/**
 * Write a description of FindAllGenes here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class FindAllGenes {
	private static String print3(String seq,int start){
		String out="";
		for(int i=0;i<seq.length();i++){
			out+= seq.substring(i,i+1);
			if( (i- start % 3+1) %3 ==0) out+=" ";
		}
		return(out);
	}

	private static String findGene(String seq){
		seq=seq.toUpperCase();
		String gene="";
		int start=seq.indexOf("ATG");

		if(start!=-1){
			int end  =seq.indexOf("TAG",start+3);
			// take the shortest one if multiple stop codon found
			if(end!=-1 && (end-start) % 3 == 0){
				 gene=seq.substring(start,end+3);				
			}
			end  =seq.indexOf("TGA",start+3);
			if(end!=-1 && (end-start) % 3 == 0){
				String g=seq.substring(start,end+3);
				if(gene!="" && g.length()<gene.length())gene=g;
			}
			end  =seq.indexOf("TAA",start+3);
			if(end!=-1 && (end-start) % 3 == 0){
				String g=seq.substring(start,end+3);
				if(gene!="" && g.length()<gene.length())gene=g;
			}
		}
		return(gene);
	}

	public static void main(){
		String dna="ATGCTGACCTGATAG";
		String g= findGene(dna);
		String out=print3(g,0);
		System.out.println(out);
		System.out.println("Hello!");
		System.out.println(-3%3);
	}   

}
