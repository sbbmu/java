 

import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

/**
 * Created by Bing Sun1 on 9/4/2016.
 */
public class Utils {
    /**
     * Helper functions -- log to console
     */
    public static String log(String p, String... v) {
        for (String s : v) p += ", " + s;
        System.out.println(p);
        return p;
    }

    public static String log(double p, double... v) {
        String ps = String.valueOf(p);
        for (double s : v) ps += ", " + String.valueOf(s);
        System.out.println(ps);
        return ps;
    }

    public boolean isInRect(MouseEvent e, Rectangle rectangle) {
        return isInRect(e, rectangle.getX(), rectangle.getY(), rectangle.getWidth(), rectangle.getHeight());
    }

    public boolean isInRect(MouseEvent e, double x1, double y1, double selectionWidth, double selectionHeight) {
        double x = e.getX(), y = e.getY();
        if (x >= x1 & x <= x1 + selectionWidth & y >= y1 & y <= y1 + selectionHeight)
            return true;
        else
            return false;
    }

    static Color randomColor() {
        return Color.rgb((int) (Math.random() * 256), (int) (Math.random() * 256), (int) (Math.random() * 256),
                Math.random());
    }

    static Color positionColor(MouseEvent e) {
        int r, g, b, a;
        if (e != null) {
            r = Math.abs((int) e.getX() * 3) % 256;
            g = Math.abs((int) e.getY() % 256);
            b = Math.abs((int) (e.getX() * 2 + e.getY()) % 256);
            a = 1;
        } else {
            r = 0;
            g = 0;
            b = 0;
            a = 1;
        }
        return (Color.rgb(r, g, b, a));
    }
}
