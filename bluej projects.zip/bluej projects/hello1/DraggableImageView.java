 

import javafx.scene.Cursor;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

/**
 * Created by VHASFCSUNB on 9/2/2016.
 */
public class DraggableImageView extends ImageView {
    private static double oldMouseX, oldMouseY;
    private static double oldTranslateX, oldTranslateY;

    public DraggableImageView(Image image) {
        super(image);

        setOnMousePressed(event -> {
            oldMouseX = event.getSceneX();
            oldMouseY = event.getSceneY();
            oldTranslateX = this.getTranslateX();
            oldTranslateY = this.getTranslateY();
            this.setCursor(Cursor.OPEN_HAND);
        });

        setOnMouseDragged(event -> {
            double deltaX = event.getSceneX() - oldMouseX;
            double deltaY = event.getSceneY() - oldMouseY;
            this.setTranslateX(deltaX + oldTranslateX);
            this.setTranslateY(deltaY + oldTranslateY);
        });
    }
}

