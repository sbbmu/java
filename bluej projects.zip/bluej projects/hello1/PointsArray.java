 

import java.util.ArrayList;

/**
 * Created by VHASFCSUNB on 9/6/2016.
 */
public class PointsArray {
    private ArrayList<Double> x, y;

    PointsArray() {
        x = new ArrayList<>();
        y = new ArrayList<>();
    }

    PointsArray(ArrayList<Double> pax, ArrayList<Double> pay) {
        x = pax;
        y = pay;
    }

    int length() {
        return x.size();
    }

    double[] getaX() {
        double[] t = new double[x.size()];
        for (int i = 0; i < t.length; i++) {
            t[i] = x.get(i);
        }
        return t;
    }

    double[] getaY() {
        double[] t = new double[y.size()];
        for (int i = 0; i < t.length; i++) {
            t[i] = y.get(i);
        }
        return t;
    }

    void add(double px, double py) {
        x.add(px);
        y.add(py);
    }
}