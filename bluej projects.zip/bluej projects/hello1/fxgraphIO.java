 

import javafx.embed.swing.SwingFXUtils;
import javafx.scene.SnapshotParameters;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.image.WritableImage;
import javafx.scene.paint.Color;
import javafx.stage.FileChooser;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.awt.image.RenderedImage;
import java.io.File;
import java.io.IOException;

/**
 * Created by Bing Sun1 on 9/2/2016.
 */
public class fxgraphIO {
    public static void saveImage(Canvas canvas){
        try {
            FileChooser fileChooser = new FileChooser();

            // Set extension filter
            FileChooser.ExtensionFilter extFilterJPG = new FileChooser.ExtensionFilter("JPG files (*.JPG)", "*.JPG");
            FileChooser.ExtensionFilter extFilterjpg = new FileChooser.ExtensionFilter("jpg files (*.jpg)", "*.jpg");
            FileChooser.ExtensionFilter extFilterPNG = new FileChooser.ExtensionFilter("PNG files (*.PNG)", "*.PNG");
            FileChooser.ExtensionFilter extFilterpng = new FileChooser.ExtensionFilter("png files (*.png)", "*.png");
            fileChooser.getExtensionFilters().addAll(extFilterPNG, extFilterpng, extFilterJPG, extFilterjpg);

            fileChooser.setInitialDirectory(new File(System.getProperty("user.home"), "Desktop"));
            fileChooser.setSelectedExtensionFilter(extFilterpng);

            // Show open file dialog
            File file = fileChooser.showSaveDialog(null);
            if (file != null) {
                SnapshotParameters sp = new SnapshotParameters();
                sp.setFill(Color.TRANSPARENT);

                WritableImage writableImage = canvas.snapshot(sp, null);
                RenderedImage renderedImage = SwingFXUtils.fromFXImage(writableImage, null);
                ImageIO.write(renderedImage, "png", file);
            }
        } catch (IOException ex) {
            System.out.println(ex);
        }
    }

    public static void openImage(undoGraphicsContext gc) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setInitialDirectory(new File(System.getProperty("user.home"), "Desktop"));
        FileChooser.ExtensionFilter ef = new FileChooser.ExtensionFilter("Image files", "*.png", "*.PNG", "*.jpg",
                "*.JPG");
        fileChooser.getExtensionFilters().addAll(ef);
        File file = fileChooser.showOpenDialog(null);

        if (file != null) {
            try {
                BufferedImage bufferedImage = ImageIO.read(file);
                Image image = SwingFXUtils.toFXImage(bufferedImage, null);
                gc.drawImage(image, 0, 0);
            } catch (IOException e) {
                System.out.println(e);
            }
        }
    }
}
