
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Bounds;
import javafx.scene.Cursor;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.*;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.WritableImage;
import javafx.scene.input.*;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

import java.net.URL;
import java.util.ResourceBundle;


public class Controller implements Initializable {
    private final KeyCombination ctlZ = new KeyCodeCombination(KeyCode.Z, KeyCombination.CONTROL_DOWN); //undo
    private final KeyCombination ctlY = new KeyCodeCombination(KeyCode.Y, KeyCombination.CONTROL_DOWN); //redo
    private final KeyCombination ctlX = new KeyCodeCombination(KeyCode.X, KeyCombination.CONTROL_DOWN); //cut
    private final KeyCombination ctlC = new KeyCodeCombination(KeyCode.C, KeyCombination.CONTROL_DOWN); //copy
    private final KeyCombination ctlV = new KeyCodeCombination(KeyCode.V, KeyCombination.CONTROL_DOWN); //paste

    @FXML
    private ToggleButton freehandButton;
    @FXML
    private TextField textA, textB, textC;
    @FXML
    private ScrollPane scrollPane;
    @FXML
    private TextField canvasW, canvasH, textLwd;
    @FXML
    private ColorPicker colorPickerStroke, colorPickerFill;
    @FXML
    private CheckBox posCol, rndCol, fill, stroke;
    @FXML
    private Label label1, label2, label3, label4, labelA, labelB, labelC;
    @FXML
    private HBox editHBox;

    private PannableCanvas pane;
    private Canvas canvas, canvas2;
    private undoGraphicsContext gc;
    private GraphicsContext gc2;
    private WritableImage img; // selection
    private DraggableImageView imageView;
    private TextInput textInputWindow = new TextInput();

    private static double textFieldValueByDragging(MouseEvent e, double min, double max) {
        TextField source = (TextField) e.getSource();
        double val;
        try {
            val = Double.parseDouble(source.getText());
        } catch (NumberFormatException ex) {
            val = 1.0;
        }
        Bounds bounds = source.localToScreen(source.getBoundsInLocal());
        double tX = bounds.getMinX() + bounds.getWidth() / 2.0;
        double mX = e.getScreenX();

        double newVal = val + (mX - tX) / 30.0;
        if (newVal < min) newVal = min;
        if (newVal > max) newVal = max;

        return newVal;
    }

    //    private void setTextFieldValueByDragging(MouseEvent e) {
    //        double newValue = textFieldValueByDragging(e, 0.0, 100.0);
    //        ((TextField) e.getSource()).setText(String.valueOf(newValue));
    //        setOnTextFieldAction(new ActionEvent(e.getSource(), null));
    //    }

    private void setTextFieldValueByDragging(MouseEvent e, int min, int max) {
        double newValue = textFieldValueByDragging(e, (double) min, (double) max);
        ((TextField) e.getSource()).setText(String.valueOf((int) newValue));
        setOnTextFieldAction(new ActionEvent(e.getSource(), null));
    }

    private void setTextFieldValueByDragging(MouseEvent e, double min, double max) {
        double newValue = textFieldValueByDragging(e, min, max);
        ((TextField) e.getSource()).setText(String.format("%3.1f", newValue));
        setOnTextFieldAction(new ActionEvent(e.getSource(), null));
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        canvas = new Canvas(800, 600);
        gc = new undoGraphicsContext(canvas);
        Brushes.setGc(gc);

        // canvas layer 2
        canvas2 = new Canvas(canvas.getWidth(), canvas.getHeight());
        gc2 = canvas2.getGraphicsContext2D();

        pane = new PannableCanvas(canvas.getWidth(), canvas.getHeight());
        pane.getChildren().addAll(canvas, canvas2);
        scrollPane.setContent(pane);
        SceneGestures sceneGestures = new SceneGestures(pane);
        scrollPane.addEventFilter(MouseEvent.MOUSE_PRESSED, sceneGestures.getOnMousePressed());
        scrollPane.addEventFilter(MouseEvent.MOUSE_DRAGGED, sceneGestures.getOnMouseDragged());
        scrollPane.addEventFilter(ScrollEvent.ANY, sceneGestures.getOnScroll());

        freehandButton.setSelected(true);
        freehandButton.requestFocus();
        freeDrawButton();

        colorPickerStroke.setValue(Color.BLACK);
        colorPickerStroke.setStyle("-fx-color-label-visible: false; -fx-color-rect-height: 3; ");
        colorPickerFill.setValue(Color.WHITE);
        colorPickerFill.setStyle("-fx-color-label-visible: false;");

        textA.setOnMouseDragged(e -> setTextFieldValueByDragging(e, 3, 100));
        textB.setOnMouseDragged(e -> setTextFieldValueByDragging(e, 1.0, 400.0));
        textC.setOnMouseDragged(e -> setTextFieldValueByDragging(e, -360, 360));
        textLwd.setOnMouseDragged(e -> setTextFieldValueByDragging(e, 0.1, 200.0));

        //        DoubleProperty myScale =new SimpleDoubleProperty(pane.getScale());
        //        StringConverter<Number> converter = new NumberStringConverter();
        //        Bindings.bindBidirectional(label3.textProperty(), new SimpleDoubleProperty(pane.getScale()), converter);
        //        label3.textProperty().bind(StringProperty.class.cast(String.valueOf(pane.getScale())));

    }

    @FXML
    private void onKeyPressed(KeyEvent k) {
        //        System.out.println("Key pressed " + k.toString());
        if (k.getCode() == KeyCode.C)
            clearCanvas(false);
        else if (k.getCode() == KeyCode.DELETE) cutButton();
        else if (k.getCode() == KeyCode.SHIFT) Brushes.setIsSHIFT(true);
        //        else if (k.getCode() == KeyCode.ADD) enlarge(1.25);
        //        else if (k.getCode() == KeyCode.SUBTRACT) enlarge(0.8);

        //
        if (ctlZ.match(k)) undo();
        else if (ctlY.match(k)) redo();
        else if (ctlX.match(k)) cutButton();
        else if (ctlC.match(k)) copyButton();
        else if (ctlV.match(k)) pasteButton();
    }

    //    private void enlarge(double scale) {
    ////        System.out.println("plus pressed");
    ////        canvas.setScaleX(canvas.getScaleX() * scale);
    ////        canvas.setScaleY(canvas.getScaleY() * scale);
    //    }

    @FXML
    private void undo() {
        UndoCollector.INSTANCE.undo();
        gc.redraw();
    }

    @FXML
    private void redo() {
        UndoCollector.INSTANCE.redo();
        gc.redraw();
    }

    @FXML
    private void onKeyReleased(KeyEvent k) {
        if (k.getCode() == KeyCode.SHIFT)
            Brushes.setIsSHIFT(false);
    }

    @FXML
    private void clearCanvas() {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Are you sure to clear canvas?", ButtonType.OK);
        alert.showAndWait().filter(response -> response == ButtonType.OK)
        .ifPresent(response -> gc.clearRect(0, 0, canvas.getWidth(), canvas.getHeight()));
    }

    private void clearCanvas(boolean ask) {
        if (ask)
            clearCanvas();
        else
            gc.clearRect(0, 0, canvas.getWidth(), canvas.getHeight());
    }

    @FXML
    private void openImage() {
        fxgraphIO.openImage(gc);
    }

    @FXML
    private void saveImage() {
        fxgraphIO.saveImage(canvas);
    }

    @FXML
    private void setCanvasSize() {
        try {
            canvas.setHeight(Integer.parseInt(canvasH.getText()));
            canvas.setWidth(Integer.parseInt(canvasW.getText()));
            pane.setPrefWidth(canvas.getWidth());
            pane.setPrefHeight(canvas.getHeight());
            setCanvas2Size();
        } catch (NumberFormatException | NullPointerException e) {
            System.out.println(e);
        }
    }

    @FXML
    private void expandCanvasSize() {
        canvas.setHeight(scrollPane.getHeight() - 8);
        canvas.setWidth(scrollPane.getWidth() - 8);
        pane.setPrefWidth(canvas.getWidth());
        pane.setPrefHeight(canvas.getHeight());
        setCanvas2Size();
    }

    private void setCanvas2Size() {
        canvas2.setWidth(canvas.getWidth());
        canvas2.setHeight(canvas.getHeight());
    }

    @FXML
    private void setStrokeColor() {
        Brushes.setStrokeColor(colorPickerStroke.getValue());
    }

    @FXML
    private void setFillColor() {
        Brushes.setFillColor(colorPickerFill.getValue());
    }

    @FXML
    private void setOnTextFieldAction(ActionEvent e) {
        double newValue;
        String text = ((TextField) e.getSource()).getText();
        try {
            newValue = Double.parseDouble(text);
        } catch (NumberFormatException ex) {
            newValue = 1;
        }
        //        System.out.println(newValue + ", :" + text + ";");
        if (e.getSource() == textA) {
            if (!text.isEmpty()) Brushes.setParA(newValue);
        } else if (e.getSource() == textB) {
            if (!text.isEmpty()) Brushes.setParB(newValue);
        } else if (e.getSource() == textC) {
            if (!text.isEmpty()) Brushes.setParC(newValue);
        } else if (e.getSource() == textLwd) {
            if (newValue < 0.1) newValue = 0.1;
            if (newValue > 400) newValue = 400;
            Brushes.setLwd(newValue);
        }
    }

    public void setBrushStatus() {
        Event.fireEvent(textA, new ActionEvent(textA, null));
        Event.fireEvent(textB, new ActionEvent(textB, null));
        Event.fireEvent(textC, new ActionEvent(textC, null));
        Event.fireEvent(textLwd, new ActionEvent(textLwd, null));

        setStrokeColor();
        setFillColor();
        Brushes.setIsFill(fill.isSelected());
        Brushes.setIsStroke(stroke.isSelected());

        if (posCol.isSelected())
            Brushes.setColorState(ColorState.Position);
        else if (rndCol.isSelected())
            Brushes.setColorState(ColorState.Random);
        else
            Brushes.setColorState(ColorState.Fixed);
    }

    public void scrollPaneOnMouseMoved(MouseEvent e) {
        label4.setText(String.format("%1$1.0f", e.getX()) + ", " + String.format("%1$1.0f", e.getY()));
        label3.setText(String.format("%1$1.2f%%", pane.getScale() * 100));
        // label1.setText(Brushes.log(Brushes.getX1(), Brushes.getY1(),
        // Brushes.getSelectionWidth(), Brushes.getSelectionHeight()));
        // label2.setText(isInRect(e, Brushes.getSelectionBounds()) ? "IN" : "Out");
        // label2.setText("ScrollPane content: " + scrollPane.getContent());
        // pane.setStyle("-fx-background-color: #fefefe");
        // scrollPane.setStyle("-fx-background: #808080");
    }

    @FXML
    public void cutButton() {
        copyButton();
        Rectangle r = Brushes.getSelectionBounds();
        gc.clearRect(r.getX(), r.getY(), r.getWidth(), r.getHeight());
    }

    @FXML
    public void copyButton() {
        if (Brushes.isSelectionSet()) {
            img = Brushes.copyImage(canvas, Brushes.getSelectionBounds());
            if (img.getWidth() > 0)
                imageView = new DraggableImageView(img);
        }
    }

    @FXML
    public void pasteButton() {
        if (imageView != null && img.getWidth() > 0) {
            if (!pane.getChildren().contains(imageView)) {
                pane.getChildren().add(imageView);
                imageView.setTranslateX(0.0);
                imageView.setTranslateY(0.0);
                imageView.setX(Brushes.getX0());
                imageView.setY(Brushes.getY0());
                imageView.setEffect(new DropShadow(20, Color.gray(0.15)));
            }
        }
    }

    public void flattenButton() {
        if (pane.getChildren().contains(imageView)) {
            double offsetX = imageView.getTranslateX() + imageView.getX();
            double offsetY = imageView.getTranslateY() + imageView.getY();
            gc.drawImage(img, offsetX, offsetY);
            pane.getChildren().remove(imageView);
            Brushes.GCClear(gc2);
        }
    }

    @FXML
    public void newCanvas() {
        clearCanvas();
    }

    private void setTextField(boolean visLabelA, boolean visLabelB, boolean visLabelC,
    String txtLabelA, String txtLabelB, String txtLabelC,
    String txtTextA, String txtTextB, String txtTextC) {
        setTextField(visLabelA, visLabelB, visLabelC);
        setToolbarLabels(txtLabelA, txtLabelB, txtLabelC);

        textA.setText(txtTextA);
        textB.setText(txtTextB);
        textC.setText(txtTextC);
    }

    private void setToolbarLabels(String a, String b, String c) {
        if (!a.isEmpty()) {
            labelA.setVisible(true);
            labelA.setText(a);
        } else labelA.setVisible(false);

        if (!b.isEmpty()) {
            labelB.setVisible(true);
            labelB.setText(b);
        } else labelB.setVisible(false);

        if (!c.isEmpty()) {
            labelC.setVisible(true);
            labelC.setText(c);
        } else labelC.setVisible(false);
    }

    private void setTextField(boolean visLabelA, boolean visLabelB, boolean visLabelC) {
        labelA.setVisible(visLabelA);
        textA.setVisible(visLabelA);

        labelB.setVisible(visLabelB);
        textB.setVisible(visLabelB);

        labelC.setVisible(visLabelC);
        textC.setVisible(visLabelC);
    }

    public void about() { About.show(); }

    public void options() {
        OptionsWindow.diplay();
    }

    // *****************  Brushes  ***********************//
    @FXML
    private void onMouseDown(MouseEvent e) {
        Brushes.setX0(e.getX());
        Brushes.setY0(e.getY());
        setBrushStatus();
    }

    // freehand
    @FXML
    public void freeDrawButton() {
        label1.setText(" Freehand drawing.");
        setTextField(false, false, false);
        editHBox.setVisible(false);
        setBrushStatus();

        MyCursor.Ellipse(canvas, Brushes.getLwd(), Brushes.getLwd());
        canvas.toFront();
        canvas.setOnMouseDragged(e -> Brushes.drawFreeHand(e));
        canvas.setOnMousePressed(e -> {
                if (e.getButton() == MouseButton.PRIMARY) {
                    onMouseDown(e);
                    Brushes.startFreeHand(e);
                }
            });
    }

    public void eraserButton() {
        label1.setText(" Eraser with size of Width and Height.");
        setTextField(true, true, false, "Width", "Height", "", "10", "10", "");
        editHBox.setVisible(false);
        setBrushStatus();

        double w = Brushes.getParA(), h = Brushes.getParB();
        MyCursor.Rectangle(canvas, w, h);

        canvas.toFront();
        canvas.setOnMouseDragged(e -> Brushes.drawErase(e));
        canvas.setOnMousePressed(e -> Brushes.startErase(e));
    }

    public void selectButton() {
        label1.setText(" 1. Make a rectangular selection. 2. Copy or Cut. 3. Paste and drag to a new location. 4. Flatten to apply to the new place. ");
        setTextField(false, false, false);
        editHBox.setVisible(true);

        canvas2.setCursor(Cursor.CROSSHAIR);
        canvas2.toFront();
        canvas2.setOnMousePressed(e -> onMouseDown(e));
        canvas2.setOnMouseReleased(e -> canvas2OnMouseRelease(e));
        canvas2.setOnMouseDragged(e -> canvas2OnMouseDragged(e));
    }

    private void canvas2OnMouseRelease(MouseEvent e) {
        Brushes.selectOnMouseReleased(e, canvas, gc2);
        Brushes.setIsSelectionSet(true);
    }

    private void canvas2OnMouseDragged(MouseEvent e) {
        Brushes.drawRect(e, gc2);
    }

    public void lineButton() {
        label1.setText(" Number of parallel lines with Distance apart.");

        setTextField(true, true, false, "Number", "Distance", "", "5", "10", "");
        editHBox.setVisible(false);
        setBrushStatus();

        canvas2.setCursor(Cursor.CROSSHAIR);
        canvas2.toFront();
        canvas2.setOnMouseDragged(e -> Brushes.drawLine(e, gc2));
        canvas2.setOnMousePressed(e -> onMouseDown(e));
        canvas2.setOnMouseReleased(e -> Brushes.lineOnMouseReleased(e, gc2));
    }

    public void rectButton() {
        label1.setText(" Click and drag to make a rectangle.");
        setTextField(false, false, false);
        editHBox.setVisible(false);
        setBrushStatus();

        canvas2.setCursor(Cursor.CROSSHAIR);
        canvas2.toFront();
        canvas2.setOnMouseDragged(e -> Brushes.drawRect(e, gc2));
        canvas2.setOnMousePressed(e -> onMouseDown(e));
        canvas2.setOnMouseReleased(e -> Brushes.rectOnMouseReleased(e, gc2));
    }

    public void ovalButton() {
        label1.setText(" Click and drag to make an oval.");
        setTextField(false, false, false);
        editHBox.setVisible(false);
        setBrushStatus();

        canvas2.setCursor(Cursor.CROSSHAIR);
        canvas2.toFront();
        canvas2.setOnMouseDragged(e -> Brushes.drawOval(e, gc2));
        canvas2.setOnMousePressed(e -> onMouseDown(e));
        canvas2.setOnMouseReleased(e -> Brushes.ovalOnMouseReleased(e, gc2));
    }

    @FXML
    public void polyBrushButton() {
        label1.setText(" Polygon with Vertices of points, Radius , Rotation of the points from Eas upward.");

        setTextField(true, true, true, "Vertices", "Radius", "Rotation", "5", "30", "18");
        editHBox.setVisible(false);
        setBrushStatus();

        canvas.setCursor(Cursor.DEFAULT);
        canvas.toFront();
        canvas.setOnMouseDragged(e -> Brushes.polyBrush(e));
        canvas.setOnMousePressed(e -> Brushes.polyBrush(e));
    }

    @FXML
    public void starBrushButton() {
        label1.setText(" Star with Vertices of points, outer Radius (inner will always 1/3 of outer), Rotation of the points from Eas upward.");
        setTextField(true, true, true, "Vertices", "Radius", "Rotation", "5", "30", "18");
        editHBox.setVisible(false);
        setBrushStatus();

        canvas.setCursor(Cursor.DEFAULT);
        canvas.toFront();
        canvas.setOnMouseDragged(e -> Brushes.starBrush(e));
        canvas.setOnMousePressed(e -> Brushes.starBrush(e));
    }

    public void sineBrushButton() {
        label1.setText(" Draw a sine curve: y =  A * sin(B * x + C). Hold <SHIFT> to keep horizontal. A=Amplitude, B= 2*Pi/period, C=shift");
        setTextField(true, true, true, "A", "B", "C", "40", "0.5", "90");
        editHBox.setVisible(false);
        setBrushStatus();

        canvas.setCursor(Cursor.DEFAULT);
        canvas.toFront();
        canvas.setOnMouseDragged(e -> Brushes.sineBrush(e));
        canvas.setOnMousePressed(e -> {
                Brushes.setX1(e.getX());
                Brushes.setY1(e.getY());
                onMouseDown(e);
            });
    }

    public void flowerBrushButton() {
        label1.setText(" Draw a flora: k petals (or pairs of petals for even numbers.)");
        setTextField(true, true, true, "k", "Amplitude", "Rotation", "7", "100", "0");
        editHBox.setVisible(false);
        setBrushStatus();

        canvas.setCursor(Cursor.DEFAULT);
        canvas.toFront();
        canvas.setOnMouseDragged(e -> Brushes.roseBrush(e));
        canvas.setOnMousePressed(e -> Brushes.roseBrush(e));
    }

    @FXML
    public void hozMirrorButton() {
        label1.setText(" Draw right-left symmetry.");
        setTextField(false, false, false);
        editHBox.setVisible(false);
        setBrushStatus();

        canvas.setCursor(Cursor.DEFAULT);
        canvas.toFront();
        canvas.setOnMouseDragged(e -> Brushes.hozMirrorBrush(e));
        canvas.setOnMousePressed(this::onMouseDown);
    }

    @FXML
    public void fourMirrorButton() {
        label1.setText(" Draw from all four corners.");
        setTextField(false, false, false);
        editHBox.setVisible(false);
        setBrushStatus();

        canvas.setCursor(Cursor.DEFAULT);
        canvas.toFront();
        canvas.setOnMouseDragged(e -> Brushes.fourMirrorBrush(e));
        canvas.setOnMousePressed(this::onMouseDown);
    }

    public void paintTextButton() {
        label1.setText(" Draw some texts.");
        setTextField(false, false, false);
        editHBox.setVisible(false);
        boolean isOK = textInputWindow.display();
        if (isOK) {
            setBrushStatus();
            canvas.setCursor(Cursor.TEXT);
            canvas.toFront();
            canvas.setOnMousePressed(e -> Brushes.paintText(e, textInputWindow.getInputText(), textInputWindow.getFont(), textInputWindow.getFontSize()));
            canvas.setOnMouseDragged(null);
        }
    }

    public void paintSparkleButton() {
        label1.setText(" Spray: Number of dots, Spread radius, Size for each dot.");
        setTextField(true, true, true, "Number", "Spread", "Size", "25", "50", "5");
        editHBox.setVisible(false);
        setBrushStatus();

        canvas.setCursor(Cursor.HAND);
        canvas.toFront();
        canvas.setOnMouseDragged(e -> Brushes.drawSparkles(e));
        canvas.setOnMousePressed(e -> Brushes.drawSparkles(e));
    }

    @FXML
    public void drawPathButton() {
        label1.setText(" Try make a path: r for radius of the dome, s for size of the base.");
        setTextField(true, true, false, "r", "s", "", "10", "20", "0");
        editHBox.setVisible(false);
        setBrushStatus();

        canvas.setCursor(Cursor.OPEN_HAND);
        canvas.toFront();
        fxgraphDrawPath.setGc(gc);
        canvas.setOnMouseDragged(e -> fxgraphDrawPath.drawPath(e));
        canvas.setOnMousePressed(e -> fxgraphDrawPath.startPath(e));
    }

    @FXML
    private void holidayBrushButton() {
        label1.setText(" Just doodle!");
        setTextField(false, false, false);
        editHBox.setVisible(false);
        canvas.setCursor(Cursor.DEFAULT);
        canvas.toFront();
        canvas.setOnMouseDragged(e -> Brushes.holidayBrush(e));
        canvas.setOnMousePressed(e -> onMouseDown(e));
    }

    @FXML
    public void quadraticButton() {
        label1.setText(" y = A * x^2 + B * x + C");
        setTextField(true, true, true, "A", "B", "C", "0.5", "0", "0");
        editHBox.setVisible(false);
        setBrushStatus();
        canvas.setCursor(Cursor.CROSSHAIR);
        canvas.toFront();
        canvas.setOnMouseDragged(e -> Brushes.quadraticBrush(e));
        canvas.setOnMousePressed(e -> Brushes.quadraticBrush(e));
    }

    @FXML
    public void drawRndRect() {
        label1.setPrefWidth(30);
        label2.setPrefWidth(30);
        label3.setPrefWidth(30);
        setTextField(true, true, true, "Number", "Max", "Min", "12", "50", "20");
        editHBox.setVisible(false);

        setBrushStatus();
        int number = (int) Brushes.getParA();
        double max = Brushes.getParB(), min = Brushes.getParC();

        canvas.setCursor(Cursor.DEFAULT);
        Brushes.drawRndRect(number, max, min);
        label1.setText("Random rectangles of Number: " + number + ", max size: " + max + ", min size: " + min);
    }

}
