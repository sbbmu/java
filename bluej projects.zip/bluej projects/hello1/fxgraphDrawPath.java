 

import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;

/**
 * Created by VHASFCSUNB on 9/6/2016.
 */
public class fxgraphDrawPath {
    private static undoGraphicsContext gc;
    public static void setGc(undoGraphicsContext gc) { fxgraphDrawPath.gc = gc; }

    public static void drawPath(MouseEvent e) {
        double x = e.getX(), y = e.getY();

        Color sColor, fColor;
        if (Brushes.getColorState() == ColorState.Random) {
            sColor = Color.rgb((int) (Math.random() * 256), (int) (Math.random() * 256), (int) (Math.random() * 256),
                    Math.random());
            fColor = Color.rgb((int) (Math.random() * 256), (int) (Math.random() * 256), (int) (Math.random() * 256),
                    Math.random());
        } else if (Brushes.getColorState() == ColorState.Position) {
            int r = Math.abs((int) e.getX() * 3) % 256, g = Math.abs((int) e.getY() % 256),
                    b = Math.abs((int) (e.getX() * 2 + e.getY()) % 256);
            sColor = Color.rgb(r, g, b);
            fColor = sColor;
        } else {
            sColor = Brushes.getStrokeColor();
            fColor = Brushes.getFillColor();
        }

        gc.setStroke(sColor);
        gc.setFill(fColor);
        double r = Brushes.getParA(), s = Brushes.getParB();

        gc.beginPath();
        gc.moveTo(x, y);
        gc.lineTo(x + 50 - s, y);
        gc.lineTo(x + 70 - s, y - 50);
        gc.bezierCurveTo(x + 70 + 100 - s, y - 50 - r, x + 70 - 200, y - 50 - r, x - 20, y - 50);
        gc.closePath();
        gc.stroke();
        if (Brushes.getIsFill())
            gc.fill();
    }

    public static void startPath(MouseEvent e) {
        drawPath(e);
    }
}
