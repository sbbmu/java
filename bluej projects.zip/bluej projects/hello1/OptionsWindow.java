 

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 * Created by Bing Sun1 on 9/11/2016.
 */
public class OptionsWindow {
    public static void diplay() {
        Stage window=new Stage();
        Button button1, button2;
        // Text fields
        TextField nameInput = new TextField();
        nameInput.setPromptText("Name");
        TextField ageInput = new TextField();
        ageInput.setPromptText("Age");

        HBox inputLayout = new HBox(10, nameInput, ageInput);
        inputLayout.setAlignment(Pos.CENTER);
        inputLayout.setPadding(new Insets(10, 10, 10, 10));

        // Buttons
        Label label = new Label();
        button1 = new Button("OK");
        button1.setOnAction(e -> {
            System.out.println(nameInput.getText() + ", " + ageInput.getText());
            label.setText(nameInput.getText() + ", " + ageInput.getText());
        });
        button2 = new Button("Close");
        button2.setOnAction(e -> window.close());

        HBox buttonLayout = new HBox(10);
        buttonLayout.setPadding(new Insets(10, 10, 10, 10));
        buttonLayout.setAlignment(Pos.CENTER);
        buttonLayout.getChildren().addAll(button1, button2);

        // root layout
        VBox vbox = new VBox(10);
        vbox.setAlignment(Pos.CENTER);
        vbox.getChildren().addAll(inputLayout, buttonLayout, label);

        window.setTitle("JavaFx Application");
        window.setScene(new Scene(vbox, 400, 300));
        window.show();
    }
}
