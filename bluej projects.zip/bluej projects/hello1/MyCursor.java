 

import javafx.scene.ImageCursor;
import javafx.scene.SnapshotParameters;
import javafx.scene.canvas.Canvas;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;
import javafx.scene.shape.Ellipse;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.Shape;

/**
 * Created by Bing Sun1 on 9/4/2016.
 */
public class MyCursor {

    public static void Rectangle(Canvas canvas, double w, double h) {
        Rectangle rectangle = new Rectangle(w, h);
        rectangle.setFill(Color.rgb(220,220,220,0.15));
        rectangle.setStroke(Color.BLACK);
        canvas.setCursor(new ImageCursor(rectangle.snapshot(null, null)));
    }
    public static void Ellipse(Canvas canvas, double w, double h) {

        Ellipse ellipse=new Ellipse(w/2,h/2);
        ellipse.setFill(Color.rgb(192,192,192,0.15));
        ellipse.setStroke(Color.BLACK);

//        Line lineH=new Line(0,h/2,w,h/2),lineV=new Line(w/2,0,w/2,h);
//        Shape shape;//= Shape.union(lineH,lineV);
//        shape=Shape.union(lineH,ellipse);

        SnapshotParameters sp = new SnapshotParameters();
        sp.setFill(Color.TRANSPARENT);
        Image img=ellipse.snapshot(sp, null);

        canvas.setCursor(new ImageCursor(img,img.getWidth()/2,img.getHeight()/2));
    }
}
