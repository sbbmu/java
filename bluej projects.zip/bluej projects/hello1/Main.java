
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.application.Platform;
import javafx.embed.swing.JFXPanel;
import java.io.IOException;

public class Main  {

    public void launchFX()
    {
        // Initialises JavaFX:
        new JFXPanel();
        // Makes sure JavaFX doesn't exit when first window is closed:
        Platform.setImplicitExit(false);
        // Runs initialisation on the JavaFX thread:
        Platform.runLater(() -> initialiseGUI());
    }

    public void initialiseGUI()
    {
        Stage window = new Stage();
        Group layout=new Group();
        try{
         layout = FXMLLoader.load(getClass().getResource("fxgraph.fxml"));
        }
        catch(IOException e){System.out.println(e);}

        window.setTitle("JavaFX 8 Test ground");
        window.setScene(new Scene(layout, 1000, 800));
        window.show();
        window.setVisible(true);
    }
}
