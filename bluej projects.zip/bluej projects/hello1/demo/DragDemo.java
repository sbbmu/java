package fxgraph;

/**
 * Created by VHASFCSUNB on 8/31/2016.
 */
import javafx.application.Application;
import javafx.scene.Cursor;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;

/**
 * @web http://java-buddy.blogspot.com/
 */
public class DragDemo extends Application {

    Circle circle_Red, circle_Green, circle_Blue;
    double orgSceneX, orgSceneY;
    double orgTranslateX, orgTranslateY;
    ImageView imageView=new ImageView(new Image(getClass().getResourceAsStream("test.png")));

    @Override
    public void start(Stage primaryStage) {
        System.out.println(System.getProperty("user.dir"));
        //Create Circles
        circle_Red = new Circle(50.0f, Color.RED);
        circle_Red.setCursor(Cursor.HAND);
        circle_Red.setOnMousePressed(e->onMousePressed(e));
        circle_Red.setOnMouseDragged(e->onMouseDragged(e));

        circle_Green = new Circle(50.0f, Color.GREEN);
        circle_Green.setCursor(Cursor.MOVE);
        circle_Green.setCenterX(150);
        circle_Green.setCenterY(150);
        circle_Green.setOnMousePressed(e->onMousePressed(e));
        circle_Green.setOnMouseDragged(e->onMouseDragged(e));

        circle_Blue = new Circle(50.0f, Color.BLUE);
        circle_Blue.setCursor(Cursor.CROSSHAIR);
        circle_Blue.setTranslateX(300);
        circle_Blue.setTranslateY(100);
        circle_Blue.setOnMousePressed(e->onMousePressed(e));
        circle_Blue.setOnMouseDragged(e->onMouseDragged(e));

        imageView.setOnMousePressed(this::imgOnMousePressed);
        imageView.setOnMouseDragged(this::imgOnMouseDragged);

        Group root = new Group();
        root.getChildren().addAll(circle_Red, circle_Green, circle_Blue,imageView);

//        primaryStage.setResizable(false);
        primaryStage.setScene(new Scene(root, 400,350));

        primaryStage.setTitle("java-buddy");
        primaryStage.show();
    }

    private void imgOnMouseDragged(MouseEvent t) {
        double offsetX = t.getSceneX() - orgSceneX;
        double offsetY = t.getSceneY() - orgSceneY;
        double newTranslateX = orgTranslateX + offsetX;
        double newTranslateY = orgTranslateY + offsetY;

        ((ImageView)(t.getSource())).setTranslateX(newTranslateX);
        ((ImageView)(t.getSource())).setTranslateY(newTranslateY);
    }

    private void imgOnMousePressed(MouseEvent t) {
        orgSceneX = t.getSceneX();
        orgSceneY = t.getSceneY();
        orgTranslateX = ((ImageView)(t.getSource())).getTranslateX();
        orgTranslateY = ((ImageView)(t.getSource())).getTranslateY();
    }

    private void onMouseDragged(MouseEvent t) {
        double offsetX = t.getSceneX() - orgSceneX;
        double offsetY = t.getSceneY() - orgSceneY;
        double newTranslateX = orgTranslateX + offsetX;
        double newTranslateY = orgTranslateY + offsetY;

        ((Circle)(t.getSource())).setTranslateX(newTranslateX);
        ((Circle)(t.getSource())).setTranslateY(newTranslateY);
    }

    private void onMousePressed(MouseEvent t) {
        orgSceneX = t.getSceneX();
        orgSceneY = t.getSceneY();
        orgTranslateX = ((Circle)(t.getSource())).getTranslateX();
        orgTranslateY = ((Circle)(t.getSource())).getTranslateY();
    }

    public static void main(String[] args) {
        launch(args);
    }


}
