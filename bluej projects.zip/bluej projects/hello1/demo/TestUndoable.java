// http://torgen-engineering.blogspot.com/2016/05/how-to-bring-undoredo-features-to-your.html#!/2016/05/how-to-bring-undoredo-features-to-your.html
// By: Arnaud Blouin
// Under: Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0)
//        https://creativecommons.org/licenses/by-nc-sa/4.0/

package fxgraph.demo;

import javafx.application.Application;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ToggleButton;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.net.URL;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.ResourceBundle;

/**
 * Created by VHASFCSUNB on 9/7/2016.
 */

interface Undoable {
    void undo();
    void redo();
    String getUndoRedoName();
}

final class UndoCollector {
    /**
     * The default undo/redo collector.
     */
    public static final UndoCollector INSTANCE = new UndoCollector();

    /**
     * Contains the undoable objects.
     */
    private final Deque<Undoable> undo;

    /**
     * Contains the redoable objects.
     */
    private final Deque<Undoable> redo;

    /**
     * The maximal number of undo.
     */
    private int sizeMax;

    private UndoCollector() {
        super();
        undo = new ArrayDeque<>();
        redo = new ArrayDeque<>();
        sizeMax = 30;
    }

    /**
     * Adds an undoable object to the collector.
     *
     * @param undoable The undoable object to add.
     */
    public void add(final Undoable undoable) {
        if (undoable != null && sizeMax > 0) {
            if (undo.size() == sizeMax) {
                undo.removeLast();
            }

            undo.push(undoable);
            redo.clear(); /* The redoable objects must be removed. */
        }
    }

    /**
     * Undoes the last undoable object.
     */
    public void undo() {
        if (!undo.isEmpty()) {
            final Undoable undoable = undo.pop();
            undoable.undo();
            redo.push(undoable);
        }
    }

    /**
     * Redoes the last undoable object.
     */
    public void redo() {
        if (!redo.isEmpty()) {
            final Undoable undoable = redo.pop();
            undoable.redo();
            undo.push(undoable);
        }
    }

    /**
     * @return The last undoable object name or "".
     */
    public String getLastUndoMessage() {
        return undo.isEmpty() ? "" : undo.peek().getUndoRedoName();
    }

    /**
     * @return The last redoable object name or "".
     */
    public String getLastRedoMessage() {
        return redo.isEmpty() ? "" : redo.peek().getUndoRedoName();
    }

    /**
     * @return The last undoable object or null.
     */
    public Undoable getLastUndo() {
        return undo.isEmpty() ? null : undo.peek();
    }

    /**
     * @return The last redoable object or null.
     */
    public Undoable getLastRedo() {
        return redo.isEmpty() ? null : redo.peek();
    }

    /**
     * @param max The max number of saved undoable objects. Must be great than 0.
     */
    public void setSizeMax(final int max) {
        if (max >= 0) {
            for (int i = 0, nb = undo.size() - max; i < nb; i++) {
                undo.removeLast();
            }
            this.sizeMax = max;
        }
    }
}

public class TestUndoable extends Application{

    @Override
    public void start(Stage primaryStage) throws Exception {
        VBox layout=new VBox(10);
        ToggleButton button=new ToggleButton("OK");
        Label label=new Label("");
        layout.getChildren().addAll(label,button);

        DummyModel model = new DummyModel();

        button.setOnAction(evt -> {
            IsItTrueOrNotCommand cmd = new IsItTrueOrNotCommand();
            cmd.setModel(model);
            cmd.setValue(button.isSelected());

            if (cmd.canExecute()) {
                cmd.execute();
                UndoCollector.INSTANCE.add(cmd);
            }
        });

        Stage window = primaryStage;
        window.setTitle("JavaFX 8 Test ground");
        window.setScene(new Scene(layout, 1000, 800));
        window.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}

//class DummyGuiController implements Initializable {
//    @FXML
//    ToggleButton button;
//
//    DummyModel model;
//
//    @Override
//    public void initialize(final URL location, final ResourceBundle resources) {
//        model = new DummyModel();
//
//        button.setOnAction(evt -> {
//            IsItTrueOrNotCommand cmd = new IsItTrueOrNotCommand();
//            cmd.setModel(model);
//            cmd.setValue(button.isSelected());
//
//            if (cmd.canExecute()) {
//                cmd.execute();
//                UndoCollector.INSTANCE.add(cmd);
//            }
//        });
//
//    }
//}

class DummyModel {
    private boolean value;

    boolean isItTrue() { return value; }

    void setIsTrueOrNot(boolean v) { value = v; }
}
interface Command {
    /**
     * Executes the command.
     */
    void execute();

    /**
     * Checks whether the command can be executed.
     */
    boolean canExecute();
}

class IsItTrueOrNotCommand implements Command, Undoable {
    private DummyModel model;
    private boolean value;
    private boolean formerValue;

    @Override
    public void execute() {
        formerValue = model.isItTrue();
        model.setIsTrueOrNot(value);
    }

    @Override
    public boolean canExecute() {
        return model != null;
    }

    public void setModel(final DummyModel dummyModel) {
        model = dummyModel;
    }

    public void setValue(final boolean val) {
        value = val;
    }

    @Override
    public void undo() {
        model.setIsTrueOrNot(formerValue);
    }

    @Override
    public void redo() {
        model.setIsTrueOrNot(value);
    }

    @Override
    public String getUndoRedoName() {
        return "Is is true or not";
    }
}


