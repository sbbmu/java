
/**
 * http://stackoverflow.com/questions/29506156/javafx-8-zooming-relative-to-mouse-pointer
 * By: Roland
 */

import javafx.application.Application;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.ScrollEvent;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

class PannableCanvas extends Pane {
    private DoubleProperty myScale = new SimpleDoubleProperty(1.0);

    public PannableCanvas(double w, double h) {
        setPrefSize(w, h);
        setStyle("-fx-background-color: #eeeeee; -fx-border-color: blue;");

        // add scale transform
        scaleXProperty().bind(myScale);
        scaleYProperty().bind(myScale);
    }

    /**
     * Add a grid to the canvas, send it to back
     */
    public void addGrid() {
        double w = getBoundsInLocal().getWidth();
        double h = getBoundsInLocal().getHeight();

        // add grid background
        Canvas grid = new Canvas(w, h);

        // don't catch mouse events
        grid.setMouseTransparent(true);

        GraphicsContext gc = grid.getGraphicsContext2D();
        gc.setStroke(Color.GRAY);
        gc.setLineWidth(.2);

        // draw grid lines
        double offset = 50;
        for (double i = offset; i < w; i += offset) {
            gc.strokeLine(i, 0, i, h);
            gc.strokeLine(0, i, w, i);
        }

        getChildren().add(grid);
        grid.toBack();
    }

    public double getScale() {
        return myScale.get();
    }

    public void setScale(double scale) {
        myScale.set(scale);
    }

    public void setPivot(double x, double y) {
        setTranslateX(getTranslateX() - x);
        setTranslateY(getTranslateY() - y);
    }
}

/**
 * Mouse drag context used for scene and nodes.
 */
class DragContext {
    double mouseAnchorX;
    double mouseAnchorY;
    double translateAnchorX;
    double translateAnchorY;
}

/**
 * Listeners for making the nodes draggable via left mouse button. Considers if parent is zoomed.
 */
class NodeGestures {
    PannableCanvas canvas;
    private DragContext nDC = new DragContext();
    private EventHandler<MouseEvent> onMousePressed = event -> {
            // left mouse button => dragging
            if (!event.isPrimaryButtonDown()) return;

            nDC.mouseAnchorX = event.getSceneX();
            nDC.mouseAnchorY = event.getSceneY();
            Node node = (Node) event.getSource();
            nDC.translateAnchorX = node.getTranslateX();
            nDC.translateAnchorY = node.getTranslateY();
        };
    private EventHandler<MouseEvent> onMouseDragged = event -> {
            // left mouse button => dragging
            if (!event.isPrimaryButtonDown()) return;

            double scale = canvas.getScale();
            Node node = (Node) event.getSource();
            node.setTranslateX(nDC.translateAnchorX + ((event.getSceneX() - nDC.mouseAnchorX) / scale));
            node.setTranslateY(nDC.translateAnchorY + ((event.getSceneY() - nDC.mouseAnchorY) / scale));
            event.consume();
        };

    public NodeGestures(PannableCanvas canvas) { this.canvas = canvas; }

    public EventHandler<MouseEvent> getOnMousePressed() {
        return onMousePressed;
    }

    public EventHandler<MouseEvent> getOnMouseDragged() {
        return onMouseDragged;
    }
}

/**
 * Listeners for making the scene's canvas draggable and zoomable
 */
class SceneGestures {
    private static final double MAX_SCALE = 10.0d;
    private static final double MIN_SCALE = .1d;
    PannableCanvas canvas;
    private DragContext sDC = new DragContext();
    private EventHandler<MouseEvent> onMousePressed = e -> {
            // right mouse button => panning
            if (!e.isSecondaryButtonDown()) return;

            sDC.mouseAnchorX = e.getSceneX();
            sDC.mouseAnchorY = e.getSceneY();
            sDC.translateAnchorX = canvas.getTranslateX();
            sDC.translateAnchorY = canvas.getTranslateY();
        };
    private EventHandler<MouseEvent> onMouseDragged = e -> {
            // right mouse button => panning
            if (!e.isSecondaryButtonDown()) return;

            canvas.setTranslateX(sDC.translateAnchorX + e.getSceneX() - sDC.mouseAnchorX);
            canvas.setTranslateY(sDC.translateAnchorY + e.getSceneY() - sDC.mouseAnchorY);
            e.consume();
        };
    /**
     * Mouse wheel handler: zoom to pivot point
     */
    private EventHandler<ScrollEvent> onScroll = e -> {
            double delta = 1.2;
            double scale = canvas.getScale(); // currently we only use Y, same value is used for X
            double oldScale = scale;

            if (e.getDeltaY() < 0) scale /= delta;
            else scale *= delta;

            scale = clamp(scale, MIN_SCALE, MAX_SCALE);

            double f = (scale / oldScale) - 1;
            double dx = (e.getSceneX() - (canvas.getBoundsInParent().getWidth() / 2 + canvas.getBoundsInParent().getMinX()));
            double dy = (e.getSceneY() - (canvas.getBoundsInParent().getHeight() / 2 + canvas.getBoundsInParent().getMinY()));

            canvas.setScale(scale);

            // note: pivot value must be untransformed, i. e. without scaling
            canvas.setPivot(f * dx, f * dy);
            e.consume();
        };

    public SceneGestures(PannableCanvas canvas) {
        this.canvas = canvas;
    }

    public static double clamp(double value, double min, double max) {
        if (Double.compare(value, min) < 0) return min;
        if (Double.compare(value, max) > 0) return max;
        return value;
    }

    public EventHandler<MouseEvent> getOnMousePressed() {
        return onMousePressed;
    }

    public EventHandler<MouseEvent> getOnMouseDragged() {
        return onMouseDragged;
    }

    public EventHandler<ScrollEvent> getOnScroll() {
        return onScroll;
    }
}

/**
 * An application with a zoomable and pannable canvas.
 */
// public class ZoomAndScrollApplication extends Application {
//     public static void main(String[] args) {
//         launch(args);
//     }
// 
//     @Override
//     public void start(Stage stage) {
//         Group group = new Group();
// 
//         // create canvas
//         PannableCanvas canvas = new PannableCanvas(600,600);
// 
//         // we don't want the canvas on the top/left in this example => just
//         // translate it a bit
//         canvas.setTranslateX(100);
//         canvas.setTranslateY(100);
// 
//         // create sample nodes which can be dragged
//         NodeGestures nodeGestures = new NodeGestures(canvas);
// 
//         Label label1 = new Label("Draggable node 1");
//         label1.setTranslateX(10);
//         label1.setTranslateY(10);
//         label1.addEventFilter(MouseEvent.MOUSE_PRESSED, nodeGestures.getOnMousePressed());
//         label1.addEventFilter(MouseEvent.MOUSE_DRAGGED, nodeGestures.getOnMouseDragged());
// 
//         Label label2 = new Label("Draggable node 2");
//         label2.setTranslateX(100);
//         label2.setTranslateY(100);
//         label2.addEventFilter(MouseEvent.MOUSE_PRESSED, nodeGestures.getOnMousePressed());
//         label2.addEventFilter(MouseEvent.MOUSE_DRAGGED, nodeGestures.getOnMouseDragged());
// 
//         Label label3 = new Label("Draggable node 3");
//         label3.setTranslateX(200);
//         label3.setTranslateY(200);
//         label3.addEventFilter(MouseEvent.MOUSE_PRESSED, nodeGestures.getOnMousePressed());
//         label3.addEventFilter(MouseEvent.MOUSE_DRAGGED, nodeGestures.getOnMouseDragged());
// 
//         Circle circle1 = new Circle(300, 300, 50);
//         circle1.setStroke(Color.ORANGE);
//         circle1.setFill(Color.ORANGE.deriveColor(1, 1, 1, 0.5));
//         circle1.addEventFilter(MouseEvent.MOUSE_PRESSED, nodeGestures.getOnMousePressed());
//         circle1.addEventFilter(MouseEvent.MOUSE_DRAGGED, nodeGestures.getOnMouseDragged());
// 
//         Rectangle rect1 = new Rectangle(100, 100);
//         rect1.setTranslateX(450);
//         rect1.setTranslateY(450);
//         rect1.setStroke(Color.BLUE);
//         rect1.setFill(Color.BLUE.deriveColor(1, 1, 1, 0.5));
//         rect1.addEventFilter(MouseEvent.MOUSE_PRESSED, nodeGestures.getOnMousePressed());
//         rect1.addEventFilter(MouseEvent.MOUSE_DRAGGED, nodeGestures.getOnMouseDragged());
// 
//         canvas.getChildren().addAll(label1, label2, label3, circle1, rect1);
// 
//         group.getChildren().add(canvas);
// 
//         // create scene which can be dragged and zoomed
//         Scene scene = new Scene(group, 1024, 768);
// 
//         SceneGestures sceneGestures = new SceneGestures(canvas);
//         scene.addEventFilter(MouseEvent.MOUSE_PRESSED, sceneGestures.getOnMousePressed());
//         scene.addEventFilter(MouseEvent.MOUSE_DRAGGED, sceneGestures.getOnMouseDragged());
//         scene.addEventFilter(ScrollEvent.ANY, sceneGestures.getOnScroll());
// 
//         stage.setScene(scene);
//         stage.show();
// 
//         canvas.addGrid();
//     }
// }