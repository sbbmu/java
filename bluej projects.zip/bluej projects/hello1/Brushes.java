 

import javafx.geometry.Point2D;
import javafx.scene.SnapshotParameters;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.PixelReader;
import javafx.scene.image.PixelWriter;
import javafx.scene.image.WritableImage;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.StrokeLineCap;
import javafx.scene.shape.StrokeLineJoin;
import javafx.scene.text.Font;

/**
 * Created by VHASFCSUNB on 8/26/2016.
 */
enum ColorState {
    Position, Random, Fixed
}

public class Brushes {
    private static double x0, y0, x1, y1;
    private static double parA,parB,parC,lwd;
    private static boolean isFill, isStroke, isRndLwd, isSelectionSet, isSHIFT;
    private static Color strokeColor, fillColor;
    private static ColorState colorState;
    private static WritableImage copiedImage;
    private static Rectangle selectionBounds = new Rectangle();
    private static undoGraphicsContext gc;

    public static void setGc(undoGraphicsContext gc) { Brushes.gc = gc; }

    public static boolean isSelectionSet() {
        return isSelectionSet;
    }
    public static void setIsSelectionSet(boolean isSelectionSet) {
        Brushes.isSelectionSet = isSelectionSet;
    }

    public static void setIsSHIFT(boolean isSHIFT) {
        Brushes.isSHIFT = isSHIFT;
    }

    public static void setIsStroke(boolean isStroke) {
        Brushes.isStroke = isStroke;
    }

    public static void setIsFill(boolean isFill) {
        Brushes.isFill = isFill;
    }
    public static boolean getIsFill() { return isFill; }

    public static ColorState getColorState() { return colorState; }
    public static void setColorState(ColorState cs) { colorState = cs; }

    public static void setLwd(double lwd) {
        Brushes.lwd = lwd;
    }
    public static double getLwd() { return lwd; }

    public static void setX0(double x0) {
        Brushes.x0 = x0;
    }
    public static void setY0(double y0) {
        Brushes.y0 = y0;
    }
    public static void setX1(double x1) {
        Brushes.x1 = x1;
    }
    public static void setY1(double y1) {
        Brushes.y1 = y1;
    }

    public static Color getStrokeColor() {
        return strokeColor;
    }
    public static void setStrokeColor(Color strokeColor) {
        Brushes.strokeColor = strokeColor;
    }

    public static Color getFillColor() {
        return fillColor;
    }
    public static void setFillColor(Color fillColor) {
        Brushes.fillColor = fillColor;
    }

    static double getParA() {
        return parA;
    }
    static void setParA(double parA) {
        Brushes.parA = parA;
    }

    static double getParB() {
        return parB;
    }
    static void setParB(double parB) {
        Brushes.parB = parB;
    }

    static double getParC() {
        return parC;
    }
    static void setParC(double parC) {
        Brushes.parC = parC;
    }

    /**
     * Clear background
     */
    static void GCClear(GraphicsContext gc) {
        gc.clearRect(0, 0, gc.getCanvas().getWidth(), gc.getCanvas().getHeight());
    }

    /**
     * setup canvas
     */
    private static void setGCStatus(MouseEvent e) {
        setGCLineWidth();
        setGCStrokeColor(e);
        setGCFillColor(e);
    }

    public static double getX0() {
        return x0;
    }

    public static double getY0() {
        return y0;
    }

    private static void setGCStrokeColor(MouseEvent e) {
        if (colorState == ColorState.Position) {
                gc.setStroke(Utils.positionColor(e));
        } else if (colorState == ColorState.Random) {
            gc.setStroke(Utils.randomColor());
        } else {
            gc.setStroke(strokeColor);
        }
    }

    private static void setGCFillColor(MouseEvent e) {
        if (colorState == ColorState.Position) {
                gc.setFill(Utils.positionColor(e));
        } else if (colorState == ColorState.Random) {
            gc.setFill(Utils.randomColor());
        } else {
            gc.setFill(getFillColor());
        }
    }

    private static void setGCLineWidth() {
        double lw;
        if (isRndLwd) lw = Math.random() * lwd;
        else lw = lwd;
        gc.setLineWidth(lw);
    }

    /** selection*/
    public static void selectOnMouseReleased(MouseEvent e, Canvas canvas, GraphicsContext gc2) {
        double x = e.getX(), y = e.getY();

        selectionBounds.setX(Math.min(x, x0));
        selectionBounds.setY(Math.min(y, y0));
        selectionBounds.setWidth(Math.abs(x - x0));
        selectionBounds.setHeight(Math.abs(y - y0));
    }

    public static Rectangle getSelectionBounds() {
        return selectionBounds;
    }

    public static WritableImage copyImage(Canvas canvas, Rectangle selectionBounds) {
        SnapshotParameters sp = new SnapshotParameters();
        sp.setFill(Color.TRANSPARENT);
        WritableImage srcImage = canvas.snapshot(sp, null);
        PixelReader pixelReader = srcImage.getPixelReader();
        int w = (int) selectionBounds.getWidth(), h = (int) selectionBounds.getHeight();

        //Copy from source to destination pixel by pixel
        WritableImage destImage = new WritableImage(w, h);
        PixelWriter pixelWriter = destImage.getPixelWriter();

        for (int yi = 0; yi < h; yi++) {
            for (int xi = 0; xi < w; xi++) {
                Color color = pixelReader.getColor((int) selectionBounds.getX() + xi, (int) selectionBounds.getY() + yi);
                pixelWriter.setColor(xi, yi, color);
            }
        }
        return destImage;
    }


    /**
     * brushes
     */
    static void drawFreeHand(MouseEvent e) {
        double x = e.getX(), y = e.getY();
        gc.strokeLine(x0, y0, x, y);
        setX0(x);
        setY0(y);
    }
    static void startFreeHand(MouseEvent e) {
        MyCursor.Ellipse(gc.getCanvas(), lwd, lwd);
        setGCStatus(e);
        gc.setLineCap(StrokeLineCap.ROUND);
        gc.setLineJoin(StrokeLineJoin.ROUND);
        gc.strokeLine(x0, y0, x0, y0);
    }

    static void drawErase(MouseEvent e) {
        double x = e.getX(), y = e.getY();
        gc.clearRect(x + 1, y + 1, parA, parB);
    }
    static void startErase(MouseEvent e) {
        MyCursor.Rectangle(gc.getCanvas(), parA, parB);
        double x = e.getX(), y = e.getY();
        gc.clearRect(x + 1, y + 1, parA, parB);
    }

    static void lineOnMouseReleased(MouseEvent e, GraphicsContext gc2) {
        GCClear(gc2);
        int amount = (int) parA;
        double distance = parB;
        double x = e.getX(), y = e.getY();
        if (isSHIFT) y = y0;
        Point2D p0 = new Point2D(x0, y0), p1 = new Point2D(x, y), p3 = new Point2D(1, 0); // p3 is a vector on x axis
        double theta = p3.angle(p1.subtract(p0)), at = Math.toRadians(theta);  //  vector math for angles

        if (y0 < y) at = -at;
        double dx = distance * Math.sin(at), dy = distance * Math.cos(at);

        for (int i = 0; i < amount; i++) {
            double d = i - (amount - 1) / 2.0; // adjust center of line start points
            setGCStatus(e);
            gc.strokeLine(x0 + dx * d, y0 + dy * d, x + dx * d, y + dy * d);
        }
    }

    static void drawLine(MouseEvent e, GraphicsContext gc2) {
        double x = e.getX(), y = e.getY();
        GCClear(gc2);
        gc2.setStroke(Color.BLACK);
        gc2.setLineWidth(1);
        gc2.setLineDashes(10f);
        if (isSHIFT) y = y0;
        gc2.strokeLine(x0, y0, x, y);
    }

    static void rectOnMouseReleased(MouseEvent e, GraphicsContext gc2) {
        double x = e.getX(), y = e.getY();
        setGCStatus(e);
        if (isFill) gc.fillRect(selectionBounds.getX(), selectionBounds.getY(), Math.abs(x - x0), Math.abs(y - y0));
        if (isStroke) gc.strokeRect(selectionBounds.getX(), selectionBounds.getY(), Math.abs(x - x0), Math.abs(y - y0));
        GCClear(gc2);
    }

    static void drawRect(MouseEvent e, GraphicsContext gc2) {
        double x = e.getX(), y = e.getY();
        double gcW = gc2.getCanvas().getWidth(), gcH = gc2.getCanvas().getHeight();
        if (x > gcW) x = gcW;
        if (y > gcH) y = gcH;
        if (x < 0) x = 0;
        if (y < 0) y = 0;

        selectionBounds.setX(Math.min(x, x0));
        selectionBounds.setY(Math.min(y, y0));
        selectionBounds.setWidth(Math.abs(x - x0));
        selectionBounds.setHeight(Math.abs(y - y0));

        GCClear(gc2);
        gc2.setStroke(Color.BLACK);
        gc2.setLineWidth(1);
        gc2.setLineDashes(5f);
        gc2.strokeRect(selectionBounds.getX(), selectionBounds.getY(), selectionBounds.getWidth(), selectionBounds.getHeight());
    }

    static void ovalOnMouseReleased(MouseEvent e, GraphicsContext gc2) {
        setGCStatus(e);
        if (isFill)
            gc.fillOval(selectionBounds.getX(), selectionBounds.getY(), selectionBounds.getWidth(), selectionBounds.getHeight());
        if (isStroke)
            gc.strokeOval(selectionBounds.getX(), selectionBounds.getY(), selectionBounds.getWidth(), selectionBounds.getHeight());
        GCClear(gc2);
    }

    static void drawOval(MouseEvent e, GraphicsContext gc2) {
        double x = e.getX(), y = e.getY();
        GCClear(gc2);
        gc2.setStroke(Color.BLACK);
        gc2.setLineWidth(1);
        gc2.setLineDashes(5f);//new double[]{5f,3f}

        selectionBounds.setX(Math.min(x, x0));
        selectionBounds.setY(Math.min(y, y0));
        selectionBounds.setWidth(Math.abs(x - x0));
        selectionBounds.setHeight(Math.abs(y - y0));

        gc2.strokeOval(selectionBounds.getX(), selectionBounds.getY(), selectionBounds.getWidth(), selectionBounds.getHeight());
    }

    static void polyBrush(MouseEvent e) {
        int nVertices = (int) parA;
        double r = parB, rotation = parC / 180 * Math.PI;
        setGCStatus(e);
        double centerX = e.getX(), centerY = e.getY();
        double angle = Math.PI / nVertices * 2;
        PointsArray p = new PointsArray();

        for (int i = 0; i < nVertices; i++) {
            double x = centerX + Math.cos(i * angle - rotation) * r; // 5 point star rotation=angle/2= 18 degrees
            double y = centerY + Math.sin(i * angle - rotation) * r;
            p.add(x, y);
        }

        if (isFill) gc.fillPolygon(p.getaX(), p.getaY(), p.length());
        if (isStroke) gc.strokePolygon(p.getaX(), p.getaY(), p.length());
    }

    static void starBrush(MouseEvent e) {
        int nVertices = (int) parA;
        double outerR = parB, innerR = outerR / 3, rotation = parC / 180 * Math.PI;
        setGCStatus(e);
        PointsArray p = computeStar(e.getX(), e.getY(), nVertices, outerR, innerR, rotation);

        if (isFill) gc.fillPolygon(p.getaX(), p.getaY(), p.length());
        if (isStroke) gc.strokePolygon(p.getaX(), p.getaY(), p.length());
    }

    private static PointsArray computeStar(double centerX, double centerY, int nVertices, double outerR, double innerR, double rotation) {
        PointsArray p = new PointsArray();
        double angle = Math.PI / nVertices;

        for (int i = 0; i < 2 * nVertices; i++) {
            double r = (i % 2 == 0) ? outerR : innerR;
            double x = centerX + Math.cos(i * angle - rotation) * r; // 5 point star rotation=angle/2= 18 degrees
            double y = centerY + Math.sin(i * angle - rotation) * r;
            p.add(x, y);
        }
        return p;
    }

    static void sineBrush(MouseEvent e) {
        int a = (int) parA;
        double b = parB, c = parC / 180 * Math.PI;
        double Y = isSHIFT ? y1 : e.getY();
        double x = e.getX(), y = a * Math.sin(b * x / 10.0 + c) + Y;
        setGCStatus(e);
        gc.setLineCap(StrokeLineCap.ROUND);
        gc.setLineJoin(StrokeLineJoin.ROUND);
        if (x1 != x0) gc.strokeLine(x0, y0, x, y);
        setX0(x);
        setY0(y);
    }

    static void roseBrush(MouseEvent e) {
        setGCStatus(e);
        gc.setLineCap(StrokeLineCap.ROUND);
        gc.setLineJoin(StrokeLineJoin.ROUND);

        int k = (int) parA;
        double a = parB, rotation = parC / 180 * Math.PI;

        x0 = a * Math.cos(k * 0) * Math.cos(0 + rotation) + e.getX();
        x1 = x0;
        y0 = a * Math.cos(k * 0) * Math.sin(0 + rotation) + e.getY();
        y1 = y0;
        for (double i = 0; i <= Math.PI * 2; i += 0.02) {
            double x = a * Math.cos(k * i) * Math.cos(i + rotation) + e.getX();
            double y = a * Math.cos(k * i) * Math.sin(i + rotation) + e.getY();
            gc.strokeLine(x0, y0, x, y);
            x0 = x;
            y0 = y;
        }
        //close the line
        gc.strokeLine(x0, y0, x1, y1);
    }

    static void hozMirrorBrush(MouseEvent e) {
        double x = e.getX(), y = e.getY();
        double w = gc.getCanvas().getWidth();

        setGCStatus(e);
        gc.setLineCap(StrokeLineCap.ROUND);
        gc.setLineJoin(StrokeLineJoin.ROUND);
        gc.strokeLine(x0, y0, x, y);
        gc.strokeLine(Math.abs(w - x0), y0, Math.abs(w - x), y);
        setX0(x);
        setY0(y);
    }

    static void vertMirrorBrush(MouseEvent e) {
        double x = e.getX(), y = e.getY();
        double h = gc.getCanvas().getHeight();

        setGCStatus(e);
        gc.setLineCap(StrokeLineCap.ROUND);
        gc.setLineJoin(StrokeLineJoin.ROUND);
        gc.strokeLine(x0, y0, x, y);
        gc.strokeLine(x0, Math.abs(h - y0), x, Math.abs(h - y));
        setX0(x);
        setY0(y);
    }

    static void fourMirrorBrush(MouseEvent e) {
        double x = e.getX(), y = e.getY();
        double w = gc.getCanvas().getWidth(), h = gc.getCanvas().getHeight();

        setGCStatus(e);
        gc.setLineCap(StrokeLineCap.ROUND);
        gc.setLineJoin(StrokeLineJoin.ROUND);
        gc.strokeLine(x0, y0, x, y);
        gc.strokeLine(x0, Math.abs(h - y0), x, Math.abs(h - y));
        gc.strokeLine(Math.abs(w - x0), y0, Math.abs(w - x), y);
        gc.strokeLine(Math.abs(w - x0), Math.abs(h - y0), Math.abs(w - x), Math.abs(h - y));
        setX0(x);
        setY0(y);
    }

    static void paintText(MouseEvent e, String text, String font, double fontSize) {
        double x = e.getX(), y = e.getY();
        setGCStatus(e);

        gc.setFont(new Font(font, fontSize));
        if (isStroke)
            gc.strokeText(text, x, y);
        if (isFill)
            gc.fillText(text, x, y);
    }

    static void drawSparkles(MouseEvent e) {
        double x = e.getX(), y = e.getY();
        double number = parA, spread = parB, size = parC;
        for (int i = 0; i < number; i++) {
            setGCStatus(e);
            double theta = Math.random() * Math.PI * 2;
            double r = spread * Math.random();
            if (isFill) gc.fillOval(x + Math.cos(theta) * r, y + Math.sin(theta) * r, size, size);
            if (isStroke) gc.strokeOval(x + Math.cos(theta) * r, y + Math.sin(theta) * r, size, size);
        }
    }

    static void holidayBrush(MouseEvent e) {

        double x = e.getX(), y = e.getY();
        int r = Math.abs((int) x % 256), g = Math.abs((int) y % 256), b = Math.abs((int) (x * 2 + y) % 256);
        gc.setStroke(Color.rgb(r, g, b));
        gc.setLineWidth(Math.sin((x / 2 * Math.sqrt(y))) * 5);
        gc.strokeLine(x0, y0, x, y);
        gc.setFill(Color.rgb((int) (Math.random() * 256), (int) (Math.random() * 256), (int) (Math.random() * 256), Math.random()));
        gc.fillOval(x - Math.random() * 2, y - Math.random() * 2, Math.random() * 30, Math.random() * 30);
        setX0(x);
        setY0(y);
    }

    static void drawRndRect(int number, double maxSize, double minSize) {
        double x1, y1, w, h;

        for (int i = 0; i < number; i++) {
            x1 = (int) (Math.random() * gc.getCanvas().getWidth());
            y1 = (int) (Math.random() * gc.getCanvas().getHeight());
            w = (int) (Math.random() * Math.abs(maxSize - minSize) + minSize);
            h = (int) (Math.random() * Math.abs(maxSize - minSize) + minSize);

            MouseEvent e = new MouseEvent(MouseEvent.MOUSE_MOVED, x1, y1, x1, y1, MouseButton.NONE, 1,
                    false, false, false, false, false, false, false, false, false, false, null);

            setGCStatus(e);
            if (isStroke) gc.strokeRect(x1, y1, w, h);
            if (isFill) gc.fillRect(x1, y1, w, h);
        }
    }

    static void quadraticBrush(MouseEvent e) {
        double x0 = e.getX(), y0 = e.getY();
        double a = parA, b = parB, c = parC;
        double x1 = 0, y1 = 0, scale = 20;
        Color sColor;

        // stroke color
        if (colorState==ColorState.Random) {
            sColor = Utils.randomColor();
        } else if(colorState==ColorState.Position){
            sColor = Utils.positionColor(e);
        }
        else{
            sColor = strokeColor;
        }

        setGCStatus(e);
        gc.setStroke(sColor);

        for (int i = -12; i <= 12; i++) { // single quadratic
            double x = i / 4.0;
            double y = -a * x * x + b * x + c;
            if (i == -12) {
                x1 = x;
                y1 = y;
            }

            gc.strokeLine(x * scale + x0, y * scale + y0, x1 * scale + x0, y1 * scale + y0);
            x1 = x;
            y1 = y;
        }
    }


}

