 

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 * Created by VHASFCSUNB on 9/6/2016.
 */
public class About {
    public static void show() {
        Stage window = new Stage();
        Label text = new Label("A painter program implemented using Java Fx 8.0. \n\n Version: 0.1 \n By Bing Sun \n\n \n\n\n\n 2016-9-6");
        text.setAlignment(Pos.CENTER);
        Button btn = new Button("OK");
        btn.setOnAction(e -> window.close());

        VBox layout = new VBox(50);
        layout.setPadding(new Insets(10, 10, 10, 10));
        layout.setAlignment(Pos.CENTER);
        layout.getChildren().addAll(text, btn);

        window.setTitle("About");
        window.setScene(new Scene(layout, 400, 300));
        window.show();
    }

}
