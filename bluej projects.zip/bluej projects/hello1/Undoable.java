 

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.VPos;
import javafx.scene.Scene;
import javafx.scene.SnapshotParameters;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.effect.BlendMode;
import javafx.scene.effect.Effect;
import javafx.scene.image.Image;
import javafx.scene.image.PixelWriter;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;
import javafx.scene.shape.ArcType;
import javafx.scene.shape.FillRule;
import javafx.scene.shape.StrokeLineCap;
import javafx.scene.shape.StrokeLineJoin;
import javafx.scene.text.Font;
import javafx.scene.text.FontSmoothingType;
import javafx.scene.text.TextAlignment;
import javafx.scene.transform.Affine;
import javafx.stage.Stage;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Iterator;


/**
 * Created by Bing Sun1 on 9/7/2016.
 */
//interface Undoable {
//    void undo();
//
//    void redo();
//
//    String getUndoRedoName();
//}
class Undoable {
    private String name;
    private double x, y, w, h, dx, dy, dw, dh;
    private double maxWidth, startAngle, arcWidth, arcHeight, arcExtent;
    private double[] xPoints, yPoints;
    private int nPoints;
    private Affine xform;
    private ArcType closure;
    private GCState state;
    private String text; // also for "svgpath";
    private Image img;
    private Effect effect;

    public Undoable(String name, double x, double y, double w, double h, GCState state) {
        this.name = name;
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
        this.state = state;
    }

    public Undoable(String name, String text, double x, double y, double maxWidth, GCState state) {
        this.name = name;
        this.text = text;
        this.x = x;
        this.y = y;
        this.maxWidth = maxWidth;
        this.state = state;
    }

    public Undoable(String name, double x, double y, double w, double h, double arcWidth, double arcHeight, GCState gcState) {
        this.name = name;
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
        this.arcWidth = arcWidth;
        this.arcHeight = arcHeight;
        state = gcState;
    }

    public Undoable(String name, double x, double y, double w, double h, double startAngle, double arcExtent, ArcType closure, GCState gcState) {
        this.name = name;
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
        this.startAngle = startAngle;
        this.arcExtent = arcExtent;
        this.closure = closure;
        state = gcState;
    }

    public Undoable(String name, double[] xPoints, double[] yPoints, int nPoints, GCState gcState) {
        this.name = name;
        this.xPoints = xPoints;
        this.yPoints = yPoints;
        this.nPoints = nPoints;
        state = gcState;
    }

    public Undoable(String name, Image img, double x, double y, double w, double h, GCState gcState) {
        this.name = name;
        this.img = img;
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
        state = gcState;
    }

    public Undoable(String name, Image img, double x, double y, double w, double h, double dx, double dy, double dw, double dh, GCState gcState) {
        this.name = name;
        this.img = img;
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
        this.dx = dx;
        this.dy = dy;
        this.dw = dw;
        this.dh = dh;
        state = gcState;
    }

    public Undoable(String name, Effect e, GCState gcState) {
        this.name = name;
        this.effect = e;
        state = gcState;
    }

    public Undoable(String name, Affine xform, GCState gcState) {
        this.name = name;
        this.xform = xform;
        state = gcState;
    }

    public Undoable(String name, GCState gcState) {
        this.name = name;
        state = gcState;
    }

    public Undoable(String name, String svgpath, GCState gcState) {
        this.name = name;
        this.text = svgpath;
        state = gcState;
    }

    public double getX() { return x; }

    public double getY() { return y; }

    public double getW() { return w; }

    public double getH() { return h; }

    public GCState getState() { return state; }

    public String getName() { return name; }

    public String getText() { return text; }

    public double getMaxWidth() { return maxWidth; }

    public double getArcWidth() { return arcWidth; }

    public double getArcHeight() { return arcHeight; }

    public double getStartAngle() { return startAngle; }

    public double getArcExtent() { return arcExtent; }

    public ArcType getClosure() { return closure; }

    public double[] getxPoints() { return xPoints; }

    public double[] getyPoints() { return yPoints; }

    public int getnPoints() { return nPoints; }

    public Image getImg() { return img; }

    public double getDx() { return dx; }

    public double getDy() { return dy; }

    public double getDw() { return dw; }

    public double getDh() { return dh; }

    public Effect getEffect() { return effect; }

    public Affine getXform() { return xform; }

}

final class UndoCollector {
    /**
     * The default undo/redo collector.
     */
    public static final UndoCollector INSTANCE = new UndoCollector();

    /**
     * Contains the undoable objects.
     */
    private final Deque<Undoable> undo;

    /**
     * Contains the redoable objects.
     */
    private final Deque<Undoable> redo;
    /**
     * The maximal number of undo.
     */
    private int sizeMax;

    private UndoCollector() {
        super();
        undo = new ArrayDeque<>();
        redo = new ArrayDeque<>();
        sizeMax = 60;
    }

    public Deque<Undoable> getUndo() {
        return undo;
    }

    /**
     * Adds an undoable object to the collector.
     *
     * @param undoable The undoable object to add.
     */
    public Undoable add(final Undoable undoable) {
        Undoable last = null;
        if (undoable != null && sizeMax > 0) {
            if (undo.size() == sizeMax) {
                last = undo.peekLast();
                undo.removeLast();
            }

            undo.push(undoable);
            redo.clear(); /* The redoable objects must be removed. */
        }
        return last;
    }

    /**
     * Undoes the last undoable object.
     */
    public void undo() {
        if (!undo.isEmpty()) {
            final Undoable undoable = undo.pop();
//            undoable.undo();
            redo.push(undoable);
        }
    }

    /**
     * Redoes the last undoable object.
     */
    public void redo() {
        if (!redo.isEmpty()) {
            final Undoable undoable = redo.pop();
//            undoable.redo();
            undo.push(undoable);
        }
    }

    /**
     * @return The last undoable object name or "".
     */
    public String getLastUndoMessage() {
        return undo.isEmpty() ? "" : undo.peek().getName();
    }

    /**
     * @return The last redoable object name or "".
     */
    public String getLastRedoMessage() {
        return redo.isEmpty() ? "" : redo.peek().getName();
    }

    /**
     * @return The last undoable object or null.
     */
    public Undoable getLastUndo() {
        return undo.isEmpty() ? null : undo.peek();
    }

    /**
     * @return The last redoable object or null.
     */
    public Undoable getLastRedo() {
        return redo.isEmpty() ? null : redo.peek();
    }

    /**
     * @param max The max number of saved undoable objects. Must be great than 0.
     */
    public void setSizeMax(final int max) {
        if (max >= 0) {
            for (int i = 0, nb = undo.size() - max; i < nb; i++) {
                undo.removeLast();
            }
            this.sizeMax = max;
        }
    }
}

class GCState {
    private double globalAlpha;
    private BlendMode blendop;
    //  private Affine2D transform;
    private Affine transform;
    private Paint fill;
    private Paint stroke;
    private double linewidth;
    private StrokeLineCap linecap;
    private StrokeLineJoin linejoin;
    private double miterlimit;
    private double dashes[];
    private double dashOffset;
    //    private int numClipPaths;
    private Font font;
    private FontSmoothingType fontsmoothing;
    private TextAlignment textalign;
    private VPos textbaseline;
    private Effect effect;
    private FillRule fillRule;

//    GCState() {
//        init();
//    }

    GCState(GraphicsContext gc) {
        get(gc);
    }

//    final void init() {
//        set(1.0, BlendMode.SRC_OVER, new Affine(), Color.BLACK, Color.BLACK, 1.0,
//                StrokeLineCap.SQUARE, StrokeLineJoin.MITER, 10.0, null, 0.0, //0,
//                Font.getDefault(), FontSmoothingType.GRAY,
//                TextAlignment.LEFT, VPos.BASELINE, null, FillRule.NON_ZERO);
//    }

//    GCState(GCState copy) {
//        set(copy.globalAlpha, copy.blendop, copy.transform, copy.fill, copy.stroke,
//                copy.linewidth, copy.linecap, copy.linejoin, copy.miterlimit,
//                copy.dashes, copy.dashOffset, //copy.numClipPaths,
//                copy.font, copy.fontsmoothing, copy.textalign, copy.textbaseline,
//                copy.effect, copy.fillRule);
//    }

//    final void set(double globalAlpha, BlendMode blendop,
//                   Affine transform, Paint fill, Paint stroke,
//                   double linewidth, StrokeLineCap linecap,
//                   StrokeLineJoin linejoin, double miterlimit,
//                   double dashes[], double dashOffset,
////                   int numClipPaths,
//                   Font font, FontSmoothingType smoothing,
//                   TextAlignment align, VPos baseline,
//                   Effect effect, FillRule fillRule) {
//        this.globalAlpha = globalAlpha;
//        this.blendop = blendop;
//        this.transform = transform;
//        this.fill = fill;
//        this.stroke = stroke;
//        this.linewidth = linewidth;
//        this.linecap = linecap;
//        this.linejoin = linejoin;
//        this.miterlimit = miterlimit;
//        this.dashes = dashes;
//        this.dashOffset = dashOffset;
////        this.numClipPaths = numClipPaths;
//        this.font = font;
//        this.fontsmoothing = smoothing;
//        this.textalign = align;
//        this.textbaseline = baseline;
//        this.effect = effect;
//        this.fillRule = fillRule;
//    }

//    GCState copy() {
//        return new GCState(this);
//    }

    void restore(GraphicsContext gc) {
        gc.setGlobalAlpha(globalAlpha);
        gc.setGlobalBlendMode(blendop);
//        ugc.setTransform(transform.getMxx(), transform.getMyx(),
//                transform.getMxy(), transform.getMyy(),
//                transform.getMxt(), transform.getMyt());
        gc.setTransform(transform);
        gc.setFill(fill);
        gc.setStroke(stroke);
        gc.setLineWidth(linewidth);
        gc.setLineCap(linecap);
        gc.setLineJoin(linejoin);
        gc.setMiterLimit(miterlimit);
        gc.setLineDashes(dashes);
        gc.setLineDashOffset(dashOffset);
//        GrowableDataBuffer buf = ugc.getBuffer();
//        while (ugc.curState.numClipPaths > numClipPaths) {
//            ugc.curState.numClipPaths--;
//            ugc.clipStack.removeLast();
//            buf.putByte(NGCanvas.POP_CLIP);
//        }
        gc.setFillRule(fillRule);
        gc.setFont(font);
        gc.setFontSmoothingType(fontsmoothing);
        gc.setTextAlign(textalign);
        gc.setTextBaseline(textbaseline);
        gc.setEffect(effect);
    }

    GCState get(GraphicsContext gc) {
        this.globalAlpha = gc.getGlobalAlpha();
        this.blendop = gc.getGlobalBlendMode();
        this.transform = gc.getTransform();
        this.fill = gc.getFill();
        this.stroke = gc.getStroke();
        this.linewidth = gc.getLineWidth();
        this.linecap = gc.getLineCap();
        this.linejoin = gc.getLineJoin();
        this.miterlimit = gc.getMiterLimit();
        this.dashes = gc.getLineDashes();
        this.dashOffset = gc.getLineDashOffset();
//        this.numClipPaths = ugc.numClipPaths;
        this.font = gc.getFont();
        this.fontsmoothing = gc.getFontSmoothingType();
        this.textalign = gc.getTextAlign();
        this.textbaseline = gc.getTextBaseline();
        this.effect = gc.getEffect(effect);
        this.fillRule = gc.getFillRule();
        return this;
    }
}

class undoGraphicsContext {
    GraphicsContext gc;
    GCState state;
    Image image; // used to save none undoable, finished drawings

    // constructor
    public undoGraphicsContext(Canvas uc) {
        gc = uc.getGraphicsContext2D();
        state = new GCState(gc);
    }

    //draw the base image that can not be undone
    private void drawFixed(Undoable last) {
        gc.clearRect(0, 0, gc.getCanvas().getWidth(), gc.getCanvas().getHeight());
        if (image != null) gc.drawImage(image, 0, 0);
        drawCmd(last);

        SnapshotParameters sp = new SnapshotParameters();
        sp.setFill(Color.TRANSPARENT);
        image = gc.getCanvas().snapshot(sp, null);
    }

    private void drawStack() {
        Deque<Undoable> commandStack = UndoCollector.INSTANCE.getUndo();
        Iterator<Undoable> iter = commandStack.descendingIterator();
        for (int i = 0; i < commandStack.size(); i++) {
            Undoable cmd = iter.next();
            drawCmd(cmd);
        }
    }

    public void redraw(Undoable last) {
        if (last != null) drawFixed(last);
        redraw();
    }

    public void redraw() {
        gc.clearRect(0, 0, gc.getCanvas().getWidth(), gc.getCanvas().getHeight());
        if (image != null) gc.drawImage(image, 0, 0);
        drawStack();
    }

    public GCState getGCState(GraphicsContext sgc) {
        state = state.get(sgc);
        return state;
    }

    public void setGCState(GraphicsContext sgc) {
        state.restore(sgc);
    }

    // non-undoable: getters
    public Canvas getCanvas() {
        return gc.getCanvas();
    }

    public double getGlobalAlpha() {
        return gc.getGlobalAlpha();
    }

    public void setGlobalAlpha(double alpha) {
        Undoable last = UndoCollector.INSTANCE.add(new Undoable("setGlobalAlpha", alpha, 0, 0, 0, new GCState(gc)));
        redraw(last);
    }

    public BlendMode getGlobalBlendMode() {
        return gc.getGlobalBlendMode();
    }

    public void setGlobalBlendMode(BlendMode op) {
        gc.setGlobalBlendMode(op);
    }

    public Paint getFill() {
        return gc.getFill();
    }

    public void setFill(Paint p) {
        gc.setFill(p);
    }

    public Paint getStroke() {
        return gc.getStroke();
    }

    public void setStroke(Paint p) {
        gc.setStroke(p);
    }

    public StrokeLineCap getLineCap() {
        return gc.getLineCap();
    }

    public void setLineCap(StrokeLineCap cap) {
        gc.setLineCap(cap);
    }

    public StrokeLineJoin getLineJoin() {
        return gc.getLineJoin();
    }

    public void setLineJoin(StrokeLineJoin join) {
        gc.setLineJoin(join);
    }

    public Font getFont() {
        return gc.getFont();
    }

    public void setFont(Font f) {
        gc.setFont(f);
    }

    public FontSmoothingType getFontSmoothingType() {
        return gc.getFontSmoothingType();
    }

    public void setFontSmoothingType(FontSmoothingType fontsmoothing) {
        gc.setFontSmoothingType(fontsmoothing);
    }

    public TextAlignment getTextAlign() {
        return gc.getTextAlign();
    }

    public void setTextAlign(TextAlignment align) {
        gc.setTextAlign(align);
    }

    public VPos getTextBaseline() {
        return gc.getTextBaseline();
    }

    public void setTextBaseline(VPos baseline) {
        gc.setTextBaseline(baseline);
    }

    public FillRule getFillRule() {
        return gc.getFillRule();
    }

    public void setFillRule(FillRule fillRule) {
        gc.setFillRule(fillRule);
    }

    public PixelWriter getPixelWriter() {
        return gc.getPixelWriter();
    }

    public Effect getEffect(Effect e) {
        return gc.getEffect(e);
    }

    public double getLineWidth() {
        return gc.getLineWidth();
    }

    public void setLineWidth(double lw) {
        gc.setLineWidth(lw);
    }

    public double getMiterLimit() {
        return gc.getMiterLimit();
    }

    public void setMiterLimit(double ml) {
        gc.setMiterLimit(ml);
    }

    public double[] getLineDashes() {
        return gc.getLineDashes();
    }

    public void setLineDashes(double... dashes) {
        gc.setLineDashes(dashes);
    }

    public double getLineDashOffset() {
        return gc.getLineDashOffset();
    }

    public void setLineDashOffset(double dashOffset) {
        gc.setLineDashOffset(dashOffset);
    }

    public boolean isPointInPath(double x, double y) {
        return gc.isPointInPath(x, y);
    }

    public Affine getTransform(Affine xform) { return gc.getTransform(xform); }

    public Affine getTransform() { return gc.getTransform(); }

    /**
     * undoable methods
     */
    public void setTransform(Affine xform) {
        Undoable last = UndoCollector.INSTANCE.add(new Undoable("setTransform2", xform, new GCState(gc)));
        redraw(last);
    }

    public void save() {
        Undoable last = UndoCollector.INSTANCE.add(new Undoable("save",  new GCState(gc)));
        redraw(last);
    }

    public void restore() {
        Undoable last = UndoCollector.INSTANCE.add(new Undoable("restore",  new GCState(gc)));
        redraw(last);
    }

    public void translate(double x, double y) {
        Undoable last = UndoCollector.INSTANCE.add(new Undoable("translate", x, y, 0, 0, new GCState(gc)));
        redraw(last);
    }

    public void scale(double x, double y) {
        Undoable last = UndoCollector.INSTANCE.add(new Undoable("scale", x, y, 0, 0, new GCState(gc)));
        redraw(last);
    }

    public void rotate(double degrees) {
        Undoable last = UndoCollector.INSTANCE.add(new Undoable("rotate", degrees, 0, 0, 0, new GCState(gc)));
        redraw(last);
    }

    // undoable drawings
    public void fillText(String text, double x, double y) {
        Undoable last = UndoCollector.INSTANCE.add(new Undoable("fillText", text, x, y, 0, new GCState(gc)));
        redraw(last);
    }

    public void strokeText(String text, double x, double y) {
        Undoable last = UndoCollector.INSTANCE.add(new Undoable("strokeText", text, x, y, 0, new GCState(gc)));
        redraw(last);
    }

    public void fillText(String text, double x, double y, double maxWidth) {
        Undoable last = UndoCollector.INSTANCE.add(new Undoable("fillText2", text, x, y, maxWidth, new GCState(gc)));
        redraw(last);
    }

    public void strokeText(String text, double x, double y, double maxWidth) {
        Undoable last = UndoCollector.INSTANCE.add(new Undoable("strokeText2", text, x, y, maxWidth, new GCState(gc)));
        redraw(last);
    }

    public void clearRect(double x, double y, double w, double h) {
        Undoable last = UndoCollector.INSTANCE.add(new Undoable("clearRect", x, y, w, h, new GCState(gc)));
        redraw(last);
    }

    public void fillRect(double x, double y, double w, double h) {
        Undoable last = UndoCollector.INSTANCE.add(new Undoable("fillRect", x, y, w, h, new GCState(gc)));
        redraw(last);
    }

    public void strokeRect(double x, double y, double w, double h) {
        Undoable last = UndoCollector.INSTANCE.add(new Undoable("strokeRect", x, y, w, h, new GCState(gc)));
        redraw(last);
    }

    public void fillOval(double x, double y, double w, double h) {
        Undoable last = UndoCollector.INSTANCE.add(new Undoable("fillOval", x, y, w, h, new GCState(gc)));
        redraw(last);
    }

    public void strokeOval(double x, double y, double w, double h) {
        Undoable last = UndoCollector.INSTANCE.add(new Undoable("strokeOval", x, y, w, h, new GCState(gc)));
        redraw(last);
    }

    public void strokeLine(double x1, double y1, double x2, double y2) {
        Undoable last = UndoCollector.INSTANCE.add(new Undoable("strokeLine", x1, y1, x2, y2, new GCState(gc)));
        redraw(last);
    }

    public void fillRoundRect(double x, double y, double w, double h, double arcWidth, double arcHeight) {
        Undoable last = UndoCollector.INSTANCE.add(new Undoable("fillRoundRect", x, y, w, h, arcWidth, arcHeight, new GCState(gc)));
        redraw(last);
    }

    public void strokeRoundRect(double x, double y, double w, double h, double arcWidth, double arcHeight) {
        Undoable last = UndoCollector.INSTANCE.add(new Undoable("strokeRoundRect", x, y, w, h, arcWidth, arcHeight, new GCState(gc)));
        redraw(last);
    }

    public void fillArc(double x, double y, double w, double h, double startAngle, double arcExtent, ArcType closure) {
        Undoable last = UndoCollector.INSTANCE.add(new Undoable("fillArc", x, y, w, h, startAngle, arcExtent, closure, new GCState(gc)));
        redraw(last);
    }

    public void strokeArc(double x, double y, double w, double h, double startAngle, double arcExtent, ArcType closure) {
        Undoable last = UndoCollector.INSTANCE.add(new Undoable("strokeArc", x, y, w, h, startAngle, arcExtent, closure, new GCState(gc)));
        redraw(last);
    }

    public void fillPolygon(double xPoints[], double yPoints[], int nPoints) {
        Undoable last = UndoCollector.INSTANCE.add(new Undoable("fillPolygon", xPoints, yPoints, nPoints, new GCState(gc)));
        redraw(last);
    }

    public void strokePolygon(double xPoints[], double yPoints[], int nPoints) {
        Undoable last = UndoCollector.INSTANCE.add(new Undoable("strokePolygon", xPoints, yPoints, nPoints, new GCState(gc)));
        redraw(last);
    }

    public void strokePolyline(double xPoints[], double yPoints[], int nPoints) {
        Undoable last = UndoCollector.INSTANCE.add(new Undoable("strokePolyline", xPoints, yPoints, nPoints, new GCState(gc)));
        redraw(last);
    }

    public void drawImage(Image img, double x, double y) {
        Undoable last = UndoCollector.INSTANCE.add(new Undoable("drawImage", img, x, y, 0, 0, new GCState(gc)));
        redraw(last);
    }

    public void drawImage(Image img, double x, double y, double w, double h) {
        Undoable last = UndoCollector.INSTANCE.add(new Undoable("drawImage2", img, x, y, w, h, new GCState(gc)));
        redraw(last);
    }

    public void drawImage(Image img, double x, double y, double w, double h, double dx, double dy, double dw, double dh) {
        Undoable last = UndoCollector.INSTANCE.add(new Undoable("drawImage3", img, x, y, w, h, dx, dy, dw, dh, new GCState(gc)));
        redraw(last);
    }

    public void setEffect(Effect e) {
        Undoable last = UndoCollector.INSTANCE.add(new Undoable("setEffect", e, new GCState(gc)));
        redraw(last);
    }

    public void applyEffect(Effect e) {
        Undoable last = UndoCollector.INSTANCE.add(new Undoable("applyEffect", e, new GCState(gc)));
        redraw(last);
    }

    public void transform(double mxx, double myx, double mxy, double myy, double mxt, double myt) {
        Undoable last = UndoCollector.INSTANCE.add(new Undoable("transform", mxx, myx, mxy, myy, mxt, myt, new GCState(gc)));
        redraw(last);
    }

    public void transform(Affine xform) {
        Undoable last = UndoCollector.INSTANCE.add(new Undoable("transform2", xform, new GCState(gc)));
        redraw(last);
    }

    public void setTransform(double mxx, double myx, double mxy, double myy, double mxt, double myt) {
        Undoable last = UndoCollector.INSTANCE.add(new Undoable("setTransform", mxx, myx, mxy, myy, mxt, myt, new GCState(gc)));
        redraw(last);
    }

    public void beginPath() {
        Undoable last = UndoCollector.INSTANCE.add(new Undoable("beginPath", new GCState(gc)));
        redraw(last);
    }

    public void moveTo(double x0, double y0) {
        Undoable last = UndoCollector.INSTANCE.add(new Undoable("moveTo", x0, y0, 0, 0, new GCState(gc)));
        redraw(last);
    }

    public void lineTo(double x1, double y1) {
        Undoable last = UndoCollector.INSTANCE.add(new Undoable("lineTo", x1, y1, 0, 0, new GCState(gc)));
        redraw(last);
    }

    public void quadraticCurveTo(double xc, double yc, double x1, double y1) {
        Undoable last = UndoCollector.INSTANCE.add(new Undoable("quadraticCurveTo", xc, yc, x1, y1, new GCState(gc)));
        redraw(last);
    }

    public void bezierCurveTo(double xc1, double yc1, double xc2, double yc2, double x1, double y1) {
        Undoable last = UndoCollector.INSTANCE.add(new Undoable("bezierCurveTo", xc1, yc1, xc2, yc2, x1, y1, new GCState(gc)));
        redraw(last);
    }

    public void arcTo(double x1, double y1, double x2, double y2, double radius) {
        Undoable last = UndoCollector.INSTANCE.add(new Undoable("arcTo", x1, y1, x2, y2, radius, 0, new GCState(gc)));
        redraw(last);
    }

    public void arc(double centerX, double centerY, double radiusX, double radiusY, double startAngle, double length) {
        Undoable last = UndoCollector.INSTANCE.add(
                new Undoable("arcTo", centerX, centerY, radiusX, radiusY, startAngle, length, new GCState(gc)));
        redraw(last);
    }

    public void rect(double x, double y, double w, double h) {
        Undoable last = UndoCollector.INSTANCE.add(new Undoable("rect", x, y, w, h, new GCState(gc)));
        redraw(last);
    }

    public void appendSVGPath(String svgpath) {
        Undoable last = UndoCollector.INSTANCE.add(new Undoable("appendSVGPath", svgpath, new GCState(gc)));
        redraw(last);
    }

    public void closePath() {
        Undoable last = UndoCollector.INSTANCE.add(new Undoable("closePath", new GCState(gc)));
        redraw(last);
    }

    public void fill() {
        Undoable last = UndoCollector.INSTANCE.add(new Undoable("fill", new GCState(gc)));
        redraw(last);
    }

    public void stroke() {
        Undoable last = UndoCollector.INSTANCE.add(new Undoable("stroke", new GCState(gc)));
        redraw(last);
    }

    public void clip() {
        Undoable last = UndoCollector.INSTANCE.add(new Undoable("clip", new GCState(gc)));
        redraw(last);
    }

    // the real draw method
    private void drawCmd(Undoable cmd) {
        double x = cmd.getX(), y = cmd.getY(), w = cmd.getW(), h = cmd.getH();

        cmd.getState().restore(gc);

        switch (cmd.getName()) {
            case "clearRect":
                gc.clearRect(x, y, w, h);
                break;
            case "fillRect":
                gc.fillRect(x, y, w, h);
                break;
            case "strokeRect":
                gc.strokeRect(x, y, w, h);
                break;
            case "save":
                gc.save();
                break;
            case "restore":
                gc.restore();
                break;
            case "translate":
                gc.translate(x, y);
                break;
            case "scale":
                gc.scale(x, y);
                break;
            case "rotate":
                gc.rotate(x);
                break; //x=degrees
            case "setGlobalAlpha":
                gc.setGlobalAlpha(x);
                break; //x=alpha
            case "fillText": {
                String text = cmd.getText();
                gc.fillText(text, x, y);
                break;
            }
            case "strokeText": {
                String text = cmd.getText();
                gc.strokeText(text, x, y);
                break;
            }
            case "fillText2": {
                String text = cmd.getText();
                double maxWidth = cmd.getMaxWidth();
                gc.fillText(text, x, y, maxWidth);
                break;
            }
            case "strokeText2": {
                String text = cmd.getText();
                double maxWidth = cmd.getMaxWidth();
                gc.strokeText(text, x, y, maxWidth);
                break;
            }
            case "fillOval":
                gc.fillOval(x, y, w, h);
                break;
            case "strokeOval":
                gc.strokeOval(x, y, w, h);
                break;
            case "strokeLine":
                gc.strokeLine(x, y, w, h);
                break;// x1, y1, x2, y2
            case "fillRoundRect": {
                double arcWidth = cmd.getArcWidth(), arcHeight = cmd.getArcHeight();
                gc.fillRoundRect(x, y, w, h, arcWidth, arcHeight);
                break;
            }
            case "strokeRoundRect": {
                double arcWidth = cmd.getArcWidth(), arcHeight = cmd.getArcHeight();
                gc.strokeRoundRect(x, y, w, h, arcWidth, arcHeight);
                break;
            }
            case "fillArc": {
                double startAngle = cmd.getStartAngle(), arcExtent = cmd.getArcExtent();
                ArcType closure = cmd.getClosure();
                gc.fillArc(x, y, w, h, startAngle, arcExtent, closure);
                break;
            }
            case "strokeArc": {
                double startAngle = cmd.getStartAngle(), arcExtent = cmd.getArcExtent();
                ArcType closure = cmd.getClosure();
                gc.strokeArc(x, y, w, h, startAngle, arcExtent, closure);
                break;
            }
            case "fillPolygon": {
                double[] xPoints = cmd.getxPoints(), yPoints = cmd.getyPoints();
                int nPoints = cmd.getnPoints();
                gc.fillPolygon(xPoints, yPoints, nPoints);
                break;
            }
            case "strokePolygon": {
                double[] xPoints = cmd.getxPoints(), yPoints = cmd.getyPoints();
                int nPoints = cmd.getnPoints();
                gc.strokePolygon(xPoints, yPoints, nPoints);
                break;
            }
            case "strokePolyline": {
                double[] xPoints = cmd.getxPoints(), yPoints = cmd.getyPoints();
                int nPoints = cmd.getnPoints();
                gc.strokePolyline(xPoints, yPoints, nPoints);
                break;
            }
            case "drawImage": {
                Image img = cmd.getImg();
                gc.drawImage(img, x, y);
                break;
            }
            case "drawImage2": {
                Image img = cmd.getImg();
                gc.drawImage(img, x, y, w, h);
                break;
            }
            case "drawImage3": {
                Image img = cmd.getImg();
                double dx = cmd.getDx(), dy = cmd.getDy(), dw = cmd.getDw(), dh = cmd.getDh();
                gc.drawImage(img, x, y, w, h, dx, dy, dw, dh);
                break;
            }
            case "setEffect": {
                Effect e = cmd.getEffect();
                gc.setEffect(e);
                break;
            }
            case "applyEffect": {
                Effect e = cmd.getEffect();
                gc.applyEffect(e);
                break;
            }
            case "transform": {
                double mxt = cmd.getArcWidth(), myt = cmd.getArcHeight();
                gc.transform(x, y, w, h, mxt, myt);//mxx, myx, mxy, myy, mxt, myt
                break;
            }
            case "transform2": {
                Affine xform = cmd.getXform();
                gc.transform(xform);
                break;
            }
            case "setTransform": {
                double mxt = cmd.getArcWidth(), myt = cmd.getArcHeight();
                gc.setTransform(x, y, w, h, mxt, myt);//mxx, myx, mxy, myy, mxt, myt
                break;
            }
            case "setTransform2": {
                Affine xform = cmd.getXform();
                gc.setTransform(xform);
                break;
            }
            case "beginPath":
                gc.beginPath();
                break;
            case "moveTo":
                gc.moveTo(x, y);
                break; //x0,y0
            case "lineTo":
                gc.lineTo(x, y);
                break;//x1,y1
            case "quadraticCurveTo":
                gc.quadraticCurveTo(x, y, w, h);
                break;//xc, yc, x1, y1);
            case "bezierCurveTo": {
                double x1 = cmd.getArcWidth(), y1 = cmd.getArcHeight();
                gc.bezierCurveTo(x, y, w, h, x1, y1);//xc1, yc1, xc2, yc2, x1, y1
                break;
            }
            case "arcTo": {
                double radius = cmd.getArcWidth();
                gc.arcTo(x, y, w, h, radius); //x1, y1, x2, y2, radius
                break;
            }
            case "arc": {
                double startAngle = cmd.getArcWidth(), length = cmd.getArcHeight();
                gc.arc(x, y, w, h, startAngle, length);//centerX, centerY, radiusX, radiusY, startAngle, length
                break;
            }
            case "rect":
                gc.rect(x, y, w, h);
                break;
            case "appendSVGPath": {
                String svgpath = cmd.getText();
                gc.appendSVGPath(svgpath);
                break;
            }
            case "fill":
                gc.fill();
                break;
            case "stroke":
                gc.stroke();
                break;
            case "clip":
                gc.clip();
                break;
            case "closePath":
                gc.closePath();
                break;
            default:
                System.out.println(cmd.getName() + " not known!! ERROR!");
        }
    }

}


// public class testUndo extends Application {
//     Pane pane = new Pane();
//     Canvas canvas;
//     undoGraphicsContext ugc;
//     Button button1, button2;
//     Stage window;
// 
//     public static void main(String[] args) {
//         launch(args);
//     }
// 
//     @Override
//     public void start(Stage primaryStage) throws Exception {
//         window = primaryStage;
//         canvas = new Canvas(400, 400);
//         pane.getChildren().add(canvas);
//         ugc = new undoGraphicsContext(canvas);
//         draw(ugc);
// 
// 
//         canvas.setOnMouseClicked(e -> onMouseClicked(e));
//         // Text fields
//         TextField nameInput = new TextField();
//         nameInput.setPromptText("Name");
//         TextField ageInput = new TextField();
//         ageInput.setPromptText("Age");
// 
//         HBox inputLayout = new HBox(10, nameInput, ageInput);
//         inputLayout.setAlignment(Pos.CENTER);
//         inputLayout.setPadding(new Insets(10, 10, 10, 10));
// 
// 
//         // Buttons
//         Label label = new Label();
//         button1 = new Button("Undo");
//         button1.setOnAction(e -> {
//             UndoCollector.INSTANCE.undo();
//             ugc.redraw();
//         });
//         button2 = new Button("Redo");
//         button2.setOnAction(e -> {
//             UndoCollector.INSTANCE.redo();
//             ugc.redraw();
//         });
// 
//         HBox buttonLayout = new HBox(10);
//         buttonLayout.setPadding(new Insets(10, 10, 10, 10));
//         buttonLayout.setAlignment(Pos.CENTER);
//         buttonLayout.getChildren().addAll(button1, button2);
// 
//         // root layout
//         VBox vbox = new VBox(10);
//         vbox.setAlignment(Pos.CENTER);
//         vbox.getChildren().addAll(pane, inputLayout, buttonLayout, label);
// 
//         window.setTitle("JavaFx Application");
//         window.setScene(new Scene(vbox, 500, 500));
//         window.show();
//     }
// 
//     private void onMouseClicked(MouseEvent e) {
//         double x = e.getX(), y = e.getY();
//         ugc.setFill(Color.rgb((int) (255 * Math.random()), (int) (255 * Math.random()), (int) (255 * Math.random())));//, Math.random()
//         ugc.fillRect(x, y, 100 * Math.random(), 100 * Math.random());
// 
//     }
// 
// 
//     private void draw(undoGraphicsContext gc) {
//         gc.setStroke(Color.BLACK);
//         gc.setFill(Color.BLUE);
//         gc.strokeRect(10, 10, 30, 30);
//         gc.fillRect(50, 20, 60, 60);
// 
//         gc.strokeRect(30, 70, 30, 30);
//         gc.setFill(Color.RED);
//         gc.fillRect(90, 120, 60, 60);
// 
//         gc.strokeRect(110, 210, 30, 30);
//         gc.setFill(Color.YELLOW);
//         gc.fillRect(150, 140, 60, 90);
//     }
// 
// }
