/**
*Text genereted by Simple GUI Extension for BlueJ
*/
import javax.swing.UIManager.LookAndFeelInfo;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import javax.swing.border.Border;
import javax.swing.*;


public class GUI_project extends JFrame {

	private JMenuBar menuBar;
	private JButton button1;
	private JButton button2;
	private JCheckBox checkbox1;
	private JCheckBox checkbox2;
	private JComboBox combobox1;
	private JEditorPane editorpane1;
	private JLabel label1;
	private JPanel panel1;
	private JTextArea textarea1;
	private JTextField textfield1;

	//Constructor 
	public GUI_project(){

		this.setTitle("GUI_project");
		this.setSize(500,400);
		//menu generate method
		generateMenu();
		this.setJMenuBar(menuBar);

		//pane with null layout
		JPanel contentPane = new JPanel(null);
		contentPane.setPreferredSize(new Dimension(500,400));
		contentPane.setBackground(new Color(192,192,192));


		button1 = new JButton();
		button1.setBounds(12,88,90,35);
		button1.setBackground(new Color(214,217,223));
		button1.setForeground(new Color(0,0,0));
		button1.setEnabled(true);
		button1.setFont(new Font("sansserif",0,12));
		button1.setText("Button1");
		button1.setVisible(true);

		button2 = new JButton();
		button2.setBounds(12,137,90,35);
		button2.setBackground(new Color(214,217,223));
		button2.setForeground(new Color(0,0,0));
		button2.setEnabled(true);
		button2.setFont(new Font("sansserif",0,12));
		button2.setText("Button2");
		button2.setVisible(true);

		checkbox1 = new JCheckBox();
		checkbox1.setBounds(17,182,90,35);
		checkbox1.setBackground(new Color(214,217,223));
		checkbox1.setForeground(new Color(0,0,0));
		checkbox1.setEnabled(true);
		checkbox1.setFont(new Font("sansserif",0,12));
		checkbox1.setText("CheckBox");
		checkbox1.setVisible(true);

		checkbox2 = new JCheckBox();
		checkbox2.setBounds(16,209,90,35);
		checkbox2.setBackground(new Color(214,217,223));
		checkbox2.setForeground(new Color(0,0,0));
		checkbox2.setEnabled(true);
		checkbox2.setFont(new Font("sansserif",0,12));
		checkbox2.setText("CheckBox");
		checkbox2.setVisible(true);

		combobox1 = new JComboBox();
		combobox1.setBounds(121,90,90,35);
		combobox1.setBackground(new Color(214,217,223));
		combobox1.setForeground(new Color(0,0,0));
		combobox1.setEnabled(true);
		combobox1.setFont(new Font("sansserif",0,12));
		combobox1.setVisible(true);

		editorpane1 = new JEditorPane();
		editorpane1.setBounds(124,140,253,127);
		editorpane1.setBackground(new Color(214,217,223));
		editorpane1.setForeground(new Color(0,0,0));
		editorpane1.setEnabled(true);
		editorpane1.setFont(new Font("sansserif",0,12));
		editorpane1.setText("JEditorPane");
		editorpane1.setBorder(BorderFactory.createBevelBorder(1));
		editorpane1.setVisible(true);

		label1 = new JLabel();
		label1.setBounds(17,44,90,35);
		label1.setBackground(new Color(214,217,223));
		label1.setForeground(new Color(0,0,0));
		label1.setEnabled(true);
		label1.setFont(new Font("sansserif",0,12));
		label1.setText("label");
		label1.setVisible(true);

		panel1 = new JPanel(null);
		panel1.setBorder(BorderFactory.createEtchedBorder(1));
		panel1.setBounds(6,291,487,102);
		panel1.setBackground(new Color(214,217,223));
		panel1.setForeground(new Color(0,0,0));
		panel1.setEnabled(true);
		panel1.setFont(new Font("sansserif",0,12));
		panel1.setVisible(true);


		textarea1 = new JTextArea();
		textarea1.setBounds(8,8,150,80);
		textarea1.setBackground(new Color(255,255,255));
		textarea1.setForeground(new Color(0,0,0));
		textarea1.setEnabled(true);
		textarea1.setFont(new Font("sansserif",0,12));
		textarea1.setText("JTextArea");
		textarea1.setBorder(BorderFactory.createBevelBorder(1));
		textarea1.setVisible(true);

		textfield1 = new JTextField();
		textfield1.setBounds(167,9,311,81);
		textfield1.setBackground(new Color(255,255,255));
		textfield1.setForeground(new Color(0,0,0));
		textfield1.setEnabled(true);
		textfield1.setFont(new Font("sansserif",0,12));
		textfield1.setText("JTextField");
		textfield1.setVisible(true);

		//adding components to contentPane panel
		contentPane.add(button1);
		contentPane.add(button2);
		contentPane.add(checkbox1);
		contentPane.add(checkbox2);
		contentPane.add(combobox1);
		contentPane.add(editorpane1);
		contentPane.add(label1);
		contentPane.add(panel1);
		panel1.add(textarea1);
		panel1.add(textfield1);

		//adding panel to JFrame and seting of window position and close operation
		this.add(contentPane);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLocationRelativeTo(null);
		this.pack();
		this.setVisible(true);
	}

	//method for generate menu
	public void generateMenu(){
		menuBar = new JMenuBar();

		JMenu file = new JMenu("File");
		JMenu tools = new JMenu("Tools");
		JMenu help = new JMenu("Help");

		JMenuItem open = new JMenuItem("Open   ");
		JMenuItem save = new JMenuItem("Save   ");
		JMenuItem exit = new JMenuItem("Exit   ");
		JMenuItem preferences = new JMenuItem("Preferences   ");
		JMenuItem about = new JMenuItem("About   ");


		file.add(open);
		file.add(save);
		file.addSeparator();
		file.add(exit);
		tools.add(preferences);
		help.add(about);

		menuBar.add(file);
		menuBar.add(tools);
		menuBar.add(help);
	}



	 public static void main(String[] args){
		System.setProperty("swing.defaultlaf", "com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
		javax.swing.SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				new GUI_project();
			}
		});
	}

}