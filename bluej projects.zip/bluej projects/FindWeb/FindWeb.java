
/**
 * Write a description of FindWeb here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
import java.io.*;
import edu.duke.*;
public class FindWeb {
    public static void main(){
        URLResource url=new URLResource("http://www.dukelearntoprogram.com/course2/data/manylinks.html");
        for(String l :url.lines()){
            if(l.indexOf("http")>0){
                if(l.indexOf("youtube")>0)
                //System.out.println(l+"\t"+ l.indexOf("http")+"\t"+  l.indexOf("\"", l.indexOf("http")) );
                //System.out.print(l.indexOf("http"));
                //System.out.print(l.indexOf("\"", l.indexOf("http")));
                System.out.println(l.substring(l.indexOf("http"),l.indexOf("\"", l.indexOf("http"))));
            }
        }
    }

}
