
/**
 * Write a description of FindGene here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class FindGene {
    public String stopCodon(String seq, int startPos){
        String gene="";
        if(seq.length()<startPos+6)return "";
        int end = seq.indexOf("tga",startPos + 3);        
        if(end>0){
            gene=seq.substring(startPos,end + 3);
            if(gene.length() %3 == 0)
                return gene;
        }
        end = seq.indexOf("tag",startPos + 3);
        if(end>0){
            gene=seq.substring(startPos,end + 3);
            if(gene.length() %3 == 0)
                return gene;
        }
        end = seq.indexOf("taa",startPos + 3);
        if(end>0){
            gene=seq.substring(startPos,end + 3);
            if(gene.length() %3 == 0)
                return gene;
        }
        return "";
    }

    public String findGene(String seq){
        seq=seq.toLowerCase();
        int start=seq.indexOf("atg");
        if(start!=-1){            
            String gene=stopCodon(seq,start);
            return gene; 
        }
        return "";
    }

    public void main(){
        String g="AATGCTAGTTTAAATCTGA";
        System.out.println("1= "+ findGene(g));
        g="ataaactatgttttaaatgt";
        System.out.println("4= "+ findGene(g));
        g="AATGTGA";
        System.out.println("2= "+ findGene(g));

        g="AATaCTAGTTTAAATCTGA";
        System.out.println("3= "+ findGene(g));

        g="acatgataacctaag";
        System.out.println("5= "+ findGene(g));

    }
}
