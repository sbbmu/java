import javax.swing.JFrame;

public class tt extends JFrame {

	public tt(){
		super("Frame title");
		setSize(300,100);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
	}
	public static void main(String[] arguments) {
		SimpleFrame sf = new SimpleFrame();
	}
}
