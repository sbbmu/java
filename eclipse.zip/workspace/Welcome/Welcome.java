import java.util.Scanner;

/**
 * This program displays a greeting for the reader.
 * 
 * @version 1.30 2014-02-27
 * @author Cay Horstmann
 */
public class Welcome {
	public static final double CM_PER_INCH = 2.54;

	public static void main(String[] args) {
		int �� = 120;
		double �� = 3.14;
		String greeting = "Welcome to Core Java!" + " \u03c0\u2122!\t" + �� + " " + �� * 12;
		System.out.println(greeting);
		for (int i = 0; i < greeting.length(); i++)
			System.out.print("=");
		System.out.println(2 - 1.1);

		// Caution when comparing strings
		greeting = "Hello"; // initialize greeting to a string
		if (greeting == "Hello") // probably true
			System.out.println("==(Hello)");
		if (greeting.substring(0, 3) == "Hel") // probably false
			System.out.println("==(Hel)");// not reachable
		if (greeting.substring(0, 3).equals("Hel")) // true
			System.out.println("equals(Hel)");

		greeting = "";
		if (greeting == "") // true
			System.out.println("==empty");
		if (greeting.equals("")) // true
			System.out.println("eq.empty");
		if (greeting + "1" == "" + "1") // not true
			System.out.println("==empty+1");
		if ((greeting + "1").equals("" + "1")) // true
			System.out.println("eq.empty+1");

		// UTF-16
		greeting = "Hello";
		System.out.println(greeting);
		System.out.println(greeting.length());
		System.out.println(greeting.codePointCount(0, greeting.length()));
		greeting = "��ã�";
		System.out.println(greeting);
		System.out.println(greeting.length());
		System.out.println(greeting.codePointCount(0, greeting.length()));
		greeting = new String(new int[] { 0x1D546 }, 0, 1) + " is the set of octonions"; // blackboard
																							// bold
																							// face
																							// O
		System.out.println(greeting);
		System.out.println(greeting.length());
		System.out.println(greeting.codePointCount(0, greeting.length()));

		// IO
		Scanner in = new Scanner(System.in);
		System.out.print("What is your name? ");
		String name = in.nextLine();
		System.out.println("Hello, " + name);
		
		System.out.print("How old are you? ");
		int age = in.nextInt();
		System.out.println("Your are " + age);
		
		System.out.print("Give me a byte: ");
		byte c = in.nextByte();
		System.out.println("You typed " + c);
		
		in.close();
	}
}
