package notes.study.corejava;

import java.time.LocalDate;
import java.util.Random;

// static import for static methods
import static java.lang.System.out;

/**
 * This program demonstrates inheritance.
 * 
 * @version 1.21 2004-02-21
 * @author Cay Horstmann
 */
public class testClass {

	public static void main(String[] args) {
		// Manager m=new Manager("Joe Biden");
		// m.setBonus(1000);
		// out.println("id=" + m.getId() + ", name=" + m.getName() + ", salary="
		// + m.getSalary() + ", hireDay="
		// + m.getHireDay()+", bonus="+m.getBonus());

		Manager boss = new Manager("Carl Cracker", 80000, 1987, 12, 15);
		boss.setBonus(5000);

		Employee[] staff = new Employee[3];
		staff[0] = boss;
		staff[1] = new Employee("Harry Hacker", 6000, 1998, 12, 18);
		staff[2] = new Employee("Tony Tester", 3000, 2006, 5, 7);

		for (Employee e : staff)
			e.raiseSalary(5);

		for (Employee e : staff)
			out.println("id=" + e.getId() + ", name=" + e.getName() + ", salary=" + e.getSalary() + ", hireDay="
					+ e.getHireDay());
		
//		// Manager and staff refer to the same object
//		Manager[] managers = new Manager[3];
//		staff = managers; // OK
//		staff[0] = new Employee("Harry Hacker"); // java.lang.ArrayStoreException
		
	}
}

class Employee {
	private static int nextId;
	private int id;
	String Name;
	private double Salary;
	LocalDate HireDate;

	// static init block
	{
		Random r = new Random();
		nextId = r.nextInt(10000) + 10000;
	}
	// object init block
	{
		id = nextId;
		nextId++;
	}

	// overloaded constructors
	public Employee(String name, double salary, int year, int month, int day) {
		Name = name;
		Salary = salary;
		HireDate = LocalDate.of(year, month, day);
	}

	public Employee(String name) {
		Name = name;
	}

	public Employee(String name, double salary) {
		Name = name;
		Salary = salary;
	}

	// default constructor
	public Employee() {
	}

	// methods
	public double getSalary() {
		return Salary;
	}

	public String getName() {
		return (Name);
	}

	public int getId() {
		return id;
	}

	public LocalDate getHireDay() {
		return HireDate;
	}

	public void raiseSalary(double rate) {
		if (rate < -1 || rate > 1) {
			rate /= 100;
		}
		Salary *= 1 + rate;
	}
}

class Manager extends Employee {
	private double bonus = 0;

	/**
	 * @param name
	 *            the employee's name
	 * @param salary
	 *            the salary
	 * @param year
	 *            the hire year
	 * @param month
	 *            the hire month
	 * @param day
	 *            the hire day
	 */
	public Manager(String Name, double salary, int year, int month, int day) {
		super(Name, salary, year, month, day);
		bonus = 0;
	}

	public Manager(String Name) {
		super(Name);
		bonus = 0;
	}

	public void setBonus(double value) {
		bonus = value;
	}

	public double getBonus() {
		return bonus;
	}

	public double getSalary() {
		return bonus + super.getSalary();
	}
}