package notes.study.corejava;

import java.io.*;
import java.nio.file.Paths;
import java.util.Scanner;

public class testIO {
	public static void main(String[] args) throws IOException {
		Scanner in = new Scanner(Paths.get("myfile.txt"), "UTF-8");
		PrintWriter out = new PrintWriter("myfileout.txt", "UTF-8");
		// Scanner in = new Scanner("myfile.txt"); // ERROR?
		String dir = System.getProperty("user.dir");

		while (in.hasNextLine()) {
			out.println(in.nextLine());
		}
		out.println(dir);

		in.close();
		out.close();
		System.out.println("~~~  done!!!  ~~~");
		print("s");
	}

	public static void print(String string) {
		System.out.println(string);
		
	}

}
