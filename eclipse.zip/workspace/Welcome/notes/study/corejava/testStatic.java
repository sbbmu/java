package notes.study.corejava;

import java.time.LocalDate;
// same package, no need to import
//import notes.study.corejava.testIO.*;


public class testStatic {
	public static void main(String[] args){
		testIO.print(LocalDate.now().toString());
	}
}
