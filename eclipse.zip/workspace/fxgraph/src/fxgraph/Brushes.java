package fxgraph;

import javafx.geometry.Point2D;
import javafx.scene.SnapshotParameters;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.PixelReader;
import javafx.scene.image.PixelWriter;
import javafx.scene.image.WritableImage;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.StrokeLineCap;
import javafx.scene.shape.StrokeLineJoin;

import java.util.ArrayList;

/**
 * Created by VHASFCSUNB on 8/26/2016.
 */
enum ColorState {
    Position, Random, Fixed
}

class PointsArray {
    private ArrayList<Double> x, y;

    PointsArray() {
        x = new ArrayList<>();
        y = new ArrayList<>();
    }

    PointsArray(ArrayList<Double> pax, ArrayList<Double> pay) {
        x = pax;
        y = pay;
    }

    int length() {
        return x.size();
    }

    double[] getaX() {
        double[] t = new double[x.size()];
        for (int i = 0; i < t.length; i++) {
            t[i] = x.get(i);
        }
        return t;
    }

    double[] getaY() {
        double[] t = new double[y.size()];
        for (int i = 0; i < t.length; i++) {
            t[i] = y.get(i);
        }
        return t;
    }

    void add(double px, double py) {
        x.add(px);
        y.add(py);
    }
}

public class Brushes {
    private static double x0;
    private static double y0;
    private static double lwd;
    private static boolean isFill, isStroke, isRndLwd, isSelectionSet, isSHIFT;
    private static Color strokeColor, fillColor;
    private static ColorState colorState;
    private static WritableImage copiedImage;

    private static Rectangle selectionBounds=new Rectangle();

    public static boolean isSelectionSet() {
        return isSelectionSet;
    }

    public static void setIsSelectionSet(boolean isSelectionSet) {
        Brushes.isSelectionSet = isSelectionSet;
    }
    public static void setIsSHIFT(boolean isSHIFT) {
        Brushes.isSHIFT = isSHIFT;
    }

    public static void setIsStroke(boolean isStroke) {
        Brushes.isStroke = isStroke;
    }

    public static void setIsFill(boolean isFill) {
        Brushes.isFill = isFill;
    }

    public static void setLwd(double lwd) {
        Brushes.lwd = lwd;
    }

    public static void setColorState(ColorState cs) {
        colorState = cs;
    }

    public static void setX0(double x0) {
        Brushes.x0 = x0;
    }

    public static void setY0(double y0) {
        Brushes.y0 = y0;
    }

    public static Color getStrokeColor() {
        return strokeColor;
    }

    public static void setStrokeColor(Color strokeColor) {
        Brushes.strokeColor = strokeColor;
    }

    public static Color getFillColor() {
        return fillColor;
    }

    public static void setFillColor(Color fillColor) {
        Brushes.fillColor = fillColor;
    }

    /**
     * Helper functions -- log to console
     */
    static String log(String p, String... v) {
        for (String s : v) p += ", " + s;
        System.out.println(p);
        return p;
    }

    static String log(double p, double... v) {
        String ps = String.valueOf(p);
        for (double s : v) ps += ", " + String.valueOf(s);
        System.out.println(ps);
        return ps;
    }

    /**
     * Clear background
     */
    static void GCClear(GraphicsContext gc) {
        gc.clearRect(0, 0, gc.getCanvas().getWidth(), gc.getCanvas().getHeight());
    }

    /**
     * setup canvas
     */
    private static void setGCStrokeColor(MouseEvent e, GraphicsContext gc) {
        if (colorState == ColorState.Position) {
            if (e != null) {
                int r = Math.abs((int) e.getX() * 3) % 256, g = Math.abs((int) e.getY() % 256), b = Math.abs((int) (e.getX() * 2 + e.getY()) % 256);
                gc.setStroke(Color.rgb(r, g, b));
            }
        } else if (colorState == ColorState.Random) {
            int r = (int) (Math.random() * 256), g = (int) (Math.random() * 256), b = (int) (Math.random() * 256);
            gc.setStroke(Color.rgb(r, g, b));
        } else {
            gc.setStroke(getStrokeColor());
        }
    }

    private static void setGCFillColor(MouseEvent e, GraphicsContext gc) {
        if (colorState == ColorState.Position) {
            if (e != null) {
                int r = Math.abs((int) e.getX() ^ 2) % 256, g = Math.abs((int) e.getY() % 256), b = Math.abs((int) (e.getX() * 2 + e.getY()) % 256);
                gc.setFill(Color.rgb(r, g, b));
            }
        } else if (colorState == ColorState.Random) {
            int r = (int) (Math.random() * 256), g = (int) (Math.random() * 256), b = (int) (Math.random() * 256);
            gc.setFill(Color.rgb(r, g, b));
        } else {
            gc.setFill(getFillColor());
        }
    }

    private static void setGCLineWidth(GraphicsContext gc) {
        double lw;
        if (isRndLwd) lw = Math.random() * lwd;
        else lw = lwd;
        gc.setLineWidth(lw);
    }

    static void setGCStatus(MouseEvent e, GraphicsContext gc) {
        setGCLineWidth(gc);
        setGCStrokeColor(e, gc);
        setGCFillColor(e, gc);
    }

    /**
     * brushes
     */
    static void holidayBrush(MouseEvent e, GraphicsContext gc) {
        double x = e.getX(), y = e.getY();
        int r = Math.abs((int) x % 256), g = Math.abs((int) y % 256), b = Math.abs((int) (x * 2 + y) % 256);
        gc.setStroke(Color.rgb(r, g, b));
        gc.setLineWidth(Math.sin((x / 2 * Math.sqrt(y))) * 5);
        gc.strokeLine(x0, y0, x, y);
        gc.setFill(Color.rgb((int) (Math.random() * 256), (int) (Math.random() * 256), (int) (Math.random() * 256), Math.random()));
        gc.fillOval(x - Math.random() * 2, y - Math.random() * 2, Math.random() * 30, Math.random() * 30);
        setX0(x);
        setY0(y);
    }

    static void starBrush(MouseEvent e, GraphicsContext gc, int nVertices, double outerR, double innerR, double rotation) {
        setGCStatus(e, gc);
        PointsArray p = computeStar(e.getX(), e.getY(), nVertices, outerR, innerR, rotation);

        if (isFill) gc.fillPolygon(p.getaX(), p.getaY(), p.length());
        if (isStroke) gc.strokePolygon(p.getaX(), p.getaY(), p.length());
    }

    private static PointsArray computeStar(double centerX, double centerY, int nVertices, double outerR, double innerR, double rotation) {
        PointsArray p = new PointsArray();
        double angle = Math.PI / nVertices;

        for (int i = 0; i < 2 * nVertices; i++) {
            double r = (i % 2 == 0) ? outerR : innerR;
            double x = centerX + Math.cos(i * angle - rotation) * r; // 5 point star rotation=angle/2= 18 degrees
            double y = centerY + Math.sin(i * angle - rotation) * r;
            p.add(x, y);
        }
        return p;
    }

    static void hozMirrorBrush(MouseEvent e, GraphicsContext gc) {
        double x, y;
        double w = gc.getCanvas().getWidth();
        x = e.getX();
        y = e.getY();

        setGCStatus(e, gc);
        gc.setLineCap(StrokeLineCap.ROUND);
        gc.setLineJoin(StrokeLineJoin.ROUND);
        gc.strokeLine(x0, y0, x, y);
        gc.strokeLine(Math.abs(w - x0), y0, Math.abs(w - x), y);
        setX0(x);
        setY0(y);
    }

    // free hand
    static void drawFreeHand(MouseEvent e, GraphicsContext gc) {
        double x = e.getX(), y = e.getY();
        setGCStatus(e, gc);
        gc.setLineCap(StrokeLineCap.ROUND);
        gc.setLineJoin(StrokeLineJoin.ROUND);
        gc.strokeLine(x0, y0, x, y);
        setX0(x);
        setY0(y);
    }

    static void lineOnMouseReleased(MouseEvent e, GraphicsContext gc, GraphicsContext gc2, int amount, double distance) {
        GCClear(gc2);

        double x = e.getX(), y = e.getY();
        if (isSHIFT) y = y0;
        Point2D p0 = new Point2D(x0, y0), p1 = new Point2D(x, y), p3 = new Point2D(1, 0); // p3 is a vector on x axis
        double theta = p3.angle(p1.subtract(p0)), at = Math.toRadians(theta);  //  vector math for angles

        if (y0 < y) at = -at;
        double dx = distance * Math.sin(at), dy = distance * Math.cos(at);

//        gc.strokeText(String.format("%1$.0f", Math.toDegrees(at)) + ", " + String.format("%1$.0f", theta) +
//                        ", (" + String.format("%1$.0f", dx) + ", " + String.format("%1$.0f", dy) + ")"
//                , x0, y0);

        for (int i = 0; i < amount; i++) {
            double d = i - (amount - 1) / 2.0; // adjust center of line start points
            setGCStatus(e, gc);
            gc.strokeLine(x0 + dx * d, y0 + dy * d, x + dx * d, y + dy * d);
        }
//        log(Math.sin(at), Math.cos(at), dx, dy);
    }

    static void drawLine(MouseEvent e, GraphicsContext gc2) {
        double x = e.getX(), y = e.getY();
        GCClear(gc2);
        gc2.setStroke(Color.BLACK);
        gc2.setLineWidth(1);
        gc2.setLineDashes(10f);
        if (isSHIFT) y = y0;
        gc2.strokeLine(x0, y0, x, y);
    }

    static void rectOnMouseReleased(MouseEvent e, GraphicsContext gc, GraphicsContext gc2) {
        double x = e.getX(), y = e.getY();
        setGCStatus(e, gc);
        if (isFill) gc.fillRect(selectionBounds.getX(), selectionBounds.getY(), Math.abs(x - x0), Math.abs(y - y0));
        if (isStroke) gc.strokeRect(selectionBounds.getX(), selectionBounds.getY(), Math.abs(x - x0), Math.abs(y - y0));
        GCClear(gc2);
    }

    static void drawRect(MouseEvent e, GraphicsContext gc2) {
        double x = e.getX(), y = e.getY();
        double gcW=gc2.getCanvas().getWidth(),gcH=gc2.getCanvas().getHeight();
        if (x > gcW) x = gcW;
        if (y > gcH) y = gcH;
        if (x < 0) x = 0;
        if (y < 0) y = 0;

        selectionBounds.setX( Math.min(x, x0));
        selectionBounds.setY( Math.min(y, y0));
        selectionBounds.setWidth(Math.abs(x - x0));
        selectionBounds.setHeight(Math.abs(y - y0));

        GCClear(gc2);
        gc2.setStroke(Color.BLACK);
        gc2.setLineWidth(1);
        gc2.setLineDashes(5f);
        gc2.strokeRect(selectionBounds.getX(), selectionBounds.getY(), selectionBounds.getWidth(), selectionBounds.getHeight());
    }

    static void ovalOnMouseReleased(MouseEvent e, GraphicsContext gc, GraphicsContext gc2) {
        
        setGCStatus(e, gc);
        if (isFill) gc.fillOval(selectionBounds.getX(), selectionBounds.getY(), selectionBounds.getWidth(), selectionBounds.getHeight());
        gc.strokeOval(selectionBounds.getX(), selectionBounds.getY(), selectionBounds.getWidth(), selectionBounds.getHeight());
        GCClear(gc2);
    }

    static void drawOval(MouseEvent e, GraphicsContext gc2) {
        double x = e.getX(), y = e.getY();
        GCClear(gc2);
        gc2.setStroke(Color.BLACK);
        gc2.setLineWidth(1);
        gc2.setLineDashes(5f);//new double[]{5f,3f}

        selectionBounds.setX( Math.min(x, x0));
        selectionBounds.setY( Math.min(y, y0));
        selectionBounds.setWidth(Math.abs(x - x0));
        selectionBounds.setHeight(Math.abs(y - y0));

        gc2.strokeOval(selectionBounds.getX(), selectionBounds.getY(), selectionBounds.getWidth(), selectionBounds.getHeight());
    }

    static void drawRndRect(GraphicsContext gc, int number, double maxSize, double minSize) {
        double x1, y1, w, h;

        for (int i = 0; i < number; i++) {
            x1 = (int) (Math.random() * gc.getCanvas().getWidth());
            y1 = (int) (Math.random() * gc.getCanvas().getHeight());
            w = (int) (Math.random() * Math.abs(maxSize - minSize) + minSize);
            h = (int) (Math.random() * Math.abs(maxSize - minSize) + minSize);

            MouseEvent e = new MouseEvent(MouseEvent.MOUSE_MOVED, x1, y1, x1, y1, MouseButton.NONE, 1,
                    false, false, false, false, false, false, false, false, false, false, null);

            setGCStatus(e, gc);
            if (isStroke) gc.strokeRect(x1, y1, w, h);
            if (isFill) gc.fillRect(x1, y1, w, h);
        }
    }

    public static void drawErase(MouseEvent e, GraphicsContext gc, double w, double h) {
        double x = e.getX(), y = e.getY();
        gc.clearRect(x, y, w, h);
    }

    public static void selectOnMouseReleased(MouseEvent e, Canvas canvas, GraphicsContext gc2) {
//        isSelectionSet=true;

        double x = e.getX(), y = e.getY();

        selectionBounds.setX( Math.min(x, x0));
        selectionBounds.setY( Math.min(y, y0));
        selectionBounds.setWidth(Math.abs(x - x0));
        selectionBounds.setHeight(Math.abs(y - y0));
//
//        copiedImage=copyImage(canvas,x1,y1,w,h);
//        gc2.drawImage(copiedImage, 0, 0);
    }

    public static Rectangle getSelectionBounds() {
        return selectionBounds;
    }

    public static void copyOnMouseReleased(MouseEvent e, Canvas canvas, GraphicsContext gc2) {
        double x = e.getX(), y = e.getY();
        if (x > canvas.getWidth()) x = canvas.getWidth();
        if (y > canvas.getHeight()) y = canvas.getHeight();
        if (x < 0) x = 0;
        if (y < 0) y = 0;

        selectionBounds.setX( Math.min(x, x0));
        selectionBounds.setY( Math.min(y, y0));
        selectionBounds.setWidth(Math.abs(x - x0));
        selectionBounds.setHeight(Math.abs(y - y0));

        copiedImage=copyImage(canvas,selectionBounds);

//        gc2.drawImage(copiedImage, 0, 0);
    }

    public static WritableImage copyImage(Canvas canvas, Rectangle selectionBounds) {
        SnapshotParameters sp = new SnapshotParameters();
        sp.setFill(Color.TRANSPARENT);
        WritableImage srcImage = canvas.snapshot(sp, null);
        PixelReader pixelReader = srcImage.getPixelReader();
        int w=(int)selectionBounds.getWidth(),h=(int)selectionBounds.getHeight();

        //Copy from source to destination pixel by pixel
        WritableImage destImage = new WritableImage(w, h);
        PixelWriter pixelWriter = destImage.getPixelWriter();

        for (int yi = 0; yi < h; yi++) {
            for (int xi = 0; xi < w; xi++) {
                Color color = pixelReader.getColor((int) selectionBounds.getX() + xi, (int) selectionBounds.getY() + yi);
                pixelWriter.setColor(xi, yi, color);
            }
        }
        return destImage;
    }

}

