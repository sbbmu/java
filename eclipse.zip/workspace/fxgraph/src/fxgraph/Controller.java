package fxgraph;

import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Cursor;
import javafx.scene.ImageCursor;
import javafx.scene.SnapshotParameters;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.image.WritableImage;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.stage.FileChooser;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.awt.image.RenderedImage;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class Controller implements Initializable {
	@FXML
	ToggleButton brush1Button, lineButton, hozMirrorButton, freehandButton, quadraticButton, pathButton, textButton;
	WritableImage img; // selection
	ImageView imageView;
	double orgSceneX, orgSceneY;
	double orgTranslateX, orgTranslateY;
	@FXML
	private Pane pane;
	@FXML
	private Canvas canvas, canvas2;
	@FXML
	private ScrollPane scrollPane;
	@FXML
	private TextField canvasW, canvasH, textLwd;
	@FXML
	private TextField textNStar, textRotation, textC;
	@FXML
	private ColorPicker colorPickerStroke, colorPickerFill;
	@FXML
	private Slider slider;
	@FXML
	private CheckBox posCol, rndCol, fill, stroke;
	@FXML
	private Label label1, label2, label3, label4;
	private GraphicsContext gc, gc2;
	private double x0, y0, x, y;
	private TextInput ti = new TextInput();

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		gc = canvas.getGraphicsContext2D();
		colorPickerStroke.setValue(Color.BLACK);
		colorPickerStroke.setStyle("-fx-color-label-visible: false; -fx-color-rect-height: 3; ");
		colorPickerFill.setValue(Color.WHITE);
		colorPickerFill.setStyle("-fx-color-label-visible: false;");
		canvas.setWidth(800);
		canvas.setHeight(600);

		// canvas layer 2
		canvas2 = new Canvas(canvas.getWidth(), canvas.getHeight());
		pane.getChildren().add(canvas2);
		gc2 = canvas2.getGraphicsContext2D();

		brush1Button.setSelected(true);
		brush1Button.requestFocus();
		brush1Button();
	}

	@FXML
	private void onKeyPressed(KeyEvent k) {
		// System.out.println("Key pressed " + k.toString());
		if (k.getCode() == KeyCode.C)
			clearCanvas(false);
		else if (k.getCode() == KeyCode.SHIFT)
			Brushes.setIsSHIFT(true);
	}

	@FXML
	private void onKeyReleased(KeyEvent k) {
		if (k.getCode() == KeyCode.SHIFT)
			Brushes.setIsSHIFT(false);
	}

	@FXML
	private void clearCanvas() {
		Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Are you sure to clear canvas?", ButtonType.OK);
		alert.showAndWait().filter(response -> response == ButtonType.OK)
				.ifPresent(response -> gc.clearRect(0, 0, canvas.getWidth(), canvas.getHeight()));
	}

	private void clearCanvas(boolean ask) {
		if (ask)
			clearCanvas();
		else
			gc.clearRect(0, 0, canvas.getWidth(), canvas.getHeight());
	}

	@FXML
	private void openImage() {
		FileChooser fileChooser = new FileChooser();
		fileChooser.setInitialDirectory(new File(System.getProperty("user.home"), "Desktop"));
		FileChooser.ExtensionFilter ef = new FileChooser.ExtensionFilter("Image files", "*.png", "*.PNG", "*.jpg",
				"*.JPG");
		fileChooser.getExtensionFilters().addAll(ef);
		File file = fileChooser.showOpenDialog(null);

		if (file != null) {
			try {
				BufferedImage bufferedImage = ImageIO.read(file);
				Image image = SwingFXUtils.toFXImage(bufferedImage, null);
				gc.drawImage(image, 0, 0);
			} catch (IOException e) {
				System.out.println(e);
			}
		}
	}

	@FXML
	private void saveImage() {
		try {
			FileChooser fileChooser = new FileChooser();

			// Set extension filter
			FileChooser.ExtensionFilter extFilterJPG = new FileChooser.ExtensionFilter("JPG files (*.JPG)", "*.JPG");
			FileChooser.ExtensionFilter extFilterjpg = new FileChooser.ExtensionFilter("jpg files (*.jpg)", "*.jpg");
			FileChooser.ExtensionFilter extFilterPNG = new FileChooser.ExtensionFilter("PNG files (*.PNG)", "*.PNG");
			FileChooser.ExtensionFilter extFilterpng = new FileChooser.ExtensionFilter("png files (*.png)", "*.png");
			fileChooser.getExtensionFilters().addAll(extFilterPNG, extFilterpng, extFilterJPG, extFilterjpg);

			fileChooser.setInitialDirectory(new File(System.getProperty("user.home"), "Desktop"));
			fileChooser.setSelectedExtensionFilter(extFilterpng);

			// Show open file dialog
			File file = fileChooser.showSaveDialog(null);
			if (file != null) {
				SnapshotParameters sp = new SnapshotParameters();
				sp.setFill(Color.TRANSPARENT);

				WritableImage writableImage = canvas.snapshot(sp, null);
				RenderedImage renderedImage = SwingFXUtils.fromFXImage(writableImage, null);
				ImageIO.write(renderedImage, "png", file);
			}
		} catch (IOException ex) {
			System.out.println(ex);
		}
	}

	@FXML
	private void setCanvasSize() {
		try {
			canvas.setHeight(Integer.parseInt(canvasH.getText()));
			canvas.setWidth(Integer.parseInt(canvasW.getText()));
			setCanvas2Size();
		} catch (NumberFormatException | NullPointerException e) {
			System.out.println(e);
		}
	}

	@FXML
	private void expandCanvasSize() {
		canvas.setHeight(scrollPane.getHeight() - 8);
		canvas.setWidth(scrollPane.getWidth() - 8);
		setCanvas2Size();
	}

	private void setCanvas2Size() {
		canvas2.setWidth(canvas.getWidth());
		canvas2.setHeight(canvas.getHeight());
	}

	@FXML
	private void setStrokeColor() {
		Brushes.setStrokeColor(colorPickerStroke.getValue());
	}

	@FXML
	private void setFillColor() {
		Brushes.setFillColor(colorPickerFill.getValue());
	}

	@FXML
	private void setLineWidth() {
		Brushes.setLwd(slider.getValue());
		textLwd.setText(String.format("%1$.1f", slider.getValue()));
	}

	@FXML
	private void onTextLwdChanged() {
		double lw = Double.parseDouble(textLwd.getText());
		if (lw < slider.getMin())
			lw = slider.getMin();
		if (lw > slider.getMax())
			lw = slider.getMax();
		slider.setValue(lw);
		setLineWidth();
	}

	// checkBox RndCol
	@FXML
	private void setBrushStatus() {
		Brushes.setStrokeColor(colorPickerStroke.getValue());
		Brushes.setFillColor(colorPickerFill.getValue());
		Brushes.setIsFill(fill.isSelected());
		Brushes.setIsStroke(stroke.isSelected());
		Brushes.setLwd(slider.getValue());
		if (posCol.isSelected())
			Brushes.setColorState(ColorState.Position);
		else if (rndCol.isSelected())
			Brushes.setColorState(ColorState.Random);
		else
			Brushes.setColorState(ColorState.Fixed);
	}

	private void setGCStatus(MouseEvent e) {
		Brushes.setGCStatus(e, gc);
	}

	@FXML
	private void brush1Button() {
		canvas.setCursor(Cursor.DEFAULT);
		canvas.toFront();
		canvas.setOnMouseDragged(e -> Brushes.holidayBrush(e, gc));
		canvas.setOnMousePressed(e -> onMouseDown(e));
	}

	// star
	@FXML
	public void starBrushButton() {
		canvas.setCursor(Cursor.DEFAULT);
		canvas.toFront();
		setBrushStatus();
		int nV = Integer.parseInt(textNStar.getText());
		double r = Double.parseDouble(textC.getText());
		double rotation = Double.parseDouble(textRotation.getText()) / 180 * Math.PI;

		canvas.setOnMouseDragged(e -> Brushes.starBrush(e, gc, nV, r, r / 3, rotation));
		canvas.setOnMousePressed(e -> Brushes.starBrush(e, gc, nV, r, r / 3, rotation));
	}

	// Hoz mirror
	@FXML
	public void brush3Button() {
		canvas.setCursor(Cursor.DEFAULT);
		setBrushStatus();
		canvas.toFront();
		canvas.setOnMouseDragged(e -> Brushes.hozMirrorBrush(e, gc));
		canvas.setOnMousePressed(this::onMouseDown);
	}

	// freehand
	@FXML
	public void brush4Button() {
		canvas.setCursor(Cursor.DEFAULT);
		setBrushStatus();
		canvas.toFront();
		canvas.setOnMouseDragged(e -> Brushes.drawFreeHand(e, gc));
		canvas.setOnMousePressed(this::onMouseDown);
	}

	// quadratic
	@FXML
	public void brush5Button() {
		canvas.setCursor(Cursor.CROSSHAIR);
		setBrushStatus();
		canvas.toFront();
		canvas.setOnMouseDragged(e -> quadBrush(e));
		canvas.setOnMousePressed(e -> quadBrush(e));
	}

	// path
	@FXML
	public void onActionPathButton() {
		setBrushStatus();
		canvas.toFront();
		canvas.setOnMouseDragged(e -> drawPath(e));
		canvas.setOnMousePressed(e -> drawPath(e));
	}

	public void rectButton() {
		canvas.setCursor(Cursor.CROSSHAIR);
		setBrushStatus();
		canvas2.toFront();
		canvas2.setOnMouseDragged(e -> Brushes.drawRect(e, gc2));
		canvas2.setOnMousePressed(e -> onMouseDown(e));
		canvas2.setOnMouseReleased(e -> Brushes.rectOnMouseReleased(e, gc, gc2));
	}

	public void ovalButton() {
		canvas.setCursor(Cursor.CROSSHAIR);
		setBrushStatus();
		canvas2.toFront();
		canvas2.setOnMouseDragged(e -> Brushes.drawOval(e, gc2));
		canvas2.setOnMousePressed(e -> onMouseDown(e));
		canvas2.setOnMouseReleased(e -> Brushes.ovalOnMouseReleased(e, gc, gc2));
	}

	public void lineButton() {
		canvas.setCursor(Cursor.CROSSHAIR);
		setBrushStatus();
		canvas2.toFront();
		canvas2.setOnMouseDragged(e -> Brushes.drawLine(e, gc2));
		canvas2.setOnMousePressed(e -> onMouseDown(e));
		int number = Integer.parseInt(textNStar.getText());
		double distance = Double.parseDouble(textRotation.getText());
		canvas2.setOnMouseReleased(e -> Brushes.lineOnMouseReleased(e, gc, gc2, number, distance));
	}

	@FXML
	public void drawRndRect() {
		canvas.setCursor(Cursor.DEFAULT);
		setBrushStatus();
		int number = Integer.parseInt(textNStar.getText());
		double max = Double.parseDouble(textRotation.getText()), min = Double.parseDouble(textC.getText());
		Brushes.drawRndRect(gc, number, max, min);
		label1.setText("Number: " + number + ", max size: " + max + ", min size: " + min);
	}

	// quadratic
	void quadBrush(MouseEvent e) {
		x0 = e.getX();
		y0 = e.getY();
		Color sColor;
		double a = Double.parseDouble(textNStar.getText()), // a=1
				b = Double.parseDouble(textRotation.getText()), // b=0
				c = Double.parseDouble(textC.getText());// c=-3
		double x1 = 0, y1 = 0, scale = 20;

		// stroke color
		if (posCol.isSelected()) {
			sColor = Color.rgb((int) (Math.random() * 256), (int) (Math.random() * 256), (int) (Math.random() * 256),
					Math.random());
		} else {
			sColor = colorPickerStroke.getValue();
		}

		gc.setStroke(sColor);

		for (int i = -12; i <= 12; i++) { // single quadratic
			x = i / 4.0;
			y = a * x * x + b * x + c;
			if (i == -12) {
				x1 = x;
				y1 = y;
			}

			gc.strokeLine(x * scale + x0, y * scale + y0, x1 * scale + x0, y1 * scale + y0);
			x1 = x;
			y1 = y;
		}
	}

	// path
	@FXML
	void drawPath(MouseEvent e) {
		canvas.setCursor(Cursor.HAND);
		x = e.getX();
		y = e.getY();

		Color sColor, fColor;
		if (posCol.isSelected()) {
			sColor = Color.rgb((int) (Math.random() * 256), (int) (Math.random() * 256), (int) (Math.random() * 256),
					Math.random());
			fColor = Color.rgb((int) (Math.random() * 256), (int) (Math.random() * 256), (int) (Math.random() * 256),
					Math.random());
		} else {
			sColor = colorPickerStroke.getValue();
			fColor = colorPickerFill.getValue();
		}

		gc.setStroke(sColor);
		gc.setFill(fColor);
		double r = Double.parseDouble(textNStar.getText()), s = Double.parseDouble(textRotation.getText());

		gc.beginPath();
		gc.moveTo(x, y);
		gc.lineTo(x + 50 - s, y);
		gc.lineTo(x + 70 - s, y - 50);
		gc.bezierCurveTo(x + 70 + 100 - s, y - 50 - r, x + 70 - 200, y - 50 - r, x - 20, y - 50);
		gc.closePath();
		gc.stroke();
		if (fill.isSelected())
			gc.fill();
	}

	public void paintTextButton() {
		canvas.setCursor(Cursor.TEXT);
		// try to show sub window just by the button
		// Bounds screenBounds =
		// textButton.localToScene(textButton.getBoundsInLocal());// not working
		boolean answer = ti.display();// screenBounds.getMaxX(),
										// screenBounds.getMaxY());
		if (answer) {
			canvas.toFront();
			canvas.setOnMousePressed(e -> paintText(e, ti.getInputText(), ti.getFont(), ti.getFontSize()));
			canvas.setOnMouseDragged(null);
		}
	}

	public void paintSparkleButton() {
		canvas.setCursor(Cursor.HAND);
		canvas.toFront();
		canvas.setOnMouseDragged(this::drawSparkles);
		canvas.setOnMousePressed(this::drawSparkles);
	}

	private void paintText(MouseEvent e, String text, String font, double fontSize) {
		x = e.getX();
		y = e.getY();

		gc.setFont(new Font(font, fontSize));
		if (stroke.isSelected())
			gc.strokeText(text, x, y);
		if (fill.isSelected())
			gc.fillText(text, x, y);
	}

	private void drawSparkles(MouseEvent e) {
		x = e.getX();
		y = e.getY();
		double n = Double.parseDouble(textNStar.getText());
		double s = Double.parseDouble(textRotation.getText());
		double w = Double.parseDouble(textC.getText());
		for (int i = 0; i < n; i++) {
			setGCStatus(e);
			double theta = Math.random() * Math.PI * 2;
			double r = s * Math.random();
			gc.fillOval(x + Math.cos(theta) * r, y + Math.sin(theta) * r, w, w);
		}
	}

	public void scrollPaneOnMouseMoved(MouseEvent e) {
		label4.setText(String.format("%1$1.0f", e.getX()) + ", " + String.format("%1$1.0f", e.getY()));

		// label1.setText(Brushes.log(Brushes.getX1(), Brushes.getY1(),
		// Brushes.getSelectionWidth(), Brushes.getSelectionHeight()));
		label2.setText(isInRect(e, Brushes.getSelectionBounds()) ? "IN" : "Out");
		// label2.setText("ScrollPane content: " + scrollPane.getContent());
		// pane.setStyle("-fx-background-color: #fefefe");
		// scrollPane.setStyle("-fx-background: #808080");
	}

	public void eraserButton() {
		double w = Double.parseDouble(textNStar.getText()), h = Double.parseDouble(textRotation.getText());
		setGCStatus(null);
		// System.out.println(System.getProperty("user.dir"));

		Image im = new Image(
				"http://icons.iconarchive.com/icons/jonathan-rey/star-wars-vehicles/32/Death-Star-1st-icon1.png");
		System.out.println(im.getWidth());
		if (im.getWidth() == 0)
			im = new Image(getClass().getResourceAsStream("css/images/rect.png"));

		canvas.setCursor(new ImageCursor(im));
		canvas.toFront();
		canvas.setOnMouseDragged(e -> Brushes.drawErase(e, gc, w, h));
		canvas.setOnMousePressed(e -> Brushes.drawErase(e, gc, w, h));
	}
Boolean startSelecting;
	@FXML
	private void onMouseDown(MouseEvent e) {
		x0 = e.getX();
		y0 = e.getY();
		Brushes.setX0(x0);
		Brushes.setY0(y0);
		// label3.setText(Brushes.log(Brushes.isSelectionSet()?1:0));
		System.out.print(Brushes.isSelectionSet());
		if (Brushes.isSelectionSet()){
			if (isInRect(e, Brushes.getSelectionBounds())) {
				Brushes.GCClear(gc2);
				img = Brushes.copyImage(canvas, Brushes.getSelectionBounds());
				if (img.getWidth() > 0) {
					imageView.setImage(img);
					pane.getChildren().add(imageView);
				}
				// label3.setText(Brushes.log(e.getX(),e.getY()));
			} else {
				startSelecting=false;
				Brushes.setIsSelectionSet(false);
				gc.drawImage(img, e.getX(), e.getY());
				Brushes.GCClear(gc2);
				pane.getChildren().remove(imageView);

				System.out.println("  , " + Brushes.isSelectionSet());

			}
		}
		else startSelecting=true;
	}

	public void selectButton(ActionEvent actionEvent) {
		canvas2.setCursor(Cursor.CROSSHAIR);
		canvas2.toFront();

		canvas2.setOnMousePressed(e -> onMouseDown(e));
		canvas2.setOnMouseReleased(e -> canvas2OnMouseRelease(e));
		canvas2.setOnMouseMoved(e -> canvas2OnMouseMoved(e));
		// canvas2.setOnMouseDragged(e -> canvas2OnMouseDragged(e));
		//// canvas2.setOnMouseDragReleased(e -> canvas2OnDragReleased(e));
		imageView = new ImageView();
		imageView.setOnMousePressed(this::imgOnMousePressed);
		imageView.setOnMouseDragged(this::imgOnMouseDragged);
		imageView.setStyle("-fx-border-color: black");
	}

	private void imgOnMouseDragged(MouseEvent t) {
		double offsetX = t.getSceneX() - orgSceneX;
		double offsetY = t.getSceneY() - orgSceneY;
		double newTranslateX = orgTranslateX + offsetX;
		double newTranslateY = orgTranslateY + offsetY;

		((ImageView) (t.getSource())).setTranslateX(newTranslateX);
		((ImageView) (t.getSource())).setTranslateY(newTranslateY);
	}

	private void imgOnMousePressed(MouseEvent t) {
		orgSceneX = t.getSceneX();
		orgSceneY = t.getSceneY();
		orgTranslateX = ((ImageView) (t.getSource())).getTranslateX();
		orgTranslateY = ((ImageView) (t.getSource())).getTranslateY();
	}

	private void canvas2OnMouseRelease(MouseEvent e) {
//		if (!Brushes.isSelectionSet()) {
//			Brushes.selectOnMouseReleased(e, canvas, gc2);
//			Brushes.setIsSelectionSet(true);
//		}
		if(startSelecting){
			startSelecting=false;
			Brushes.selectOnMouseReleased(e, canvas, gc2);
			Brushes.setIsSelectionSet(true);
		}
	}

	// private void canvas2OnMouseDragged(MouseEvent e) {
	// if (Brushes.isSelectionSet()) {
	// canvas2.setCursor(Cursor.CLOSED_HAND);
	// Brushes.GCClear(gc2);
	//
	// gc2.drawImage(img, e.getX(), e.getY());
	// gc2.strokeRect(e.getX(), e.getY(), img.getWidth(), img.getHeight());
	//
	// } else Brushes.drawRect(e, gc2);
	// }

	// private void canvas2OnDragReleased(MouseDragEvent e) { //
	// label1.setText(Brushes.log(e.getX(), e.getY(), Brushes.isSelectionSet() ?
	// 1f : 0f));
	//
	// if (Brushes.isSelectionSet()) {
	// gc.drawImage(img, e.getX(), e.getY());
	// Brushes.GCClear(gc2);
	// canvas2.setCursor(Cursor.DEFAULT);
	//
	// } else
	// Brushes.selectOnMouseReleased(e, canvas, gc2);
	// }

	private void canvas2OnMouseMoved(MouseEvent e) {
		if (Brushes.isSelectionSet()) {
			Rectangle sb = Brushes.getSelectionBounds();
			if (isInRect(e, sb)) {
				canvas2.setCursor(Cursor.MOVE);
			} else {
				canvas2.setCursor(Cursor.DEFAULT);
			}
		}
	}

	private boolean isInRect(MouseEvent e, Rectangle rectangle) {
		return isInRect(e, rectangle.getX(), rectangle.getY(), rectangle.getWidth(), rectangle.getHeight());
	}

	private boolean isInRect(MouseEvent e, double x1, double y1, double selectionWidth, double selectionHeight) {
		double x = e.getX(), y = e.getY();
		if (x >= x1 & x <= x1 + selectionWidth & y >= y1 & y <= y1 + selectionHeight)
			return true;
		else
			return false;
	}

	public void copyButton(ActionEvent actionEvent) {
		canvas2.setCursor(Cursor.CROSSHAIR);
		canvas2.toFront();
		canvas2.setOnMouseDragged(e -> Brushes.drawRect(e, gc2));
		canvas2.setOnMousePressed(e -> onMouseDown(e));
		canvas2.setOnMouseReleased(e -> Brushes.copyOnMouseReleased(e, canvas, gc2));
	}

	public void pasteButton(ActionEvent actionEvent) {
		canvas2.setCursor(Cursor.CROSSHAIR);
		canvas2.toFront();
		canvas2.setOnMouseDragged(e -> Brushes.drawRect(e, gc2));
		canvas2.setOnMousePressed(e -> onMouseDown(e));
		canvas2.setOnMouseReleased(e -> Brushes.copyOnMouseReleased(e, canvas, gc2));
	}

	@FXML public void cutButton() {}
	@FXML public void copyButton() {}
	@FXML public void pasteButton() {}

	@FXML public void newCanvas() {}

	@FXML public void vertMirrorButton() {}

	@FXML public void polyBrushButton() {}
	

}
