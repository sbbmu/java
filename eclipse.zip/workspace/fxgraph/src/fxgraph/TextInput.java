package fxgraph;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;

/**
 * Created by Bing Sun1 on 8/27/2016.
 */
public class TextInput {
    static boolean OKStatus = false;
    static private String inputText = "";
    static private String font = "";
    static private double fontSize = 0;

    public String getFont() {
        return font;
    }

    public double getFontSize() {
        return fontSize;
    }

    public String getInputText() {
        return inputText;
    }

    public boolean display() {//double x,double y
        Stage window = new Stage();
        Button okButton, cancelButton;
        TextField textInput;

        // Text fields
        textInput = new TextField(inputText);
        textInput.setPromptText("input text");
        Label label = new Label("Please input: ");
        VBox textVBox = new VBox(label, textInput);

        // font selection
        ChoiceBox<String> fontText = new ChoiceBox<>();
        fontText.getItems().addAll("Arial", "Times New Roman", "Tahoma");
        fontText.setValue(font.length() == 0 ? fontText.getItems().get(0) : font);

        ComboBox<Double> sizeText = new ComboBox<>();
        sizeText.getItems().addAll(5.0, 6.0, 7.0, 8.0, 10.0, 12.0, 13.0, 14.0, 18.0, 22.0, 36.0, 72.0);
        sizeText.setValue(fontSize == 0 ? 11.0 : fontSize);

        HBox fontHBox = new HBox(fontText, sizeText);
        fontHBox.setSpacing(10);
        fontHBox.setPadding(new Insets(10, 10, 10, 10));
        fontHBox.setAlignment(Pos.CENTER);

        // Buttons
        okButton = new Button("OK");
        okButton.setOnAction(e -> {
            inputText = textInput.getText();
            font = fontText.getValue();
            fontSize = sizeText.getValue();
            OKStatus = true;
            window.close();
        });

        cancelButton = new Button("Close");
        cancelButton.setOnAction(e -> {
            OKStatus = false;
            window.close();
        });

        HBox buttonLayout = new HBox(10);
        buttonLayout.setPadding(new Insets(10, 10, 10, 10));
        buttonLayout.setAlignment(Pos.CENTER);
        buttonLayout.getChildren().addAll(okButton, cancelButton);

        // root layout
        VBox vbox = new VBox(10);
        vbox.setAlignment(Pos.CENTER);
        vbox.setPadding(new Insets(10, 10, 10, 10));
        vbox.setSpacing(10);
        vbox.getChildren().addAll(textVBox, fontHBox, buttonLayout);

        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle("Input text");
        window.setScene(new Scene(vbox, 300, 200));
//        window.setX(x);window.setY(y);
        window.showAndWait();
        return OKStatus;
    }
}
