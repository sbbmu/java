package fxgraph;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Main extends Application {
    public Stage window;

    @Override
    public void start(Stage primaryStage) throws Exception {
        window = primaryStage;
        Parent layout = FXMLLoader.load(getClass().getResource("fxgraph.fxml"));

        window.setTitle("JavaFX 8 Test ground");
        window.setScene(new Scene(layout, 1000, 800));
        window.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
