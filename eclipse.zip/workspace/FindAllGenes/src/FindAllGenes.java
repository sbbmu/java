
/**
 * Write a description of FindAllGenes here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
import java.lang.Math;
import java.util.Hashtable;
import java.util.Set;
import edu.duke.*;

public class FindAllGenes {
	private static String print3(String seq, int start) {
		String out = "";
		for (int i = 0; i < seq.length(); i++) {
			out += seq.substring(i, i + 1);
			if ((i - start % 3 + 1) % 3 == 0)
				out += " ";
		}
		return (out);
	}

	private static String print3(String seq) {
		return (print3(seq, 0));
	}

	private static int searchStop(String seq, int start) {
		seq = seq.toUpperCase();
		int endGene = -1;
		if (start != -1) {
			int end = seq.indexOf("TAG", start + 3);
			// take the shortest one if multiple stop codon found
			if (end != -1 && (end - start) % 3 == 0) {
				endGene = end + 3;
			}
			end = seq.indexOf("TGA", start + 3);
			if (end != -1 && (end - start) % 3 == 0) {
				endGene = Math.min(endGene, end + 3);
				if (endGene == -1)
					endGene = end + 3;
			}
			end = seq.indexOf("TAA", start + 3);
			if (end != -1 && (end - start) % 3 == 0) {
				endGene = Math.min(endGene, end + 3);
				if (endGene == -1)
					endGene = end + 3;
			}
		}
		return (endGene);
	}

	private static String findGene(String seq, int start) {
		int end = searchStop(seq, start);
		if (start == -1 || end == -1)
			return ("");
		else
			return (seq.substring(start, end));
	}

	private static void findAll(String seq) {
		int start = seq.toUpperCase().indexOf("ATG");
		if (start != -1) {
			String gene = print3(findGene(seq, start));
			if (gene != "")
				System.out.println(gene);
			seq = seq.substring(start + 3);
			findAll(seq);
		}
	}

//	public static Hashtable<String, Integer> count(String seq) {
//		char[] cc = seq.toUpperCase().toCharArray();
//		Hashtable<String, Integer> count = new Hashtable<String, Integer>();
//		count.put("A", 0);
//		count.put("T", 0);
//		count.put("C", 0);
//		count.put("G", 0);
//		count.put("O", 0);
//
//		for (int i = 0; i < cc.length; i++) {
//			switch (cc[i]) {
//			case 'A':
//				count.put("A", count.get("A") + 1);
//				break;
//			case 'T':
//				count.put("T", count.get("T") + 1);
//				break;
//			case 'C':
//				count.put("C", count.get("C") + 1);
//				break;
//			case 'G':
//				count.put("G", count.get("G") + 1);
//				break;
//			default:
//				count.put("O", count.get("O") + 1);
//				break;
//			}
//		}
//		return (count);
//	}

	public static Hashtable<String, Integer> countAll(String seq) {
		char[] cc = seq.toCharArray();
		Hashtable<String, Integer> count = new Hashtable<String, Integer>();
		for (int i = 0; i < cc.length; i++) {
			String key=String.valueOf(cc[i]);
			if(!count.containsKey(key)){				
				count.put(key, 1);
			}
			else{
				count.put(key, count.get(key) + 1);
			}
		}

		return (count);
	}

	public static void main(String[] args) {
		String dna = "tccaATGacatgGACCTGATAtagcTAG";
		// findAll(dna);
		//
		// System.out.println("Hello, Java!");
		// System.out.println(-12 % 3);

		// findAll("CATGTAATAGATGAATGACTGATAGATATGCTTGTATGCTATGAAAATGTGAAATGACCCA");
		 findAll("ccatgccctaataaatgtctgtaatgtaga");

		dna = "CATGTAATAGATGAATGACTGATAGATATGCTTGTATGCTATGAAAATGTGAAATGACCCAsdxy";
		
//		Hashtable<String, Integer> count = count(dna);
//		System.out.println("A: " + count.get("A") + "\tT: " + count.get("T") + "\tC: " + count.get("C") + "\tG: "
//				+ count.get("G") + "\tOther: " + count.get("O"));		
//		
		Hashtable<String, Integer> countAll = countAll(dna);		
		Set<String> keys = countAll.keySet();
		for(String key: keys){
			System.out.println("Value of '"+key+"' is: "+countAll.get(key));
		}
	}

}
